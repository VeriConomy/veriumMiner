/*
 * Copyright 2009 Colin Percival, 2011 ArtForz, 2011-2014 pooler
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * This file was originally written by Colin Percival as part of the Tarsnap
 * online backup system.
 *
 * *** (27-08-2018) 	Edited by Rollmeister for 2ways aarch64 support, inlineable sha256 and memcpy alternatives. 
 *			≈13+% performance improvement on 1gb 4 core armv8 boards, with small enough kernel (below 8mb)
 *			and reduced background task memory footprint. No perfomance regression in most cases for 2ways 
 *			compared to original 3ways while reducing memory requirements by 1/3rd. 
 *			Possibly due to significantly improved possibility of dual issue instruction ordering 
 *			which gcc8 does well. Refer to github repo or readme.md for compile instructions.
 *			Currently only works for arm64. aarch32 support has been tested to work by g4b.
 *			Might add support for it (Odroid XU4 users) in future. #UPDATE: Neon based stores, loads/eqxor.
			xor_salsa8() replaced.
 */
/*#pragma GCC push_options
#pragma GCC optimize("O2")*/
#include "miner.h"

#include <stdlib.h>
#include <string.h>
#include <inttypes.h>

#ifdef __linux__
#include <sys/mman.h>
#include <errno.h>
#endif

#if defined(__aarch64__)
#undef HAVE_SHA256_4WAY
#undef HAVE_SHA256_8WAY
#endif

#ifndef __aarch64__

static const uint32_t keypad[12] = {
	0x80000000, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0x00000280
};
static const uint32_t innerpad[11] = {
	0x80000000, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0x000004a0
};
static const uint32_t outerpad[ 8] = {
	0x80000000, 0, 0, 0, 0, 0, 0, 0x00000300
};

static const uint32_t finalblk[16] = {
	0x00000001, 0x80000000, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0x00000620
};

static inline void HMAC_SHA256_80_init(const uint32_t *key,
	uint32_t *tstate, uint32_t *ostate)
{
	uint32_t ihash[ 8];
	uint32_t pad[16];
	int i;

	/* tstate is assumed to contain the midstate of key */
	newmemcpy(pad, key + 16, 16);
	newmemcpy(pad + 4, keypad, 48);
	sha256_transform(tstate, pad, 0);
	newmemcpy(ihash, tstate, 32);

	sha256_init(ostate);
	for (i = 0; i < 8; i++)
		pad[i] = ihash[i] ^ 0x5c5c5c5c;
	for (; i < 16; i++)
		pad[i] = 0x5c5c5c5c;
	sha256_transform(ostate, pad, 0);

	sha256_init(tstate);
	for (i = 0; i < 8; i++)
		pad[i] = ihash[i] ^ 0x36363636;
	for (; i < 16; i++)
		pad[i] = 0x36363636;
	sha256_transform(tstate, pad, 0);
}

static inline void PBKDF2_SHA256_80_128(const uint32_t *tstate,
	const uint32_t *ostate, const uint32_t *salt, uint32_t *output)
{
	uint32_t istate[ 8], ostate2[ 8];
	uint32_t ibuf[16], obuf[16];
	int i, j;

	newmemcpy(istate, tstate, 32);
	sha256_transform(istate, salt, 0);
	
	newmemcpy(ibuf, salt + 16, 16);
	newmemcpy(ibuf + 5, innerpad, 44);
	newmemcpy(obuf + 8, outerpad, 32);

	for (i = 0; i < 4; i++) {
		newmemcpy(obuf, istate, 32);
		ibuf[ 4] = i + 1;
		sha256_transform(obuf, ibuf, 0);

		newmemcpy(ostate2, ostate, 32);
		sha256_transform(ostate2, obuf, 0);
		for (j = 0; j < 8; j++)
			output[8 * i + j] = swab32(ostate2[j]);
	}
}

static inline void PBKDF2_SHA256_128_32(uint32_t *tstate, uint32_t *ostate,
	const uint32_t *salt, uint32_t *output)
{
	uint32_t buf[16];
	int i;
	
	sha256_transform(tstate, salt, 1);
	sha256_transform(tstate, salt + 16, 1);
	sha256_transform(tstate, finalblk, 0);
	newmemcpy(buf, tstate, 32);
	newmemcpy(buf + 8, outerpad, 32);

	sha256_transform(ostate, buf, 0);
	for (i = 0; i < 8; i++)
		output[i] = swab32(ostate[i]);
}
#endif

#ifdef HAVE_SHA256_4WAY

static const uint32_t keypad_4way[4 * 12] = {
	0x80000000, 0x80000000, 0x80000000, 0x80000000,
	0x00000000, 0x00000000, 0x00000000, 0x00000000,
	0x00000000, 0x00000000, 0x00000000, 0x00000000,
	0x00000000, 0x00000000, 0x00000000, 0x00000000,
	0x00000000, 0x00000000, 0x00000000, 0x00000000,
	0x00000000, 0x00000000, 0x00000000, 0x00000000,
	0x00000000, 0x00000000, 0x00000000, 0x00000000,
	0x00000000, 0x00000000, 0x00000000, 0x00000000,
	0x00000000, 0x00000000, 0x00000000, 0x00000000,
	0x00000000, 0x00000000, 0x00000000, 0x00000000,
	0x00000000, 0x00000000, 0x00000000, 0x00000000,
	0x00000280, 0x00000280, 0x00000280, 0x00000280
};
static const uint32_t innerpad_4way[4 * 11] = {
	0x80000000, 0x80000000, 0x80000000, 0x80000000,
	0x00000000, 0x00000000, 0x00000000, 0x00000000,
	0x00000000, 0x00000000, 0x00000000, 0x00000000,
	0x00000000, 0x00000000, 0x00000000, 0x00000000,
	0x00000000, 0x00000000, 0x00000000, 0x00000000,
	0x00000000, 0x00000000, 0x00000000, 0x00000000,
	0x00000000, 0x00000000, 0x00000000, 0x00000000,
	0x00000000, 0x00000000, 0x00000000, 0x00000000,
	0x00000000, 0x00000000, 0x00000000, 0x00000000,
	0x00000000, 0x00000000, 0x00000000, 0x00000000,
	0x000004a0, 0x000004a0, 0x000004a0, 0x000004a0
};
static const uint32_t outerpad_4way[4 * 8] = {
	0x80000000, 0x80000000, 0x80000000, 0x80000000,
	0x00000000, 0x00000000, 0x00000000, 0x00000000,
	0x00000000, 0x00000000, 0x00000000, 0x00000000,
	0x00000000, 0x00000000, 0x00000000, 0x00000000,
	0x00000000, 0x00000000, 0x00000000, 0x00000000,
	0x00000000, 0x00000000, 0x00000000, 0x00000000,
	0x00000000, 0x00000000, 0x00000000, 0x00000000,
	0x00000300, 0x00000300, 0x00000300, 0x00000300
};
static const uint32_t _ALIGN(16) finalblk_4way[4 * 16] = {
	0x00000001, 0x00000001, 0x00000001, 0x00000001,
	0x80000000, 0x80000000, 0x80000000, 0x80000000,
	0x00000000, 0x00000000, 0x00000000, 0x00000000,
	0x00000000, 0x00000000, 0x00000000, 0x00000000,
	0x00000000, 0x00000000, 0x00000000, 0x00000000,
	0x00000000, 0x00000000, 0x00000000, 0x00000000,
	0x00000000, 0x00000000, 0x00000000, 0x00000000,
	0x00000000, 0x00000000, 0x00000000, 0x00000000,
	0x00000000, 0x00000000, 0x00000000, 0x00000000,
	0x00000000, 0x00000000, 0x00000000, 0x00000000,
	0x00000000, 0x00000000, 0x00000000, 0x00000000,
	0x00000000, 0x00000000, 0x00000000, 0x00000000,
	0x00000000, 0x00000000, 0x00000000, 0x00000000,
	0x00000000, 0x00000000, 0x00000000, 0x00000000,
	0x00000000, 0x00000000, 0x00000000, 0x00000000,
	0x00000620, 0x00000620, 0x00000620, 0x00000620
};

static inline void HMAC_SHA256_80_init_4way(const uint32_t *key,
	uint32_t *tstate, uint32_t *ostate)
{
	uint32_t _ALIGN(16) ihash[4 * 8];
	uint32_t _ALIGN(16) pad[4 * 16];
	int i;

	/* tstate is assumed to contain the midstate of key */
	newmemcpy(pad, key + 4 * 16, 4 * 16);
	newmemcpy(pad + 4 * 4, keypad_4way, 4 * 48);
	sha256_transform_4way(tstate, pad, 0);
	newmemcpy(ihash, tstate, 4 * 32);

	sha256_init_4way(ostate);
	for (i = 0; i < 4 * 8; i++)
		pad[i] = ihash[i] ^ 0x5c5c5c5c;
	for (; i < 4 * 16; i++)
		pad[i] = 0x5c5c5c5c;
	sha256_transform_4way(ostate, pad, 0);

	sha256_init_4way(tstate);
	for (i = 0; i < 4 * 8; i++)
		pad[i] = ihash[i] ^ 0x36363636;
	for (; i < 4 * 16; i++)
		pad[i] = 0x36363636;
	sha256_transform_4way(tstate, pad, 0);
}

static inline void PBKDF2_SHA256_80_128_4way(const uint32_t *tstate,
	const uint32_t *ostate, const uint32_t *salt, uint32_t *output)
{
	uint32_t _ALIGN(16) istate[4 * 8];
	uint32_t _ALIGN(16) ostate2[4 * 8];
	uint32_t _ALIGN(16) ibuf[4 * 16];
	uint32_t _ALIGN(16) obuf[4 * 16];
	int i, j;

	newmemcpy(istate, tstate, 4 * 32);
	sha256_transform_4way(istate, salt, 0);
	
	newmemcpy(ibuf, salt + 4 * 16, 4 * 16);
	newmemcpy(ibuf + 4 * 5, innerpad_4way, 4 * 44);
	newmemcpy(obuf + 4 * 8, outerpad_4way, 4 * 32);

	for (i = 0; i < 4; i++) {
		newmemcpy(obuf, istate, 4 * 32);
		ibuf[4 * 4 + 0] = i + 1;
		ibuf[4 * 4 + 1] = i + 1;
		ibuf[4 * 4 + 2] = i + 1;
		ibuf[4 * 4 + 3] = i + 1;
		sha256_transform_4way(obuf, ibuf, 0);

		newmemcpy(ostate2, ostate, 4 * 32);
		sha256_transform_4way(ostate2, obuf, 0);
		for (j = 0; j < 4 * 8; j++)
			output[4 * 8 * i + j] = swab32(ostate2[j]);
	}
}

static inline void PBKDF2_SHA256_128_32_4way(uint32_t *tstate,
	uint32_t *ostate, const uint32_t *salt, uint32_t *output)
{
	uint32_t _ALIGN(16) buf[4 * 16];
	int i;
	
	sha256_transform_4way(tstate, salt, 1);
	sha256_transform_4way(tstate, salt + 4 * 16, 1);
	sha256_transform_4way(tstate, finalblk_4way, 0);
	newmemcpy(buf, tstate, 4 * 32);
	newmemcpy(buf + 4 * 8, outerpad_4way, 4 * 32);

	sha256_transform_4way(ostate, buf, 0);
	for (i = 0; i < 4 * 8; i++)
		output[i] = swab32(ostate[i]);
}

#endif /* HAVE_SHA256_4WAY */


#ifdef HAVE_SHA256_8WAY

static const uint32_t _ALIGN(32) finalblk_8way[8 * 16] = {
	0x00000001, 0x00000001, 0x00000001, 0x00000001, 0x00000001, 0x00000001, 0x00000001, 0x00000001,
	0x80000000, 0x80000000, 0x80000000, 0x80000000, 0x80000000, 0x80000000, 0x80000000, 0x80000000,
	0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000,
	0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000,
	0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000,
	0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000,
	0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000,
	0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000,
	0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000,
	0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000,
	0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000,
	0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000,
	0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000,
	0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000,
	0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000,
	0x00000620, 0x00000620, 0x00000620, 0x00000620, 0x00000620, 0x00000620, 0x00000620, 0x00000620
};

static inline void HMAC_SHA256_80_init_8way(const uint32_t *key,
	uint32_t *tstate, uint32_t *ostate)
{
	uint32_t _ALIGN(32) ihash[8 * 8];
	uint32_t _ALIGN(32)  pad[8 * 16];
	int i;
	
	/* tstate is assumed to contain the midstate of key */
	newmemcpy(pad, key + 8 * 16, 8 * 16);
	for (i = 0; i < 8; i++)
		pad[8 * 4 + i] = 0x80000000;
	memset(pad + 8 * 5, 0x00, 8 * 40);
	for (i = 0; i < 8; i++)
		pad[8 * 15 + i] = 0x00000280;
	sha256_transform_8way(tstate, pad, 0);
	newmemcpy(ihash, tstate, 8 * 32);
	
	sha256_init_8way(ostate);
	for (i = 0; i < 8 * 8; i++)
		pad[i] = ihash[i] ^ 0x5c5c5c5c;
	for (; i < 8 * 16; i++)
		pad[i] = 0x5c5c5c5c;
	sha256_transform_8way(ostate, pad, 0);
	
	sha256_init_8way(tstate);
	for (i = 0; i < 8 * 8; i++)
		pad[i] = ihash[i] ^ 0x36363636;
	for (; i < 8 * 16; i++)
		pad[i] = 0x36363636;
	sha256_transform_8way(tstate, pad, 0);
}

static inline void PBKDF2_SHA256_80_128_8way(const uint32_t *tstate,
	const uint32_t *ostate, const uint32_t *salt, uint32_t *output)
{
	uint32_t _ALIGN(32) istate[8 * 8];
	uint32_t _ALIGN(32) ostate2[8 * 8];
	uint32_t _ALIGN(32) ibuf[8 * 16];
	uint32_t _ALIGN(32) obuf[8 * 16];
	int i, j;
	
	newmemcpy(istate, tstate, 8 * 32);
	sha256_transform_8way(istate, salt, 0);
	
	newmemcpy(ibuf, salt + 8 * 16, 8 * 16);
	for (i = 0; i < 8; i++)
		ibuf[8 * 5 + i] = 0x80000000;
	memset(ibuf + 8 * 6, 0x00, 8 * 36);
	for (i = 0; i < 8; i++)
		ibuf[8 * 15 + i] = 0x000004a0;
	
	for (i = 0; i < 8; i++)
		obuf[8 * 8 + i] = 0x80000000;
	memset(obuf + 8 * 9, 0x00, 8 * 24);
	for (i = 0; i < 8; i++)
		obuf[8 * 15 + i] = 0x00000300;
	
	for (i = 0; i < 4; i++) {
		newmemcpy(obuf, istate, 8 * 32);
		ibuf[8 * 4 + 0] = i + 1;
		ibuf[8 * 4 + 1] = i + 1;
		ibuf[8 * 4 + 2] = i + 1;
		ibuf[8 * 4 + 3] = i + 1;
		ibuf[8 * 4 + 4] = i + 1;
		ibuf[8 * 4 + 5] = i + 1;
		ibuf[8 * 4 + 6] = i + 1;
		ibuf[8 * 4 + 7] = i + 1;
		sha256_transform_8way(obuf, ibuf, 0);
		
		newmemcpy(ostate2, ostate, 8 * 32);
		sha256_transform_8way(ostate2, obuf, 0);
		for (j = 0; j < 8 * 8; j++)
			output[8 * 8 * i + j] = swab32(ostate2[j]);
	}
}

static inline void PBKDF2_SHA256_128_32_8way(uint32_t *tstate,
	uint32_t *ostate, const uint32_t *salt, uint32_t *output)
{
	uint32_t _ALIGN(32) buf[8 * 16];
	int i;
	
	sha256_transform_8way(tstate, salt, 1);
	sha256_transform_8way(tstate, salt + 8 * 16, 1);
	sha256_transform_8way(tstate, finalblk_8way, 0);
	
	newmemcpy(buf, tstate, 8 * 32);
	for (i = 0; i < 8; i++)
		buf[8 * 8 + i] = 0x80000000;
	memset(buf + 8 * 9, 0x00, 8 * 24);
	for (i = 0; i < 8; i++)
		buf[8 * 15 + i] = 0x00000300;
	sha256_transform_8way(ostate, buf, 0);
	
	for (i = 0; i < 8 * 8; i++)
		output[i] = swab32(ostate[i]);
}

#endif /* HAVE_SHA256_8WAY */


#if defined(USE_ASM) && defined(__x86_64__)

#define SCRYPT_MAX_WAYS 12
#define HAVE_SCRYPT_3WAY 1
int scrypt_best_throughput();
void scrypt_core(uint32_t *X, uint32_t *V, int N);
void scrypt_core_3way(uint32_t *X, uint32_t *V, int N);
#if defined(USE_AVX2)
#undef SCRYPT_MAX_WAYS
#define SCRYPT_MAX_WAYS 24
#define HAVE_SCRYPT_6WAY 1
void scrypt_core_6way(uint32_t *X, uint32_t *V, int N);
#endif

#elif defined(USE_ASM) && defined(__i386__)

#define SCRYPT_MAX_WAYS 4
#define scrypt_best_throughput() 1
void scrypt_core(uint32_t *X, uint32_t *V, int N);

#elif defined(USE_ASM) && defined(__arm__) && defined(__APCS_32__)

void scrypt_core(uint32_t *X, uint32_t *V, int N);
#if defined(__ARM_NEON)
#undef HAVE_SHA256_4WAY
#define SCRYPT_MAX_WAYS 3
#define HAVE_SCRYPT_3WAY 1
#define scrypt_best_throughput() 3
void scrypt_core_3way(uint32_t *X, uint32_t *V, int N);
#endif

#elif defined(__aarch64__)

#include <stdint.h>
#include <arm_neon.h>

#undef HAVE_SHA256_4WAY
#define SCRYPT_MAX_WAYS 1
//#define HAVE_SCRYPT_2WAY 1
#define scrypt_best_throughput() 1

//simplified & inlinable neon version of memcpy. "128-bit" copying.
static inline void newmemcpy(uint32_t *dstp, const uint32_t *srcp, uint len)
{
	uint32x4_t *dst = (uint32x4_t *) dstp;
	uint32x4_t *src = (uint32x4_t *) srcp;
	uint i;

	for(i = 0; i < (len / sizeof(uint32x4_t)); i++)
		*dst++ = *src++;
}

//simplified & inlinable neon version of memcpy with "tail" handling.
static inline void newmemcpytail(uint32_t *dstp, const uint32_t *srcp, uint len)
{
	uint32x4_t *dst = (uint32x4_t *) dstp;
	uint32x4_t *src = (uint32x4_t *) srcp;
	uint i, tail;

	for(i = 0; i < (len / sizeof(uint32x4_t)); i++)
		*dst++ = *src++;

	tail = len & (sizeof(uint32x4_t) - 1);
	//if(tail) { //one instance requires this
		uchar *dstb = (uchar *) dstp;
		uchar *srcb = (uchar *) srcp;

		for(i = len - tail; i < len; i++)
			dstb[i] = srcb[i];
	//}
}

// Obsolete variables used in sha256 steps
/*static const uint32_t sha256_h[ 8] = {
	0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
	0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19
};*/

/*static uint32_t bufouterpad[16] = {
	0, 0, 0, 0,
	0, 0, 0, 0,
	0x80000000, 0, 0, 0, 
	0, 0, 0, 0x00000300
};*/
/*
static uint32_t finalblock[48] = {
	0, 0, 0, 0,
	0, 0, 0, 0,
	0, 0, 0, 0,
	0, 0, 0, 0,
	0, 0, 0, 0,
	0, 0, 0, 0,
	0, 0, 0, 0,
	0, 0, 0, 0,
	0x00000001, 0x80000000, 0, 0, 
	0, 0, 0, 0, 
	0, 0, 0, 0, 
	0, 0, 0, 0x00000620
};*/

/*static uint32_t pad[16] = {
	0, 0, 0, 0, 0x80000000, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0x00000280
};

static uint32_t pad2[16] = {
	0, 0, 0, 0,
	0, 0, 0, 0,
	0x5c5c5c5c, 0x5c5c5c5c, 0x5c5c5c5c, 0x5c5c5c5c,
	0x5c5c5c5c, 0x5c5c5c5c, 0x5c5c5c5c, 0x5c5c5c5c,
};

static uint32_t pad3[16] = {
	0, 0, 0, 0,
	0, 0, 0, 0,
	0x36363636, 0x36363636, 0x36363636, 0x36363636,
	0x36363636, 0x36363636, 0x36363636, 0x36363636,
};*/

typedef struct uint32x4x8_t
{
  uint32x4_t val[8];
} uint32x4x8_t __attribute__((__aligned__(16)));

static const uint32x4x2_t sha256_h_neon = {
	0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
	0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19
};

static const uint32x4x4_t k0 = {
	0x428A2F98, 0x71374491, 0xB5C0FBCF, 0xE9B5DBA5,
	0x3956C25B, 0x59F111F1, 0x923F82A4, 0xAB1C5ED5,
	0xD807AA98, 0x12835B01, 0x243185BE, 0x550C7DC3,
	0x72BE5D74, 0x80DEB1FE, 0x9BDC06A7, 0xC19BF174,
};

static const uint32x4x4_t k4 = {
	0xE49B69C1, 0xEFBE4786, 0x0FC19DC6, 0x240CA1CC,
	0x2DE92C6F, 0x4A7484AA, 0x5CB0A9DC, 0x76F988DA,
	0x983E5152, 0xA831C66D, 0xB00327C8, 0xBF597FC7,
	0xC6E00BF3, 0xD5A79147, 0x06CA6351, 0x14292967,
};

static const uint32x4x4_t k8 = {
	0x27B70A85, 0x2E1B2138, 0x4D2C6DFC, 0x53380D13,
	0x650A7354, 0x766A0ABB, 0x81C2C92E, 0x92722C85,
	0xA2BFE8A1, 0xA81A664B, 0xC24B8B70, 0xC76C51A3,
	0xD192E819, 0xD6990624, 0xF40E3585, 0x106AA070,
};

static const uint32x4x4_t kc = {
	0x19A4C116, 0x1E376C08, 0x2748774C, 0x34B0BCB5,
	0x391C0CB3, 0x4ED8AA4A, 0x5B9CCA4F, 0x682E6FF3,
	0x748F82EE, 0x78A5636F, 0x84C87814, 0x8CC70208,
	0x90BEFFFA, 0xA4506CEB, 0xBEF9A3F7, 0xC67178F2,
};

/*static inline void sha256_init_armv8(uint32_t *state)
{
	newmemcpy(state, sha256_h, 32);
}*/

#define Rx(T0, T1, K, W0, W1, W2, W3)      \
	W0 = vsha256su0q_u32( W0, W1 );    \
	ddtmp = dd.val[ 0];                           \
	T1 = vaddq_u32( W1, K );           \
	dd.val[ 0] = vsha256hq_u32( dd.val[ 0], dd.val[ 1], T0 );  \
	dd.val[ 1] = vsha256h2q_u32( dd.val[ 1], ddtmp, T0 ); \
	W0 = vsha256su1q_u32( W0, W2, W3 );

#define Ry(T0, T1, K, W1)                  \
	ddtmp = dd.val[ 0];                           \
	T1 = vaddq_u32( W1, K  );          \
	dd.val[ 0] = vsha256hq_u32( dd.val[ 0], dd.val[ 1], T0 );  \
	dd.val[ 1] = vsha256h2q_u32( dd.val[ 1], ddtmp, T0 );

#define Rz(T0)                             \
	ddtmp = dd.val[ 0];                       	   \
	dd.val[ 0] = vsha256hq_u32( dd.val[ 0], dd.val[ 1], T0 );  \
	dd.val[ 1] = vsha256h2q_u32( dd.val[ 1], ddtmp, T0 );

#define __swap32gen(x)							\
    (__uint32_t)(((__uint32_t)(x) & 0xff) << 24 |			\
    ((__uint32_t)(x) & 0xff00) << 8 | ((__uint32_t)(x) & 0xff0000) >> 8 |\
    ((__uint32_t)(x) & 0xff000000) >> 24)

//based on sha2armv8.c in new vrm wallet. Minor performance gain from inlineable shrunken code.
static void inline sha256_transform_armv8(uint32_t state[ 8], const uint32_t data[16])
{
	static uint32x4_t w0, w1, w2, w3, ddtmp;
	static uint32x4x2_t dd, sta;
	static uint32x4_t t0, t1;

	/* load state */
	sta.val[ 0] = vld1q_u32(&state[ 0]);
	sta.val[ 1] = vld1q_u32(&state[ 4]);
 
	/* load message */
	w0 = vld1q_u32(data);
	w1 = vld1q_u32(data + 4);
	t0 = vaddq_u32(w0, k0.val[ 0]);
	w2 = vld1q_u32(data + 8);
	dd = sta;
	w3 = vld1q_u32(data + 12);

	/*if (__builtin_expect(swap, 0)) { moved to sha256 compress function
		w0 = vreinterpretq_u32_u8(vrev32q_u8(vreinterpretq_u8_u32(w0)));
		w1 = vreinterpretq_u32_u8(vrev32q_u8(vreinterpretq_u8_u32(w1)));
		w2 = vreinterpretq_u32_u8(vrev32q_u8(vreinterpretq_u8_u32(w2)));
		w3 = vreinterpretq_u32_u8(vrev32q_u8(vreinterpretq_u8_u32(w3)));
	}*/

	//dd.val[ 1] = s1;

	/* perform rounds of four */
	Rx(t0, t1, k0.val[ 1], w0, w1, w2, w3);
	Rx(t1, t0, k0.val[ 2], w1, w2, w3, w0);
	Rx(t0, t1, k0.val[ 3], w2, w3, w0, w1);
	Rx(t1, t0, k4.val[ 0], w3, w0, w1, w2);
	Rx(t0, t1, k4.val[ 1], w0, w1, w2, w3);
	Rx(t1, t0, k4.val[ 2], w1, w2, w3, w0);
	Rx(t0, t1, k4.val[ 3], w2, w3, w0, w1);
	Rx(t1, t0, k8.val[ 0], w3, w0, w1, w2);
	Rx(t0, t1, k8.val[ 1], w0, w1, w2, w3);
	Rx(t1, t0, k8.val[ 2], w1, w2, w3, w0);
	Rx(t0, t1, k8.val[ 3], w2, w3, w0, w1);
	Rx(t1, t0, kc.val[ 0], w3, w0, w1, w2);
	Ry(t0, t1, kc.val[ 1], w1);
	Ry(t1, t0, kc.val[ 2], w2);
	Ry(t0, t1, kc.val[ 3], w3);
	Rz(t1);

	/* update state */
	sta.val[ 0] = vaddq_u32(sta.val[ 0], dd.val[ 0]);
	sta.val[ 1] = vaddq_u32(sta.val[ 1], dd.val[ 1]);

	/* save state */
	vst1q_u32(&state[ 0], sta.val[ 0]);
	vst1q_u32(&state[ 4], sta.val[ 1]);
}

static void __attribute__((cold)) __attribute__ ((noinline)) sha256_transform_armv8_init(uint32_t state[ 8], const uint32_t data[16])
{
	static uint32x4_t w0, w1, w2, w3, ddtmp;
	static uint32x4x2_t dd, sta;
	static uint32x4_t t0, t1;

	/* load message */
	w0 = vld1q_u32(data);
	w1 = vld1q_u32(data + 4);
	t0 = vaddq_u32(w0, k0.val[ 0]);
	w2 = vld1q_u32(data + 8);
	w3 = vld1q_u32(data + 12);

	/* initialize t0, dd.val[ 0], dd.val[ 1] */
 
	dd = sha256_h_neon;
	//dd.val[ 1] = s1;

	/* perform rounds of four */
	Rx(t0, t1, k0.val[ 1], w0, w1, w2, w3);
	Rx(t1, t0, k0.val[ 2], w1, w2, w3, w0);
	Rx(t0, t1, k0.val[ 3], w2, w3, w0, w1);
	Rx(t1, t0, k4.val[ 0], w3, w0, w1, w2);
	Rx(t0, t1, k4.val[ 1], w0, w1, w2, w3);
	Rx(t1, t0, k4.val[ 2], w1, w2, w3, w0);
	Rx(t0, t1, k4.val[ 3], w2, w3, w0, w1);
	Rx(t1, t0, k8.val[ 0], w3, w0, w1, w2);
	Rx(t0, t1, k8.val[ 1], w0, w1, w2, w3);
	Rx(t1, t0, k8.val[ 2], w1, w2, w3, w0);
	Rx(t0, t1, k8.val[ 3], w2, w3, w0, w1);
	Rx(t1, t0, kc.val[ 0], w3, w0, w1, w2);
	Ry(t0, t1, kc.val[ 1], w1);
	Ry(t1, t0, kc.val[ 2], w2);
	Ry(t0, t1, kc.val[ 3], w3);
	Rz(t1);

	/* update state */
	sta.val[ 0] = vaddq_u32(sha256_h_neon.val[ 0], dd.val[ 0]);
	sta.val[ 1] = vaddq_u32(sha256_h_neon.val[ 1], dd.val[ 1]);

	/* save state */
	vst1q_u32(&state[ 0], sta.val[ 0]);
	vst1q_u32(&state[ 4], sta.val[ 1]);
}

static void inline sha256_transform_80_128_armv8(uint32_t *state, const uint32_t *data, const uint32_t *tstate, uint32_t *output, bool finalstep)
{
	uint32x4_t w0, w1, w2, w3, ddtmp;
	uint32x4x2_t dd, sta;
	uint32x4_t t0, t1;

	/* load state */
	sta.val[ 0] = vld1q_u32(&tstate[ 0]);
	sta.val[ 1] = vld1q_u32(&tstate[ 4]);
	dd = sta;
	/* load message */
	w0 = vld1q_u32(data);
	w1 = vld1q_u32(data + 4);
	t0 = vaddq_u32(w0, k0.val[ 0]);
	w2 = vld1q_u32(data + 8);
	w3 = vld1q_u32(data + 12);

	/* initialize t0, dd.val[ 0], dd.val[ 1] */
 
	//dd.val[ 1] = s1;

	/* perform rounds of four */
	Rx(t0, t1, k0.val[ 1], w0, w1, w2, w3);
	Rx(t1, t0, k0.val[ 2], w1, w2, w3, w0);
	Rx(t0, t1, k0.val[ 3], w2, w3, w0, w1);
	Rx(t1, t0, k4.val[ 0], w3, w0, w1, w2);
	Rx(t0, t1, k4.val[ 1], w0, w1, w2, w3);
	Rx(t1, t0, k4.val[ 2], w1, w2, w3, w0);
	Rx(t0, t1, k4.val[ 3], w2, w3, w0, w1);
	Rx(t1, t0, k8.val[ 0], w3, w0, w1, w2);
	Rx(t0, t1, k8.val[ 1], w0, w1, w2, w3);
	Rx(t1, t0, k8.val[ 2], w1, w2, w3, w0);
	Rx(t0, t1, k8.val[ 3], w2, w3, w0, w1);
	Rx(t1, t0, kc.val[ 0], w3, w0, w1, w2);
	Ry(t0, t1, kc.val[ 1], w1);
	Ry(t1, t0, kc.val[ 2], w2);
	Ry(t0, t1, kc.val[ 3], w3);
	Rz(t1);

	/* update state */
	sta.val[ 0] = vaddq_u32(sta.val[ 0], dd.val[ 0]);
	sta.val[ 1] = vaddq_u32(sta.val[ 1], dd.val[ 1]);

	/* save state */
	if(!finalstep) {
		vst1q_u32(&state[ 0], sta.val[ 0]);
		vst1q_u32(&state[ 4], sta.val[ 1]);
	} else {
		sta.val[ 0] = vreinterpretq_u32_u8(vrev32q_u8(vreinterpretq_u8_u32(sta.val[ 0])));
		sta.val[ 1] = vreinterpretq_u32_u8(vrev32q_u8(vreinterpretq_u8_u32(sta.val[ 1])));
		vst1q_u32(output + 0, sta.val[ 0]);
		vst1q_u32(output + 4, sta.val[ 1]);
	}
}

// Not a true compress function. Last block is not reversed. Customised for specific use.
static void inline sha256_compress_armv8(uint32_t *state, const uint32_t *data, int blocks, uint32_t *output, bool finalstep)
{
	static uint32x4_t w0, w1, w2, w3, ddtmp;
	static uint32x4x2_t dd, sta;
	static uint32x4_t t0, t1;

	/* load state */
	sta.val[ 0] = vld1q_u32(&state[ 0]);
	sta.val[ 1] = vld1q_u32(&state[ 4]);

while (blocks)
      {
 
	/* load message */
	w0 = vld1q_u32(data);
	w1 = vld1q_u32(data + 4);
	dd = sta;
	w2 = vld1q_u32(data + 8);
	w3 = vld1q_u32(data + 12);

	if (blocks != 1) {
		w0 = vreinterpretq_u32_u8(vrev32q_u8(vreinterpretq_u8_u32(w0)));
		w1 = vreinterpretq_u32_u8(vrev32q_u8(vreinterpretq_u8_u32(w1)));
		w2 = vreinterpretq_u32_u8(vrev32q_u8(vreinterpretq_u8_u32(w2)));
		w3 = vreinterpretq_u32_u8(vrev32q_u8(vreinterpretq_u8_u32(w3)));
	}

	/* initialize t0, dd.val[ 0], dd.val[ 1] */
	t0 = vaddq_u32(w0, k0.val[ 0]);
 
	//dd.val[ 1] = s1;

	/* perform rounds of four */
	Rx(t0, t1, k0.val[ 1], w0, w1, w2, w3);
	Rx(t1, t0, k0.val[ 2], w1, w2, w3, w0);
	Rx(t0, t1, k0.val[ 3], w2, w3, w0, w1);
	Rx(t1, t0, k4.val[ 0], w3, w0, w1, w2);
	Rx(t0, t1, k4.val[ 1], w0, w1, w2, w3);
	Rx(t1, t0, k4.val[ 2], w1, w2, w3, w0);
	Rx(t0, t1, k4.val[ 3], w2, w3, w0, w1);
	Rx(t1, t0, k8.val[ 0], w3, w0, w1, w2);
	Rx(t0, t1, k8.val[ 1], w0, w1, w2, w3);
	Rx(t1, t0, k8.val[ 2], w1, w2, w3, w0);
	Rx(t0, t1, k8.val[ 3], w2, w3, w0, w1);
	Rx(t1, t0, kc.val[ 0], w3, w0, w1, w2);
	Ry(t0, t1, kc.val[ 1], w1);
	Ry(t1, t0, kc.val[ 2], w2);
	Ry(t0, t1, kc.val[ 3], w3);
	Rz(t1);

	/* update state */
	sta.val[ 0] = vaddq_u32(sta.val[ 0], dd.val[ 0]);
	sta.val[ 1] = vaddq_u32(sta.val[ 1], dd.val[ 1]);

      data += 16;
      blocks--;
}
	/* save state */
	vst1q_u32(&state[ 0], sta.val[ 0]);
	vst1q_u32(&state[ 4], sta.val[ 1]);

	/* save state */
	if(!finalstep) {
		vst1q_u32(&state[ 0], sta.val[ 0]);
		vst1q_u32(&state[ 4], sta.val[ 1]);
	} else {
		sta.val[ 0] = vreinterpretq_u32_u8(vrev32q_u8(vreinterpretq_u8_u32(sta.val[ 0])));
		sta.val[ 1] = vreinterpretq_u32_u8(vrev32q_u8(vreinterpretq_u8_u32(sta.val[ 1])));
		vst1q_u32(output + 0, sta.val[ 0]);
		vst1q_u32(output + 4, sta.val[ 1]);
	}
}

static void __attribute__((cold)) __attribute__ ((noinline)) HMAC_SHA256_80_init_armv8(const uint32_t *key,
	uint32_t *tstate, uint32_t *ostate, uint32_t numways)
{
	//uint32_t ihash[ 8];
	//uint32_t pad[16];
	//size_t numkeys = (sizeof(key)/sizeof(key[ 0]));
	uint32_t pad[48] = {
	0, 0, 0, 0, 0x80000000, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0x00000280,
	0, 0, 0, 0,
	0, 0, 0, 0,
	0x5c5c5c5c, 0x5c5c5c5c, 0x5c5c5c5c, 0x5c5c5c5c,
	0x5c5c5c5c, 0x5c5c5c5c, 0x5c5c5c5c, 0x5c5c5c5c,
	0, 0, 0, 0,
	0, 0, 0, 0,
	0x36363636, 0x36363636, 0x36363636, 0x36363636,
	0x36363636, 0x36363636, 0x36363636, 0x36363636,
	};
/*
	uint32_t pad2[16] = {
	0, 0, 0, 0,
	0, 0, 0, 0,
	0x5c5c5c5c, 0x5c5c5c5c, 0x5c5c5c5c, 0x5c5c5c5c,
	0x5c5c5c5c, 0x5c5c5c5c, 0x5c5c5c5c, 0x5c5c5c5c,
	};

	uint32_t pad3[16] = {
	0, 0, 0, 0,
	0, 0, 0, 0,
	0x36363636, 0x36363636, 0x36363636, 0x36363636,
	0x36363636, 0x36363636, 0x36363636, 0x36363636,
	};*/

	int i;
	while (numways)
	{
	/* tstate is assumed to contain the midstate of key */
	newmemcpy(pad, key + 16, 16);
	//newmemcpy(pad + 4, keypad, 48);
	sha256_transform_armv8(tstate, pad);
	//newmemcpy(ihash, tstate, 32);

	uint32x4_t *dst = (uint32x4_t *) &pad[16];
	uint32x4_t *dst2 = (uint32x4_t *) tstate;
	*dst++ = *dst2++ ^ 0x5c5c5c5c;	*dst++ = *dst2++ ^ 0x5c5c5c5c;

	//sha256_init_armv8(ostate);
/*	for (i = 0; i < 8; i++)
		pad2[i] = tstate[i] ^ 1549556828;*/
	/*for (; i < 16; i++)
		pad[i] = 0x5c5c5c5c;*/
	sha256_transform_armv8_init(ostate, &pad[16]);

	//sha256_init_armv8(tstate);
	for (i = 0; i < 8; i++)
		pad[i+32] = tstate[i] ^ 0x36363636;
	/*for (; i < 16; i++)
		pad[i] = 0x36363636;*/
	sha256_transform_armv8_init(tstate, &pad[32]);
	key += 20;
	ostate += 8;
	tstate += 8;
	numways--;
	}
}

static void __attribute__((noinline)) __attribute__((cold)) PBKDF2_SHA256_80_128_armv8(const uint32_t *tstate,
	const uint32_t *ostate, const uint32_t *salt, uint32_t *output)
{
	uint32_t istate[ 8], ostate2[ 8];
	/*uint32_t ibuf[16], obuf[16];*/

	uint32_t ibuf[16] = {
	0, 0, 0, 0,
	0, 0x80000000, 0, 0,
	0, 0, 0, 0, 
	0, 0, 0, 0x000004a0
	};
	uint32_t bufouterpad[16] = {
	0, 0, 0, 0,
	0, 0, 0, 0,
	0x80000000, 0, 0, 0, 
	0, 0, 0, 0x00000300
	};
	int i, j;

	//newmemcpy(istate, tstate, 32);
	sha256_transform_80_128_armv8(istate, salt, tstate, output, false);
	
	newmemcpy(ibuf, salt + 16, 16);
	//newmemcpytail(ibuf + 5, innerpad, 44);
	//newmemcpy(obuf + 8, outerpad, 32);

	for (i = 0; i < 4; i++) {
	//newmemcpy(obuf, istate, 32);
		ibuf[ 4] = i + 1;
	//sha256_transform_80_128_armv8(obuf, ibuf, istate);
		sha256_transform_80_128_armv8(bufouterpad, ibuf, istate, output, false);
	asm("":::"memory");
	//newmemcpy(ostate2, ostate, 32);
		sha256_transform_80_128_armv8(ostate2, bufouterpad, ostate, output, true);
		/*for (j = 0; j < 8; j++)
			output[8 * i + j] = __builtin_bswap32(ostate2[j]);*/
		output+=8;
	}
}

static __attribute__ ((noinline)) __attribute__((cold)) void PBKDF2_SHA256_128_32_armv8(uint32_t *tstate, uint32_t *ostate,
	const uint32_t *salt, uint32_t *output, uint32_t numways)
{
	//uint32_t buf[16];
	//uint32_t blocks[48];
	uint32_t finalblock[48] = {
	0, 0, 0, 0,
	0, 0, 0, 0,
	0, 0, 0, 0,
	0, 0, 0, 0,
	0, 0, 0, 0,
	0, 0, 0, 0,
	0, 0, 0, 0,
	0, 0, 0, 0,
	0x00000001, 0x80000000, 0, 0, 
	0, 0, 0, 0, 
	0, 0, 0, 0, 
	0, 0, 0, 0x00000620
	};
	uint32_t bufouterpad[16] = {
	0, 0, 0, 0,
	0, 0, 0, 0,
	0x80000000, 0, 0, 0, 
	0, 0, 0, 0x00000300
	};
	//int i;
	while (numways)
	{
	//newmemcpy(blocks, salt, 128);
	//newmemcpy(blocks + 32, finalblk, 64);
	newmemcpy(finalblock, salt, 128);

	//printf("0x%08x 0x%08x\n", finalblk[15], __builtin_bswap32(finalblk[15]));
	
	sha256_compress_armv8(tstate, finalblock, 3, output, false);

/*	sha256_transform_armv8(tstate, salt, 1);
	sha256_transform_armv8(tstate, salt + 16, 1);
	sha256_transform_armv8(tstate, finalblk, 0);*/
	//newmemcpy(buf, tstate, 32);
	newmemcpy(bufouterpad, tstate, 32);
	//newmemcpy(buf + 8, outerpad, 32);

	sha256_compress_armv8(ostate, bufouterpad, 1, output, true);
	/*for (i = 0; i < 8; i++)
		output[i] = __builtin_bswap32(ostate[i]);*/
	salt += 32;
	ostate += 8;
	tstate += 8;
	output += 8;
	numways--;
	}
}

static inline void __attribute__((hot)) scryptNsave_cycle(uint32x4x8_t *B, uint32_t *restrict V, uint32_t thr_id, uint32_t totalthreads)
{
	//uint32_t __attribute__((__aligned__(16))) x[16];

	register uint32_t x00 asm("w8"),x01 asm("w12"),x02 asm("w16"),x03 asm("w21"),x04 asm("w9"),x05 asm("w13"),x06 asm("w17"),x07 asm("w20"),x08 asm("w10"),x09 asm("w14"),x10 asm("w18"),x11 asm("w22"),x12 asm("w11"),x13 asm("w15"),x14 asm("w19"),x15 asm("w23"),x16 asm("w24");
	register uint32_t tmp1 asm("w25"), tmp2 asm("w26"), tmp3 asm("w27"), tmp4 asm("w28");

	register uint32x4_t one asm("v1");
	register uint32x4_t two asm("v2");
	register uint32x4_t three asm("v3");
	register uint32x4_t four asm("v4");

	register uint32x4_t five asm("v5");
	register uint32x4_t six asm("v6");
	register uint32x4_t seven asm("v7");
	register uint32x4_t eight asm("v8");

	// Discourage unnecessary register flushes by indicating register variables
	one = B->val[ 0];
	two = B->val[ 1];
	three = B->val[ 2];
	four = B->val[ 3];

	five = B->val[ 4];
	six = B->val[ 5];
	seven = B->val[ 6];
	eight = B->val[ 7];

	register uint32x4_t nine asm("v9");
	register uint32x4_t ten asm("v10");
	register uint32x4_t eleven asm("v11");
	register uint32x4_t twelve asm("v12");

	register uint32x4_t thirteen asm("v13");
	register uint32x4_t fourteen asm("v14");
	register uint32x4_t fifteen asm("v15");
	register uint32x4_t sixteen asm("v16");

	nine = vmovq_n_u32(0);
	ten = vmovq_n_u32(0);
	eleven = vmovq_n_u32(0);
	twelve = vmovq_n_u32(0);

	thirteen = vmovq_n_u32(0);
	fourteen = vmovq_n_u32(0);
	fifteen = vmovq_n_u32(0);
	sixteen = vmovq_n_u32(0);

	register uint32_t *Vptr = V;

	totalthreads *= 32;

	asm volatile(
		"sha256su0 %[DST].4s, %[DST].4s" "\n"
		: [DST] "+w" (ten)
	);

	// Save loop
	for (; Vptr < &V[1048576 * totalthreads]; Vptr += totalthreads) {
/*
	asm volatile(
		"aese %[DST].16b, %[DST].16b" "\n"
		: [DST] "+w" (nine)
	);*/
	//nine = veorq_u32(one, five);
	asm volatile(
		"eor %[DST].16b, %[SRC1].16b, %[SRC2].16b" "\n"
		: [DST] "=w" (nine)
		: [SRC1] "w" (one), [SRC2] "w" (five)
	);
	//ten = veorq_u32(two, six);
	asm volatile(
		"eor %[DST].16b, %[SRC1].16b, %[SRC2].16b" "\n"
		: [DST] "=w" (ten)
		: [SRC1] "w" (two), [SRC2] "w" (six)
	);
	//eleven = veorq_u32(three, seven);
	asm volatile(
		"eor %[DST].16b, %[SRC1].16b, %[SRC2].16b" "\n"
		: [DST] "=w" (eleven)
		: [SRC1] "w" (three), [SRC2] "w" (seven)
	);
	//twelve = veorq_u32(four, eight);
	asm volatile(
		"eor %[DST].16b, %[SRC1].16b, %[SRC2].16b" "\n"
		: [DST] "=w" (twelve)
		: [SRC1] "w" (four), [SRC2] "w" (eight)
	);

 	asm volatile(
		"umov %w[X00], %[SRCA].s[0]" "\n"
		"umov %w[X01], %[SRCA].s[1]" "\n"
		"umov %w[X02], %[SRCA].s[2]" "\n"
		"umov %w[X03], %[SRCA].s[3]" "\n"
		"umov %w[X04], %[SRCB].s[0]" "\n"
		"umov %w[X05], %[SRCB].s[1]" "\n"
		"umov %w[X06], %[SRCB].s[2]" "\n"
		"umov %w[X07], %[SRCB].s[3]" "\n"
		"umov %w[X08], %[SRCC].s[0]" "\n"
		"umov %w[X09], %[SRCC].s[1]" "\n"
		"umov %w[X10], %[SRCC].s[2]" "\n"
		"umov %w[X11], %[SRCC].s[3]" "\n"
		"umov %w[X12], %[SRCD].s[0]" "\n"
		"umov %w[X13], %[SRCD].s[1]" "\n"
		"umov %w[X14], %[SRCD].s[2]" "\n"
		"umov %w[X15], %[SRCD].s[3]" "\n"
		: [X00] "=r" (x00), [X01] "=r" (x01), [X02] "=r" (x02), [X03] "=r" (x03),	\
		[X04] "=r" (x04), [X05] "=r" (x05), [X06] "=r" (x06), [X07] "=r" (x07),	\
		[X08] "=r" (x08), [X09] "=r" (x09), [X10] "=r" (x10), [X11] "=r" (x11),	\
		[X12] "=r" (x12), [X13] "=r" (x13), [X14] "=r" (x14), [X15] "=r" (x15)
		: [SRCA] "w" (nine), [SRCB] "w" (ten), [SRCC] "w" (eleven), [SRCD] "w" (twelve)
	);

#define ROR(a,b) a >> b | a << (32 - b)
#define QuadRound(a, b, c, d, a1, a2, b1, b2, c1, c2, d1, d2, rot)		\
	asm volatile("": : :"memory");	\
	(tmp1 = a1 + a2,	\
	tmp2 = b1 + b2,	\
	tmp3 = c1 + c2,	\
	tmp4 = d1 + d2),	\
	(a ^= ROR(tmp1, rot),	\
	b ^= ROR(tmp2, rot),	\
	c ^= ROR(tmp3, rot),	\
	d ^= ROR(tmp4, rot))
/*	vst1q_u32(Vptr, one);
	vst1q_u32(Vptr + 4, two);*/
	asm volatile(
		"str %q[DST1], [%[SRC]]" "\n"
		"str %q[DST2], [%[SRC],#16]" "\n"
		:
		: [DST1] "w" (one), [DST2] "w" (two), [SRC] "r" (Vptr)
	);
	// Operate on columns.
	QuadRound(x04, x09, x14, x03, x00, \
	x12, x05, x01, x10, x06, x15, x11, 25);

	QuadRound(x08, x13, x02, x07, x04, \
	x00, x09, x05, x14, x10, x03, x15, 23);

	QuadRound(x12, x01, x06, x11, x08, \
	x04, x13, x09, x02, x14, x07, x03, 19);

	QuadRound(x00, x05, x10, x15, x12, \
	x08, x01, x13, x06, x02, x11, x07, 14);
	/*asm volatile(
		"str %q[DST1], [%[SRC]]" "\n"
		"str %q[DST2], [%[SRC],#16]" "\n"
		:
		: [DST1] "w" (one), [DST2] "w" (two), [SRC] "r" (Vptr)
	);*/
	// Operate on rows.
	QuadRound(x01, x06, x11, x12, x00, \
	x03, x05, x04, x10, x09, x15, x14, 25);

	QuadRound(x02, x07, x08, x13, x01, \
	x00, x06, x05, x11, x10, x12, x15, 23);

	QuadRound(x03, x04, x09, x14, x02, \
	x01, x07, x06, x08, x11, x13, x12, 19);

	QuadRound(x00, x05, x10, x15, x03, \
	x02, x04, x07, x09, x08, x14, x13, 14);

	// Operate on columns.
	QuadRound(x04, x09, x14, x03, x00, \
	x12, x05, x01, x10, x06, x15, x11, 25);

	QuadRound(x08, x13, x02, x07, x04, \
	x00, x09, x05, x14, x10, x03, x15, 23);

	QuadRound(x12, x01, x06, x11, x08, \
	x04, x13, x09, x02, x14, x07, x03, 19);

	QuadRound(x00, x05, x10, x15, x12, \
	x08, x01, x13, x06, x02, x11, x07, 14);
	asm volatile(
		"str %q[DST1], [%[SRC],#32]" "\n"
		"str %q[DST2], [%[SRC],#48]" "\n"
		:
		: [DST1] "w" (three), [DST2] "w" (four), [SRC] "r" (Vptr)
	);
	/*vst1q_u32(Vptr + 8, three);
	vst1q_u32(Vptr + 12, four);*/
	// Operate on rows.
	QuadRound(x01, x06, x11, x12, x00, \
	x03, x05, x04, x10, x09, x15, x14, 25);

	QuadRound(x02, x07, x08, x13, x01, \
	x00, x06, x05, x11, x10, x12, x15, 23);

	QuadRound(x03, x04, x09, x14, x02, \
	x01, x07, x06, x08, x11, x13, x12, 19);

	QuadRound(x00, x05, x10, x15, x03, \
	x02, x04, x07, x09, x08, x14, x13, 14);
  
	// Operate on columns.
	QuadRound(x04, x09, x14, x03, x00, \
	x12, x05, x01, x10, x06, x15, x11, 25);

	QuadRound(x08, x13, x02, x07, x04, \
	x00, x09, x05, x14, x10, x03, x15, 23);

	QuadRound(x12, x01, x06, x11, x08, \
	x04, x13, x09, x02, x14, x07, x03, 19);

	QuadRound(x00, x05, x10, x15, x12, \
	x08, x01, x13, x06, x02, x11, x07, 14);
 	asm volatile(
		"str %q[SRCA], [%[SRC],#64]" "\n"
		"str %q[SRCB], [%[SRC],#80]" "\n"
		:
		: [SRCA] "w" (five), [SRCB] "w" (six), [SRC] "r" (Vptr)
	);
	/*vst1q_u32(Vptr + 16, five);
	vst1q_u32(Vptr + 20, six);*/
	// Operate on rows.
	QuadRound(x01, x06, x11, x12, x00, \
	x03, x05, x04, x10, x09, x15, x14, 25);

	QuadRound(x02, x07, x08, x13, x01, \
	x00, x06, x05, x11, x10, x12, x15, 23);

	QuadRound(x03, x04, x09, x14, x02, \
	x01, x07, x06, x08, x11, x13, x12, 19);

	QuadRound(x00, x05, x10, x15, x03, \
	x02, x04, x07, x09, x08, x14, x13, 14);

	// Operate on columns.
	QuadRound(x04, x09, x14, x03, x00, \
	x12, x05, x01, x10, x06, x15, x11, 25);

	QuadRound(x08, x13, x02, x07, x04, \
	x00, x09, x05, x14, x10, x03, x15, 23);

	QuadRound(x12, x01, x06, x11, x08, \
	x04, x13, x09, x02, x14, x07, x03, 19);

	QuadRound(x00, x05, x10, x15, x12, \
	x08, x01, x13, x06, x02, x11, x07, 14);
	asm volatile(
		"str %q[DST1], [%[SRC],#96]" "\n"
		"str %q[DST2], [%[SRC],#112]" "\n"
		:
		: [DST1] "w" (seven), [DST2] "w" (eight), [SRC] "r" (Vptr)
	);
	/*vst1q_u32(Vptr + 24, seven);
	vst1q_u32(Vptr + 28, eight);*/
	// Operate on rows.
	QuadRound(x01, x06, x11, x12, x00, \
	x03, x05, x04, x10, x09, x15, x14, 25);

	QuadRound(x02, x07, x08, x13, x01, \
	x00, x06, x05, x11, x10, x12, x15, 23);

	QuadRound(x03, x04, x09, x14, x02, \
	x01, x07, x06, x08, x11, x13, x12, 19);

	QuadRound(x00, x05, x10, x15, x03, \
	x02, x04, x07, x09, x08, x14, x13, 14);
/*

	// scalar to vector register copies are very slow.
	// Using struct destination can encourage GCC 8+ to use store/loads
	asm volatile(
		"stp %w[X00], %w[X01], [%[SRC]]" "\n"
		"stp %w[X02], %w[X03], [%[SRC],#8]" "\n"
		"stp %w[X04], %w[X05], [%[SRC],#16]" "\n"
		"stp %w[X06], %w[X07], [%[SRC],#24]" "\n"
		"stp %w[X08], %w[X09], [%[SRC],#32]" "\n"
		"stp %w[X10], %w[X11], [%[SRC],#40]" "\n"
		"stp %w[X12], %w[X13], [%[SRC],#48]" "\n"
		"ldp %q[SRCA], %q[SRCB], [%[SRC]]" "\n"
		"stp %w[X14], %w[X15], [%[SRC],#56]" "\n"
		"ldp %q[SRCC], %q[SRCD], [%[SRC],#32]" "\n"
		: [SRCA] "=w" (thirteen), [SRCB] "=w" (fourteen), [SRCC] "=w" (fifteen), [SRCD] "=w" (sixteen)
		: [X00] "r" (x00), [X01] "r" (x01), [X02] "r" (x02), [X03] "r" (x03),	\
		[X04] "r" (x04), [X05] "r" (x05), [X06] "r" (x06), [X07] "r" (x07),	\
		[X08] "r" (x08), [X09] "r" (x09), [X10] "r" (x10), [X11] "r" (x11),	\
		[X12] "r" (x12), [X13] "r" (x13), [X14] "r" (x14), [X15] "r" (x15), [SRC] "r" (x)
		:
	);
*/
 /*	asm volatile(
		"mov %[SRCA].s[0], %w[X00]" "\n"
		"mov %[SRCB].s[0], %w[X04]" "\n"
		"mov %[SRCC].s[0], %w[X08]" "\n"
		"mov %[SRCD].s[0], %w[X12]" "\n"
		"mov %[SRCA].s[1], %w[X01]" "\n"
		"mov %[SRCB].s[1], %w[X05]" "\n"
		"mov %[SRCC].s[1], %w[X09]" "\n"
		"mov %[SRCD].s[1], %w[X13]" "\n"
		"mov %[SRCA].s[2], %w[X02]" "\n"
		"mov %[SRCB].s[2], %w[X06]" "\n"
		"mov %[SRCC].s[2], %w[X10]" "\n"
		"mov %[SRCD].s[2], %w[X14]" "\n"
		"mov %[SRCB].s[3], %w[X07]" "\n"
		"mov %[SRCA].s[3], %w[X03]" "\n"
		"mov %[SRCC].s[3], %w[X11]" "\n"
		"mov %[SRCD].s[3], %w[X15]" "\n"
		: [SRCA] "=w" (thirteen), [SRCB] "=w" (fourteen), [SRCC] "=w" (fifteen), [SRCD] "=w" (sixteen)
		: [X00] "r" (x00), [X01] "r" (x01), [X02] "r" (x02), [X03] "r" (x03),	\
		[X04] "r" (x04), [X05] "r" (x05), [X06] "r" (x06), [X07] "r" (x07),	\
		[X08] "r" (x08), [X09] "r" (x09), [X10] "r" (x10), [X11] "r" (x11),	\
		[X12] "r" (x12), [X13] "r" (x13), [X14] "r" (x14), [X15] "r" (x15)
	);*/
 	asm volatile(
		"mov %[SRCA].s[0], %w[X00]" "\n"
		"mov %[SRCB].s[0], %w[X04]" "\n"
		"mov %[SRCC].s[0], %w[X08]" "\n"
		"mov %[SRCD].s[0], %w[X12]" "\n"
		"mov %[SRCA].s[1], %w[X01]" "\n"
		"mov %[SRCB].s[1], %w[X05]" "\n"
		"mov %[SRCC].s[1], %w[X09]" "\n"
		"mov %[SRCD].s[1], %w[X13]" "\n"
		"mov %[SRCA].s[2], %w[X02]" "\n"
		"mov %[SRCB].s[2], %w[X06]" "\n"
		"mov %[SRCC].s[2], %w[X10]" "\n"
		"mov %[SRCD].s[2], %w[X14]" "\n"
		"mov %[SRCB].s[3], %w[X07]" "\n"
		"mov %[SRCA].s[3], %w[X03]" "\n"
		"mov %[SRCC].s[3], %w[X11]" "\n"
		"mov %[SRCD].s[3], %w[X15]" "\n"
		: [SRCA] "=w" (thirteen), [SRCB] "=w" (fourteen), [SRCC] "=w" (fifteen), [SRCD] "=w" (sixteen)	\
		: [X00] "r" (x00), [X02] "r" (x02),	\
		[X04] "r" (x04), [X06] "r" (x06), [X08] "r" (x08),	\
		[X10] "r" (x10), [X12] "r" (x12), [X14] "r" (x14),
		[X01] "r" (x01), [X03] "r" (x03), [X05] "r" (x05),	\
		[X07] "r" (x07), [X09] "r" (x09), [X11] "r" (x11),	\
		[X13] "r" (x13), [X15] "r" (x15)
	);
/*
	asm volatile(
		"stp %w[X00], %w[X01], [%[SRC]]" "\n"
		"stp %w[X02], %w[X03], [%[SRC],#8]" "\n"
		"stp %w[X04], %w[X05], [%[SRC],#16]" "\n"
		"stp %w[X06], %w[X07], [%[SRC],#24]" "\n"
		"stp %w[X08], %w[X09], [%[SRC],#32]" "\n"
		"ldr %q[SRCA], [%[SRC]]" "\n"
		"stp %w[X10], %w[X11], [%[SRC],#40]" "\n"
		"ldr %q[SRCB], [%[SRC],#16]" "\n"
		"stp %w[X12], %w[X13], [%[SRC],#48]" "\n"
		"ldr %q[SRCC], [%[SRC],#32]" "\n"
		"stp %w[X14], %w[X15], [%[SRC],#56]" "\n"
		"ldr %q[SRCD], [%[SRC],#48]" "\n"
		: [SRCA] "=w" (thirteen), [SRCB] "=w" (fourteen), [SRCC] "=w" (fifteen), [SRCD] "=w" (sixteen)
		: [X00] "r" (x00), [X01] "r" (x01), [X02] "r" (x02), [X03] "r" (x03),	\
		[X04] "r" (x04), [X05] "r" (x05), [X06] "r" (x06), [X07] "r" (x07),	\
		[X08] "r" (x08), [X09] "r" (x09), [X10] "r" (x10), [X11] "r" (x11),	\
		[X12] "r" (x12), [X13] "r" (x13), [X14] "r" (x14), [X15] "r" (x15), [SRC] "r" (x)
		:
	);
  
 	asm volatile(
		"stp %w[X00], %w[X01], [%[SRC]]" "\n"
		"stp %w[X02], %w[X03], [%[SRC],#8]" "\n"
		"stp %w[X04], %w[X05], [%[SRC],#16]" "\n"
		"stp %w[X06], %w[X07], [%[SRC],#24]" "\n"
 		"mov %[SRCD].s[2], %w[X14]" "\n"
		"mov %[SRCC].s[0], %w[X08]" "\n"
		"mov %[SRCD].s[3], %w[X15]" "\n"
		"mov %[SRCC].s[2], %w[X10]" "\n"
		"mov %[SRCD].s[0], %w[X12]" "\n"
 		"mov %[SRCC].s[1], %w[X09]" "\n"
		"mov %[SRCD].s[1], %w[X13]" "\n"
		"ldr %q[SRCA], [%[SRC]]" "\n"
		"mov %[SRCC].s[3], %w[X11]" "\n"
		"ldr %q[SRCB], [%[SRC],#16]" "\n"
		: [SRCA] "=w" (thirteen), [SRCB] "=w" (fourteen), [SRCC] "=w" (fifteen), [SRCD] "=w" (sixteen)
		: [X00] "r" (x00), [X01] "r" (x01), [X02] "r" (x02), [X03] "r" (x03),	\
		[X04] "r" (x04), [X05] "r" (x05), [X06] "r" (x06), [X07] "r" (x07),	\
		[X08] "r" (x08), [X09] "r" (x09), [X10] "r" (x10), [X11] "r" (x11),	\
		[X12] "r" (x12), [X13] "r" (x13), [X14] "r" (x14), [X15] "r" (x15), [SRC] "r" (x)
		:
	);
  */
	one = vaddq_u32(nine, thirteen);
	two = vaddq_u32(ten, fourteen);
	three = vaddq_u32(eleven, fifteen);
	four = vaddq_u32(twelve, sixteen);



	// Working on right half
	five = veorq_u32(five, one);
	six = veorq_u32(six, two);
	seven = veorq_u32(seven, three);
	eight = veorq_u32(eight, four);

 	asm volatile(
		/*"mov %x[X00], %[SRCA].d[0]" "\n"
		"mov %x[X02], %[SRCA].d[1]" "\n"
		"mov %x[X04], %[SRCB].d[0]" "\n"
		"mov %x[X06], %[SRCB].d[1]" "\n"
		"mov %x[X08], %[SRCC].d[0]" "\n"
		"mov %x[X10], %[SRCC].d[1]" "\n"
		"mov %x[X12], %[SRCD].d[0]" "\n"
		"mov %x[X14], %[SRCD].d[1]" "\n"
		"lsr %x[X01], %x[X00], #32" "\n"
		"lsr %x[X03], %x[X02], #32" "\n"
		"lsr %x[X05], %x[X04], #32" "\n"
		"lsr %x[X07], %x[X06], #32" "\n"
		"lsr %x[X09], %x[X08], #32" "\n"
		"lsr %x[X11], %x[X10], #32" "\n"
		"lsr %x[X13], %x[X12], #32" "\n"
		"lsr %x[X15], %x[X14], #32" "\n"*/
		"umov %w[X00], %[SRCA].s[0]" "\n"
		"umov %w[X01], %[SRCA].s[1]" "\n"
		"umov %w[X02], %[SRCA].s[2]" "\n"
		"umov %w[X03], %[SRCA].s[3]" "\n"
		"umov %w[X04], %[SRCB].s[0]" "\n"
		"umov %w[X05], %[SRCB].s[1]" "\n"
		"umov %w[X06], %[SRCB].s[2]" "\n"
		"umov %w[X07], %[SRCB].s[3]" "\n"
		"umov %w[X08], %[SRCC].s[0]" "\n"
		"umov %w[X09], %[SRCC].s[1]" "\n"
		"umov %w[X10], %[SRCC].s[2]" "\n"
		"umov %w[X11], %[SRCC].s[3]" "\n"
		"umov %w[X12], %[SRCD].s[0]" "\n"
		"umov %w[X13], %[SRCD].s[1]" "\n"
		"umov %w[X14], %[SRCD].s[2]" "\n"
		"umov %w[X15], %[SRCD].s[3]" "\n"
		: [X00] "=r" (x00), [X01] "=r" (x01), [X02] "=r" (x02), [X03] "=r" (x03),	\
		[X04] "=r" (x04), [X05] "=r" (x05), [X06] "=r" (x06), [X07] "=r" (x07),	\
		[X08] "=r" (x08), [X09] "=r" (x09), [X10] "=r" (x10), [X11] "=r" (x11),	\
		[X12] "=r" (x12), [X13] "=r" (x13), [X14] "=r" (x14), [X15] "=r" (x15)
		: [SRCA] "w" (five), [SRCB] "w" (six), [SRCC] "w" (seven), [SRCD] "w" (eight) 
	);

	// Operate on columns.
	QuadRound(x04, x09, x14, x03, x00, \
	x12, x05, x01, x10, x06, x15, x11, 25);

	QuadRound(x08, x13, x02, x07, x04, \
	x00, x09, x05, x14, x10, x03, x15, 23);

	QuadRound(x12, x01, x06, x11, x08, \
	x04, x13, x09, x02, x14, x07, x03, 19);

	QuadRound(x00, x05, x10, x15, x12, \
	x08, x01, x13, x06, x02, x11, x07, 14);

	// Operate on rows.
	QuadRound(x01, x06, x11, x12, x00, \
	x03, x05, x04, x10, x09, x15, x14, 25);

	QuadRound(x02, x07, x08, x13, x01, \
	x00, x06, x05, x11, x10, x12, x15, 23);

	QuadRound(x03, x04, x09, x14, x02, \
	x01, x07, x06, x08, x11, x13, x12, 19);

	QuadRound(x00, x05, x10, x15, x03, \
	x02, x04, x07, x09, x08, x14, x13, 14);

	// Operate on columns.
	QuadRound(x04, x09, x14, x03, x00, \
	x12, x05, x01, x10, x06, x15, x11, 25);

	QuadRound(x08, x13, x02, x07, x04, \
	x00, x09, x05, x14, x10, x03, x15, 23);

	QuadRound(x12, x01, x06, x11, x08, \
	x04, x13, x09, x02, x14, x07, x03, 19);

	QuadRound(x00, x05, x10, x15, x12, \
	x08, x01, x13, x06, x02, x11, x07, 14);

	// Operate on rows.
	QuadRound(x01, x06, x11, x12, x00, \
	x03, x05, x04, x10, x09, x15, x14, 25);

	QuadRound(x02, x07, x08, x13, x01, \
	x00, x06, x05, x11, x10, x12, x15, 23);

	QuadRound(x03, x04, x09, x14, x02, \
	x01, x07, x06, x08, x11, x13, x12, 19);

	QuadRound(x00, x05, x10, x15, x03, \
	x02, x04, x07, x09, x08, x14, x13, 14);

	// Operate on columns.
	QuadRound(x04, x09, x14, x03, x00, \
	x12, x05, x01, x10, x06, x15, x11, 25);

	QuadRound(x08, x13, x02, x07, x04, \
	x00, x09, x05, x14, x10, x03, x15, 23);

	QuadRound(x12, x01, x06, x11, x08, \
	x04, x13, x09, x02, x14, x07, x03, 19);

	QuadRound(x00, x05, x10, x15, x12, \
	x08, x01, x13, x06, x02, x11, x07, 14);

	// Operate on rows.
	QuadRound(x01, x06, x11, x12, x00, \
	x03, x05, x04, x10, x09, x15, x14, 25);

	QuadRound(x02, x07, x08, x13, x01, \
	x00, x06, x05, x11, x10, x12, x15, 23);

	QuadRound(x03, x04, x09, x14, x02, \
	x01, x07, x06, x08, x11, x13, x12, 19);

	QuadRound(x00, x05, x10, x15, x03, \
	x02, x04, x07, x09, x08, x14, x13, 14);

	// Operate on columns.
	QuadRound(x04, x09, x14, x03, x00, \
	x12, x05, x01, x10, x06, x15, x11, 25);

	QuadRound(x08, x13, x02, x07, x04, \
	x00, x09, x05, x14, x10, x03, x15, 23);

	QuadRound(x12, x01, x06, x11, x08, \
	x04, x13, x09, x02, x14, x07, x03, 19);

	QuadRound(x00, x05, x10, x15, x12, \
	x08, x01, x13, x06, x02, x11, x07, 14);

	// Operate on rows.
	QuadRound(x01, x06, x11, x12, x00, \
	x03, x05, x04, x10, x09, x15, x14, 25);

	QuadRound(x02, x07, x08, x13, x01, \
	x00, x06, x05, x11, x10, x12, x15, 23);

	QuadRound(x03, x04, x09, x14, x02, \
	x01, x07, x06, x08, x11, x13, x12, 19);

	QuadRound(x00, x05, x10, x15, x03, \
	x02, x04, x07, x09, x08, x14, x13, 14);

#undef QuadRound
#undef ROR

 	asm volatile(
		"ins %[SRCA].s[0], %w[X00]" "\n"
		"ins %[SRCB].s[0], %w[X04]" "\n"
		"ins %[SRCC].s[0], %w[X08]" "\n"
		"ins %[SRCD].s[0], %w[X12]" "\n"
		"ins %[SRCA].s[1], %w[X01]" "\n"
		"ins %[SRCB].s[1], %w[X05]" "\n"
		"ins %[SRCC].s[1], %w[X09]" "\n"
		"ins %[SRCD].s[1], %w[X13]" "\n"
		"ins %[SRCA].s[2], %w[X02]" "\n"
		"ins %[SRCB].s[2], %w[X06]" "\n"
		"ins %[SRCC].s[2], %w[X10]" "\n"
		"ins %[SRCD].s[2], %w[X14]" "\n"
		"ins %[SRCB].s[3], %w[X07]" "\n"
		"ins %[SRCA].s[3], %w[X03]" "\n"
		"ins %[SRCC].s[3], %w[X11]" "\n"
		"ins %[SRCD].s[3], %w[X15]" "\n"
		: [SRCA] "=w" (thirteen), [SRCB] "=w" (fourteen), [SRCC] "=w" (fifteen), [SRCD] "=w" (sixteen)	\
		: [X00] "r" (x00), [X02] "r" (x02),	\
		[X04] "r" (x04), [X06] "r" (x06), [X08] "r" (x08),	\
		[X10] "r" (x10), [X12] "r" (x12), [X14] "r" (x14),
		[X01] "r" (x01), [X03] "r" (x03), [X05] "r" (x05),	\
		[X07] "r" (x07), [X09] "r" (x09), [X11] "r" (x11),	\
		[X13] "r" (x13), [X15] "r" (x15)
	);

	five = vaddq_u32(five, thirteen);
	six = vaddq_u32(six, fourteen);
	seven = vaddq_u32(seven, fifteen);
	eight = vaddq_u32(eight, sixteen);
	}

	B->val[ 0] = one;
	B->val[ 1] = two;
	B->val[ 2] = three;
	B->val[ 3] = four;

	B->val[ 4] = five;
	B->val[ 5] = six;
	B->val[ 6] = seven;
	B->val[ 7] = eight;
}

void printBits(size_t const size, uint32_t data, uint32_t sss)
{
	uint32_t ptr = data;
    unsigned char *b = (unsigned char*) &ptr;
    unsigned char byte;
    int i, j;

    for (i=size-1;i>=0;i--)
    {
        for (j=7;j>=0;j--)
        {
            byte = (b[i] >> j) & 1;
            printf("%u", byte);
        }
    }
    printf(" %u \n", sss);
}

static inline void __attribute__((hot)) scryptNread_cycle(uint32x4x8_t *B, uint32_t *restrict V, uint32_t thr_id, uint32_t totalthreads)
{
	register uint32_t x00 asm("w8"),x01 asm("w12"),x02 asm("w16"),x03 asm("w21"),x04 asm("w9"),x05 asm("w13"),x06 asm("w17"),x07 asm("w20"),x08 asm("w10"),x09 asm("w14"),x10 asm("w18"),x11 asm("w22"),x12 asm("w11"),x13 asm("w15"),x14 asm("w19"),x15 asm("w23"),x16 asm("w24");
	register uint32_t tmp1 asm("w25"), tmp2 asm("w26"), tmp3 asm("w27"), tmp4 asm("w28");

	register uint32_t i = B->val[ 4][ 0];
	totalthreads *= 32;
	i &= (uint32_t) 1048575;

	register uint32_t prefetchAND = 0x3ffffc;

	register uint32_t *Vptr = &V[i * totalthreads];

	register uint32x4_t one asm("v1");
	register uint32x4_t two asm("v2");
	register uint32x4_t three asm("v3");
	register uint32x4_t four asm("v4");

	register uint32x4_t five asm("v5");
	register uint32x4_t six asm("v6");
	register uint32x4_t seven asm("v7");
	register uint32x4_t eight asm("v8");

	// Discourage unnecessary register flushes by indicating register variables
	one = B->val[ 0];
	two = B->val[ 1];
	three = B->val[ 2];
	four = B->val[ 3];

	five = B->val[ 4];
	six = B->val[ 5];
	seven = B->val[ 6];
	eight = B->val[ 7];

	register uint32x4_t nine asm("v9");
	register uint32x4_t ten asm("v10");
	register uint32x4_t eleven asm("v11");
	register uint32x4_t twelve asm("v12");

	register uint32x4_t thirteen asm("v13");
	register uint32x4_t fourteen asm("v14");
	register uint32x4_t fifteen asm("v15");
	register uint32x4_t sixteen asm("v16");

	nine = vmovq_n_u32(0);
	ten = vmovq_n_u32(0);
	eleven = vmovq_n_u32(0);
	twelve = vmovq_n_u32(0);

	thirteen = vmovq_n_u32(0);
	fourteen = vmovq_n_u32(0);
	fifteen = vmovq_n_u32(0);
	sixteen = vmovq_n_u32(0);

	// Read loop
	for (i = 0; i < 1048576; i++) {
	/*asm volatile(
		"mov %[DST].16b, %[DST].16b" "\n"
		: [DST] "+w" (thirteen)
	);*/
	// five = vaddq_u32(five, thirteen);
	asm volatile(
		"add %[DSTE].4s, %[DSTE].4s, %[SRC].4s" "\n"
	//	"ldr %q[DSTA], [%[PTR]]" "\n"
		"ld1 { %[DSTA].4s, %[DSTB].4s, %[DSTC].4s, %[DSTD].4s }, [%[PTR]]" "\n"
		: [DSTA] "=w" (nine), [DSTB] "=w" (ten), [DSTC] "=w" (eleven), [DSTD] "=w" (twelve), [DSTE] "+w" (five)
		: [PTR] "r" (Vptr), [SRC] "w" (thirteen)
	);
	// six = vaddq_u32(six, fourteen);
	asm volatile(
		"add %[DSTB].4s, %[DSTB].4s, %[SRC].4s" "\n"
	//	"ldr %q[DSTA], [%[PTR],#16]" "\n"
		: /*[DSTA] "=w" (ten),*/ [DSTB] "+w" (six)
		: /*[PTR] "r" (Vptr), */[SRC] "w" (fourteen)
	);
	// seven = vaddq_u32(seven, fifteen);
	asm volatile(
		"add %[DSTB].4s, %[DSTB].4s, %[SRC].4s" "\n"
	//	"ldr %q[DSTA], [%[PTR],#32]" "\n"
	//	"nop" "\n"
		:/* [DSTA] "=w" (eleven), */[DSTB] "+w" (seven)
		:/* [PTR] "r" (Vptr), */[SRC] "w" (fifteen)
	);
	// eight = vaddq_u32(eight, sixteen);
	asm volatile(
		"add %[DSTB].4s, %[DSTB].4s, %[SRC].4s" "\n"
	//	"ldr %q[DSTA], [%[PTR],#48]" "\n"
		:/* [DSTA] "=w" (twelve), */[DSTB] "+w" (eight)
		:/* [PTR] "r" (Vptr), */[SRC] "w" (sixteen)
	);
 	// one = veorq_u32(one, nine);
	asm volatile(
		"eor %[DSTB].16b, %[DSTB].16b, %[SRC].16b" "\n"
		"ldr %q[DSTA], [%[PTR],#64] " "\n"
		: [DSTA] "=w" (thirteen), [DSTB] "+w" (one)
		: [PTR] "r" (Vptr), [SRC] "w" (nine)
	);
 	// two = veorq_u32(two, ten);
	asm volatile(
		"eor %[DSTB].16b, %[DSTB].16b, %[SRC].16b" "\n"
		"ldr %q[DSTA], [%[PTR],#80] " "\n"
		: [DSTA] "=w" (fourteen), [DSTB] "+w" (two)
		: [PTR] "r" (Vptr), [SRC] "w" (ten)
	);
	// three = veorq_u32(three, eleven);
	asm volatile(
		"eor %[DSTB].16b, %[DSTB].16b, %[SRC].16b" "\n"
		"ldr %q[DSTA], [%[PTR],#96] " "\n"
		: [DSTA] "=w" (fifteen), [DSTB] "+w" (three)
		: [PTR] "r" (Vptr), [SRC] "w" (eleven)
	);
	// four = veorq_u32(four, twelve);
	asm volatile(
		"eor %[DSTB].16b, %[DSTB].16b, %[SRC].16b" "\n"
		"ldr %q[DSTA], [%[PTR],#112] " "\n"
		: [DSTA] "=w" (sixteen), [DSTB] "+w" (four)
		: [PTR] "r" (Vptr), [SRC] "w" (twelve)
	);
	// five = veorq_u32(five, thirteen);
	asm volatile(
		"eor %[DST].16b, %[DST].16b, %[SRC].16b" "\n"
		: [DST] "+w" (five)
		: [SRC] "w" (thirteen)
	);
	// six = veorq_u32(six, fourteen);
	asm volatile(
		"eor %[DST].16b, %[DST].16b, %[SRC].16b" "\n"
		: [DST] "+w" (six)
		: [SRC] "w" (fourteen)
	);
	// seven = veorq_u32(seven, fifteen);
 	asm volatile(
		"eor %[DST].16b, %[DST].16b, %[SRC].16b" "\n"
		: [DST] "+w" (seven)
		: [SRC] "w" (fifteen)
	);
	// eight = veorq_u32(eight, sixteen);
	asm volatile(
		"eor %[DST].16b, %[DST].16b, %[SRC].16b" "\n"
		: [DST] "+w" (eight)
		: [SRC] "w" (sixteen)
	);
	// one = veorq_u32(one, five);
 	asm volatile(
		"eor %[DST].16b, %[DST].16b, %[SRC].16b" "\n"
		: [DST] "+w" (one)
		: [SRC] "w" (five)
	);
	// two = veorq_u32(two, six);
	asm volatile(
		"eor %[DST].16b, %[DST].16b, %[SRC].16b" "\n"
		: [DST] "+w" (two)
		: [SRC] "w" (six)
	);
	// three = veorq_u32(three, seven);
 	asm volatile(
		"eor %[DST].16b, %[DST].16b, %[SRC].16b" "\n"
		: [DST] "+w" (three)
		: [SRC] "w" (seven)
	);
	// four = veorq_u32(four, eight);
	asm volatile(
		"eor %[DST].16b, %[DST].16b, %[SRC].16b" "\n"
		: [DST] "+w" (four)
		: [SRC] "w" (eight)
	);
 
 	asm volatile(
		"umov %w[X00], %[SRCA].s[0]" "\n"
		"umov %w[X01], %[SRCA].s[1]" "\n"
		"umov %w[X02], %[SRCA].s[2]" "\n"
		"umov %w[X03], %[SRCA].s[3]" "\n"
		"umov %w[X04], %[SRCB].s[0]" "\n"
		"umov %w[X05], %[SRCB].s[1]" "\n"
		"umov %w[X06], %[SRCB].s[2]" "\n"
		"umov %w[X07], %[SRCB].s[3]" "\n"
		"umov %w[X08], %[SRCC].s[0]" "\n"
		"umov %w[X09], %[SRCC].s[1]" "\n"
		"umov %w[X10], %[SRCC].s[2]" "\n"
		"umov %w[X11], %[SRCC].s[3]" "\n"
		"umov %w[X12], %[SRCD].s[0]" "\n"
		"umov %w[X13], %[SRCD].s[1]" "\n"
		"umov %w[X14], %[SRCD].s[2]" "\n"
		"umov %w[X15], %[SRCD].s[3]" "\n"
		: [X00] "=r" (x00), [X01] "=r" (x01), [X02] "=r" (x02), [X03] "=r" (x03),	\
		[X04] "=r" (x04), [X05] "=r" (x05), [X06] "=r" (x06), [X07] "=r" (x07),	\
		[X08] "=r" (x08), [X09] "=r" (x09), [X10] "=r" (x10), [X11] "=r" (x11),	\
		[X12] "=r" (x12), [X13] "=r" (x13), [X14] "=r" (x14), [X15] "=r" (x15), [X16] "=r" (x16)
		: [SRCA] "w" (one), [SRCB] "w" (two), [SRCC] "w" (three), [SRCD] "w" (four)
	);

#define ROR(a,b) a >> b | a << (32 - b)
#define QuadRound(a, b, c, d, a1, a2, b1, b2, c1, c2, d1, d2, rot)		\
	asm volatile("": : :"memory");	\
	(tmp1 = a1 + a2,	\
	tmp2 = b1 + b2,	\
	tmp3 = c1 + c2,	\
	tmp4 = d1 + d2),	\
	(a ^= ROR(tmp1, rot),	\
	b ^= ROR(tmp2, rot),	\
	c ^= ROR(tmp3, rot),	\
	d ^= ROR(tmp4, rot))
	
	// Operate on columns.
	QuadRound(x04, x09, x14, x03, x00, \
	x12, x05, x01, x10, x06, x15, x11, 25);

	QuadRound(x08, x13, x02, x07, x04, \
	x00, x09, x05, x14, x10, x03, x15, 23);

	QuadRound(x12, x01, x06, x11, x08, \
	x04, x13, x09, x02, x14, x07, x03, 19);

	QuadRound(x00, x05, x10, x15, x12, \
	x08, x01, x13, x06, x02, x11, x07, 14);

	// Operate on rows.
	QuadRound(x01, x06, x11, x12, x00, \
	x03, x05, x04, x10, x09, x15, x14, 25);

	QuadRound(x02, x07, x08, x13, x01, \
	x00, x06, x05, x11, x10, x12, x15, 23);

	QuadRound(x03, x04, x09, x14, x02, \
	x01, x07, x06, x08, x11, x13, x12, 19);

	QuadRound(x00, x05, x10, x15, x03, \
	x02, x04, x07, x09, x08, x14, x13, 14);

	// Operate on columns.
	QuadRound(x04, x09, x14, x03, x00, \
	x12, x05, x01, x10, x06, x15, x11, 25);

	QuadRound(x08, x13, x02, x07, x04, \
	x00, x09, x05, x14, x10, x03, x15, 23);

	QuadRound(x12, x01, x06, x11, x08, \
	x04, x13, x09, x02, x14, x07, x03, 19);

	QuadRound(x00, x05, x10, x15, x12, \
	x08, x01, x13, x06, x02, x11, x07, 14);

	// Operate on rows.
	QuadRound(x01, x06, x11, x12, x00, \
	x03, x05, x04, x10, x09, x15, x14, 25);

	QuadRound(x02, x07, x08, x13, x01, \
	x00, x06, x05, x11, x10, x12, x15, 23);

	QuadRound(x03, x04, x09, x14, x02, \
	x01, x07, x06, x08, x11, x13, x12, 19);

	QuadRound(x00, x05, x10, x15, x03, \
	x02, x04, x07, x09, x08, x14, x13, 14);

	// Operate on columns.
	QuadRound(x04, x09, x14, x03, x00, \
	x12, x05, x01, x10, x06, x15, x11, 25);

	QuadRound(x08, x13, x02, x07, x04, \
	x00, x09, x05, x14, x10, x03, x15, 23);

	QuadRound(x12, x01, x06, x11, x08, \
	x04, x13, x09, x02, x14, x07, x03, 19);

	QuadRound(x00, x05, x10, x15, x12, \
	x08, x01, x13, x06, x02, x11, x07, 14);

	// Operate on rows.
	QuadRound(x01, x06, x11, x12, x00, \
	x03, x05, x04, x10, x09, x15, x14, 25);

	QuadRound(x02, x07, x08, x13, x01, \
	x00, x06, x05, x11, x10, x12, x15, 23);

	QuadRound(x03, x04, x09, x14, x02, \
	x01, x07, x06, x08, x11, x13, x12, 19);

	QuadRound(x00, x05, x10, x15, x03, \
	x02, x04, x07, x09, x08, x14, x13, 14);

	// Operate on columns.
	QuadRound(x04, x09, x14, x03, x00, \
	x12, x05, x01, x10, x06, x15, x11, 25);

	QuadRound(x08, x13, x02, x07, x04, \
	x00, x09, x05, x14, x10, x03, x15, 23);

	QuadRound(x12, x01, x06, x11, x08, \
	x04, x13, x09, x02, x14, x07, x03, 19);

	QuadRound(x00, x05, x10, x15, x12, \
	x08, x01, x13, x06, x02, x11, x07, 14);

	// Operate on rows.
	QuadRound(x01, x06, x11, x12, x00, \
	x03, x05, x04, x10, x09, x15, x14, 25);

	QuadRound(x02, x07, x08, x13, x01, \
	x00, x06, x05, x11, x10, x12, x15, 23);

	QuadRound(x03, x04, x09, x14, x02, \
	x01, x07, x06, x08, x11, x13, x12, 19);

	QuadRound(x00, x05, x10, x15, x03, \
	x02, x04, x07, x09, x08, x14, x13, 14);

 	asm volatile(
		"add %x[X00], %x[X00], %x[X01], lsl #32" "\n"
		"add %x[X02], %x[X02], %x[X03], lsl #32" "\n"
		"add %x[X04], %x[X04], %x[X05], lsl #32" "\n"
		"add %x[X06], %x[X06], %x[X07], lsl #32" "\n"
		"mov %[SRCA].d[0], %x[X00]" "\n"
		"add %x[X08], %x[X08], %x[X09], lsl #32" "\n"
		"mov %[SRCA].d[1], %x[X02]" "\n"
		"add %x[X10], %x[X10], %x[X11], lsl #32" "\n"
		"mov %[SRCB].d[0], %x[X04]" "\n"
		"add %x[X12], %x[X12], %x[X13], lsl #32" "\n"
		"mov %[SRCB].d[1], %x[X06]" "\n"
		"add %x[X14], %x[X14], %x[X15], lsl #32" "\n"
		"mov %[SRCC].d[0], %x[X08]" "\n"
		"mov %[SRCD].d[0], %x[X12]" "\n"
		"mov %[SRCC].d[1], %x[X10]" "\n"
		"mov %[SRCD].d[1], %x[X14]" "\n"

/*		"mov %[SRCA].s[0], %w[X00]" "\n"
		"mov %[SRCB].s[0], %w[X04]" "\n"
		"mov %[SRCC].s[0], %w[X08]" "\n"
		"mov %[SRCD].s[0], %w[X12]" "\n"
		"mov %[SRCA].s[1], %w[X01]" "\n"
		"mov %[SRCB].s[1], %w[X05]" "\n"
		"mov %[SRCC].s[1], %w[X09]" "\n"
		"mov %[SRCD].s[1], %w[X13]" "\n"
		"mov %[SRCA].s[2], %w[X02]" "\n"
		"mov %[SRCB].s[2], %w[X06]" "\n"
		"mov %[SRCC].s[2], %w[X10]" "\n"
		"mov %[SRCD].s[2], %w[X14]" "\n"
		"mov %[SRCB].s[3], %w[X07]" "\n"
		"mov %[SRCA].s[3], %w[X03]" "\n"
		"mov %[SRCC].s[3], %w[X11]" "\n"
		"mov %[SRCD].s[3], %w[X15]" "\n"*/
		: [SRCA] "=w" (thirteen), [SRCB] "=w" (fourteen), [SRCC] "=w" (fifteen), [SRCD] "=w" (sixteen)	\
		: [X00] "r" (x00), [X02] "r" (x02),	\
		[X04] "r" (x04), [X06] "r" (x06), [X08] "r" (x08),	\
		[X10] "r" (x10), [X12] "r" (x12), [X14] "r" (x14),
		[X01] "r" (x01), [X03] "r" (x03), [X05] "r" (x05),	\
		[X07] "r" (x07), [X09] "r" (x09), [X11] "r" (x11),	\
		[X13] "r" (x13), [X15] "r" (x15)
	);

	one = vaddq_u32(one, thirteen);
	two = vaddq_u32(two, fourteen);
	three = vaddq_u32(three, fifteen);
	four = vaddq_u32(four, sixteen);

	// Working on right half
	five = veorq_u32(five, one);
	six = veorq_u32(six, two);
	seven = veorq_u32(seven, three);
	eight = veorq_u32(eight, four);

 	asm volatile(
		"umov %w[X00], %[SRCA].s[0]" "\n"
		"umov %w[X01], %[SRCA].s[1]" "\n"
		"umov %w[X02], %[SRCA].s[2]" "\n"
		"umov %w[X03], %[SRCA].s[3]" "\n"
		"umov %w[X04], %[SRCB].s[0]" "\n"
		"umov %w[X05], %[SRCB].s[1]" "\n"
		"umov %w[X06], %[SRCB].s[2]" "\n"
		"umov %w[X07], %[SRCB].s[3]" "\n"
		"umov %w[X08], %[SRCC].s[0]" "\n"
		"umov %w[X09], %[SRCC].s[1]" "\n"
		"umov %w[X10], %[SRCC].s[2]" "\n"
		"umov %w[X11], %[SRCC].s[3]" "\n"
		"umov %w[X12], %[SRCD].s[0]" "\n"
		"umov %w[X13], %[SRCD].s[1]" "\n"
		"umov %w[X14], %[SRCD].s[2]" "\n"
		"umov %w[X15], %[SRCD].s[3]" "\n"
		"mov %w[X16], %w[X00]" "\n"
		"mov %w[TMP1], %w[TMP1]" "\n"
		: [X00] "+r" (x00), [X01] "=r" (x01), [X02] "=r" (x02), [X03] "=r" (x03),	\
		[X04] "=r" (x04), [X05] "=r" (x05), [X06] "=r" (x06), [X07] "=r" (x07),	\
		[X08] "=r" (x08), [X09] "=r" (x09), [X10] "=r" (x10), [X11] "=r" (x11),	\
		[X12] "=r" (x12), [X13] "=r" (x13), [X14] "=r" (x14), [X15] "=r" (x15), [X16] "=r" (x16), [TMP1] "+r" (tmp1)
		: [SRCA] "w" (five), [SRCB] "w" (six), [SRCC] "w" (seven), [SRCD] "w" (eight)
	);
/*
#undef QuadRound
	//x16 = x00;
#if defined(__GNUC__) || defined(__GNUG__)
*/
/*#define QuadRound(a, b, c, d, a1, a2, b1, b2, c1, c2, d1, d2, rot)		\
	asm volatile("": : :"memory");	\
	(tmp1 = a1 + a2,	\
	tmp2 = b1 + b2,	\
	tmp3 = c1 + c2,	\
	tmp4 = d1 + d2),	\
	(a ^= ROR(tmp1, rot),	\
	b ^= ROR(tmp2, rot),	\
	c ^= ROR(tmp3, rot),	\
	d ^= ROR(tmp4, rot))*/
/*#else
 

#define QuadRound(a, b, c, d, a1, a2, b1, b2, c1, c2, d1, d2, rot)		\
	asm volatile(	\
		"add %w[TMP1], %w[SRC1], %w[SRC2]" "\n"	\
		"add %w[TMP2], %w[SRC3], %w[SRC4]" "\n"	\
		"add %w[TMP3], %w[SRC5], %w[SRC6]" "\n"	\
		"add %w[TMP4], %w[SRC7], %w[SRC8]" "\n"	\
		"eor	%w[DST1], %w[DST1], %w[TMP1], ror %[ROT]" "\n"	\
		"eor	%w[DST2], %w[DST2], %w[TMP2], ror %[ROT]" "\n"	\
		"eor	%w[DST3], %w[DST3], %w[TMP3], ror %[ROT]" "\n"	\
		"eor	%w[DST4], %w[DST4], %w[TMP4], ror %[ROT]" "\n"	\
		: [DST1] "+r" (a), [DST2] "+r" (b), [DST3] "+r" (c), [DST4] "+r" (d),	\
		[TMP1] "+r" (tmp1), [TMP2] "+r" (tmp2), [TMP3] "+r" (tmp3), [TMP4] "+r" (tmp4)	\
		: [SRC1] "r" (a1), [SRC2] "r" (a2), [SRC3] "r" (b1), [SRC4] "r" (b2), \
		[SRC5] "r" (c1), [SRC6] "r" (c2), [SRC7] "r" (d1), [SRC8] "r" (d2), [ROT] "X" (rot));
//#endif*/

#undef QuadRound
#define QuadRound(a, b, c, d, a1, a2, b1, b2, c1, c2, d1, d2, rot)		\
	asm volatile(	\
		"add %w[TMP1], %w[SRC1], %w[SRC2]" "\n"	\
		"add %w[TMP2], %w[SRC3], %w[SRC4]" "\n"	\
		"eor	%w[DST1], %w[DST1], %w[TMP1], ror %[ROT]" "\n"	\
		"add %w[TMP3], %w[SRC5], %w[SRC6]" "\n"	\
		"eor	%w[DST2], %w[DST2], %w[TMP2], ror %[ROT]" "\n"	\
		"add %w[TMP4], %w[SRC7], %w[SRC8]" "\n"	\
		"eor	%w[DST3], %w[DST3], %w[TMP3], ror %[ROT]" "\n"	\
		"eor	%w[DST4], %w[DST4], %w[TMP4], ror %[ROT]" "\n"	\
		: [DST1] "+r" (a), [DST2] "+r" (b), [DST3] "+r" (c), [DST4] "+r" (d),	\
		[TMP1] "+r" (tmp1), [TMP2] "+r" (tmp2), [TMP3] "+r" (tmp3), [TMP4] "+r" (tmp4)	\
		: [SRC1] "r" (a1), [SRC2] "r" (a2), [SRC3] "r" (b1), [SRC4] "r" (b2), \
		[SRC5] "r" (c1), [SRC6] "r" (c2), [SRC7] "r" (d1), [SRC8] "r" (d2), [ROT] "X" (rot));

	// Operate on columns.
	QuadRound(x04, x09, x14, x03, x00, \
	x12, x05, x01, x10, x06, x15, x11, 25);

	QuadRound(x08, x13, x02, x07, x04, \
	x00, x09, x05, x14, x10, x03, x15, 23);

	QuadRound(x12, x01, x06, x11, x08, \
	x04, x13, x09, x02, x14, x07, x03, 19);

	QuadRound(x00, x05, x10, x15, x12, \
	x08, x01, x13, x06, x02, x11, x07, 14);

	// Operate on rows.
	QuadRound(x01, x06, x11, x12, x00, \
	x03, x05, x04, x10, x09, x15, x14, 25);

	QuadRound(x02, x07, x08, x13, x01, \
	x00, x06, x05, x11, x10, x12, x15, 23);

	QuadRound(x03, x04, x09, x14, x02, \
	x01, x07, x06, x08, x11, x13, x12, 19);

	QuadRound(x00, x05, x10, x15, x03, \
	x02, x04, x07, x09, x08, x14, x13, 14);

	// Operate on columns.
	QuadRound(x04, x09, x14, x03, x00, \
	x12, x05, x01, x10, x06, x15, x11, 25);

	QuadRound(x08, x13, x02, x07, x04, \
	x00, x09, x05, x14, x10, x03, x15, 23);

	QuadRound(x12, x01, x06, x11, x08, \
	x04, x13, x09, x02, x14, x07, x03, 19);

	QuadRound(x00, x05, x10, x15, x12, \
	x08, x01, x13, x06, x02, x11, x07, 14);

	// Operate on rows.
	QuadRound(x01, x06, x11, x12, x00, \
	x03, x05, x04, x10, x09, x15, x14, 25);

	QuadRound(x02, x07, x08, x13, x01, \
	x00, x06, x05, x11, x10, x12, x15, 23);

	QuadRound(x03, x04, x09, x14, x02, \
	x01, x07, x06, x08, x11, x13, x12, 19);

	QuadRound(x00, x05, x10, x15, x03, \
	x02, x04, x07, x09, x08, x14, x13, 14);

	// Operate on columns.
	QuadRound(x04, x09, x14, x03, x00, \
	x12, x05, x01, x10, x06, x15, x11, 25);

	QuadRound(x08, x13, x02, x07, x04, \
	x00, x09, x05, x14, x10, x03, x15, 23);

	QuadRound(x12, x01, x06, x11, x08, \
	x04, x13, x09, x02, x14, x07, x03, 19);

	QuadRound(x00, x05, x10, x15, x12, \
	x08, x01, x13, x06, x02, x11, x07, 14);

	// Operate on rows.
	QuadRound(x01, x06, x11, x12, x00, \
	x03, x05, x04, x10, x09, x15, x14, 25);

	QuadRound(x02, x07, x08, x13, x01, \
	x00, x06, x05, x11, x10, x12, x15, 23);

	QuadRound(x03, x04, x09, x14, x02, \
	x01, x07, x06, x08, x11, x13, x12, 19);

	QuadRound(x00, x05, x10, x15, x03, \
	x02, x04, x07, x09, x08, x14, x13, 14);

	// Operate on columns.
	QuadRound(x04, x09, x14, x03, x00, \
	x12, x05, x01, x10, x06, x15, x11, 25);

	QuadRound(x08, x13, x02, x07, x04, \
	x00, x09, x05, x14, x10, x03, x15, 23);

	QuadRound(x12, x01, x06, x11, x08, \
	x04, x13, x09, x02, x14, x07, x03, 19);

	QuadRound(x00, x05, x10, x15, x12, \
	x08, x01, x13, x06, x02, x11, x07, 14);

	// Operate on rows.
	QuadRound(x01, x06, x11, x12, x00, \
	x03, x05, x04, x10, x09, x15, x14, 25);

	QuadRound(x02, x07, x08, x13, x01, \
	x00, x06, x05, x11, x10, x12, x15, 23);

	QuadRound(x03, x04, x09, x14, x02, \
	x01, x07, x06, x08, x11, x13, x12, 19);

	QuadRound(x00, x05, x10, x15, x03, \
	x02, x04, x07, x09, x08, x14, x13, 14);

/*	x16 = (x00 + x16) & (uint32_t) 1048575;  
	Vptr = &V[x16 * totalthreads];
	__builtin_prefetch(Vptr);
	//__builtin_prefetch(Vptr + 16);

	asm volatile(
		"prfm pldl1keep, [%[SRC],#64]" "\n"
		:
		: [SRC] "r" (Vptr)
	);*/

#undef QuadRound
#undef ROR

 	asm volatile(
		"mov %[SRCA].s[0], %w[X00]" "\n"
		"add %w[X16], %w[X16], %w[X00]" "\n"
		"mov %[SRCB].s[0], %w[X04]" "\n"
		"and %w[X16], %w[PREFETCHAND], %w[X16], lsl #2" "\n"
		"mov %[SRCC].s[0], %w[X08]" "\n"
		"mul %w[X16], %w[X16], %w[TOTALTHREADS]" "\n"
		"mov %[SRCD].s[0], %w[X12]" "\n"
		"add %x[VPTR], %x[V], %x[X16]" "\n"
		"mov %[SRCA].s[1], %w[X01]" "\n"
		"mov %[SRCB].s[1], %w[X05]" "\n"
		"prfm pldl1keep, [%[VPTR]]" "\n"
		"prfm pldl1keep, [%[VPTR],#64]" "\n"
		"mov %[SRCC].s[1], %w[X09]" "\n"
		"mov %[SRCD].s[1], %w[X13]" "\n"
		"mov %[SRCA].s[2], %w[X02]" "\n"
		"mov %[SRCB].s[2], %w[X06]" "\n"
		"mov %[SRCC].s[2], %w[X10]" "\n"
		"mov %[SRCD].s[2], %w[X14]" "\n"
		"mov %[SRCB].s[3], %w[X07]" "\n"
		"mov %[SRCA].s[3], %w[X03]" "\n"
		"mov %[SRCC].s[3], %w[X11]" "\n"
		"mov %[SRCD].s[3], %w[X15]" "\n"
		: [SRCA] "=w" (thirteen), [SRCB] "=w" (fourteen), [SRCC] "=w" (fifteen), [SRCD] "=w" (sixteen), [X16] "+r" (x16), \
		[VPTR] "=r" (Vptr)
		: [X00] "r" (x00), [X02] "r" (x02),	\
		[X04] "r" (x04), [X06] "r" (x06), [X08] "r" (x08),	\
		[X10] "r" (x10), [X12] "r" (x12), [X14] "r" (x14),
		[X01] "r" (x01), [X03] "r" (x03), [X05] "r" (x05),	\
		[X07] "r" (x07), [X09] "r" (x09), [X11] "r" (x11),	\
		[X13] "r" (x13), [X15] "r" (x15), [TOTALTHREADS] "r" (totalthreads), [V] "r" (V), [PREFETCHAND] "r" (prefetchAND)
	);

	}

	B->val[ 0] = one;
	B->val[ 1] = two;
	B->val[ 2] = three;
	B->val[ 3] = four;

	B->val[ 4] = vaddq_u32(five, thirteen);
	B->val[ 5] = vaddq_u32(six, fourteen);
	B->val[ 6] = vaddq_u32(seven, fifteen);
	B->val[ 7] = vaddq_u32(eight, sixteen);
}

uint32_t volatile startwork = 1;

static inline void __attribute__((hot)) scrypt_core(uint32_t *Xsrc, uint32_t *V, uint32_t thr_id, uint32_t totalthreads)
{
	// Create neon register work buffer.
	// Stores, Loads and some Adds & Xor operations performed in asimd/neon
	uint32x4x8_t X;

	// memcpy for accurate work data copy.
	memcpy(&X, Xsrc, 128);

	// Thread's Scratchpad offset
	V = &V[thr_id * 32];

	scryptNsave_cycle(&X, V, thr_id, totalthreads);

	if(thr_id + 1 == totalthreads) {
		startwork = 0;
	}

	// Tiny delay between threads consecutive read cycle starts so memory loads are spaced out
	for(int i = thr_id * 100; i != 0; i--) { asm volatile("nop"); };

	scryptNread_cycle(&X, V, thr_id, totalthreads);

	if(thr_id + 1 == totalthreads) {
		startwork = 1;
	}

	// Store results
	memcpy(Xsrc, &X, 128);
}

/* Removed unnecessary steps */
static inline void scrypt_shuffle(uint32_t B[16])
{
	uint32_t tmp = B[ 1];	
	B[ 1] = B[ 5];
	B[ 5] = tmp;
	tmp = B[ 2];
	B[ 2] = B[10];
	B[10] = tmp;
	tmp = B[ 3];
	B[ 3] = B[15];
	B[15] = tmp;
	tmp = B[ 4];
	B[ 4] = B[12];
	B[12] = tmp;
	tmp = B[ 7];
	B[ 7] = B[11];
	B[11] = tmp;
	tmp = B[ 9];
	B[ 9] = B[13];
	B[13] = tmp;
}

/* Stripped down implementation of scrypt_core_3way for aarch64/armv8.
scrypt_core() outperforms this. May aswell remove scrypt_core_1way().
Not tested for producing valid work nor any likelyhood of performance
tuning as far I can see. Lacks possibility of dual issue. */
static inline void scrypt_core_1way(uint32_t B[32 * 1], uint32_t *V, uint32_t N)
{
	uint32_t* W = V;

	scrypt_shuffle(&B[0  + 0]);
	scrypt_shuffle(&B[16 + 0]);

	uint32x4x4_t q_tmp;
  	uint32x4x4_t q_a;
	uint32x4x4_t ba_a, ba_b;

	ba_a.val[ 0] = vld1q_u32(&B[( 0) / 4]);
	ba_a.val[ 1] = vld1q_u32(&B[(16) / 4]);
	ba_a.val[ 2] = vld1q_u32(&B[(32) / 4]);
	ba_a.val[ 3] = vld1q_u32(&B[(48) / 4]);

	ba_b.val[ 0] = vld1q_u32(&B[(0 + 64 + 0) / 4]);
	ba_b.val[ 1] = vld1q_u32(&B[(0 + 64 + 16) / 4]);
	ba_b.val[ 2] = vld1q_u32(&B[(0 + 64 + 32) / 4]);
	ba_b.val[ 3] = vld1q_u32(&B[(0 + 64 + 48) / 4]);

	// prep

	vst1q_u32(&V[( 0) / 4], ba_a.val[ 0]);
	vst1q_u32(&V[(16) / 4], ba_a.val[ 1]);
	vst1q_u32(&V[(32) / 4], ba_a.val[ 2]);
	vst1q_u32(&V[(48) / 4], ba_a.val[ 3]);

	vst1q_u32(&V[(64) / 4],  ba_b.val[ 0]);
	vst1q_u32(&V[(80) / 4],  ba_b.val[ 1]);
	vst1q_u32(&V[(96) / 4],  ba_b.val[ 2]);
	vst1q_u32(&V[(112) / 4], ba_b.val[ 3]);

	for (register int n = 0; n < N; n++)
	{
	// loop 1 part a
			vst1q_u32(&V[(     16 + (0 * 4))], ba_b.val[ 0]);
		q_a.val[ 0] = veorq_u32(ba_b.val[ 0], ba_a.val[ 0]);
			vst1q_u32(&V[(     16 + (1 * 4))], ba_b.val[ 1]);
		q_a.val[ 1] = veorq_u32(ba_b.val[ 1], ba_a.val[ 1]);
			vst1q_u32(&V[(     16 + (2 * 4))], ba_b.val[ 2]);
		q_a.val[ 2] = veorq_u32(ba_b.val[ 2], ba_a.val[ 2]);
			vst1q_u32(&V[(     16 + (3 * 4))], ba_b.val[ 3]);
		q_a.val[ 3] = veorq_u32(ba_b.val[ 3], ba_a.val[ 3]);

		V += 32;
		ba_a = q_a;

		for (register int i = 0; i < 4; i ++)
		{
			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 0], q_a.val[ 1]);  	
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 7);	
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 25);
			q_a.val[ 3] = veorq_u32(q_tmp.val[ 1], q_a.val[ 3]);

			q_tmp.val[ 2] = vaddq_u32(q_a.val[ 3], q_a.val[ 0]);
			q_tmp.val[ 3] = vshlq_n_u32(q_tmp.val[ 2], 9);
			q_tmp.val[ 3] = vsriq_n_u32(q_tmp.val[ 3], q_tmp.val[ 2], 23);
			q_a.val[ 2] = veorq_u32(q_tmp.val[ 3], q_a.val[ 2]);

			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 2], q_a.val[ 3]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 13);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 19);
			q_a.val[ 1] = veorq_u32(q_tmp.val[ 1], q_a.val[ 1]);
			
			q_tmp.val[ 2] = vaddq_u32(q_a.val[ 1], q_a.val[ 2]);
			q_tmp.val[ 3] = vshlq_n_u32(q_tmp.val[ 2], 18);
			q_tmp.val[ 3] = vsriq_n_u32(q_tmp.val[ 3], q_tmp.val[ 2], 14);
			q_a.val[ 0] = veorq_u32(q_tmp.val[ 3], q_a.val[ 0]);
			
			q_a.val[ 1] = vextq_u32(q_a.val[ 1], q_a.val[ 1], 1);
			q_a.val[ 3] = vextq_u32(q_a.val[ 3], q_a.val[ 3], 3);
			q_a.val[ 2] = vextq_u32(q_a.val[ 2], q_a.val[ 2], 2);
			
			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 0], q_a.val[ 3]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 7);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 25);
			q_a.val[ 1] = veorq_u32(q_tmp.val[ 1], q_a.val[ 1]);

			q_tmp.val[ 2] = vaddq_u32(q_a.val[ 1], q_a.val[ 0]);
			q_tmp.val[ 3] = vshlq_n_u32(q_tmp.val[ 2], 9);
			q_tmp.val[ 3] = vsriq_n_u32(q_tmp.val[ 3], q_tmp.val[ 2], 23);
			q_a.val[ 2] = veorq_u32(q_tmp.val[ 3], q_a.val[ 2]);

			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 2], q_a.val[ 1]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 13);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 19);
			q_a.val[ 3] = veorq_u32(q_tmp.val[ 1], q_a.val[ 3]);

			q_a.val[ 1] = vextq_u32(q_a.val[ 1], q_a.val[ 1], 3);
			q_a.val[ 2] = vextq_u32(q_a.val[ 2], q_a.val[ 2], 2);
			q_a.val[ 3] = vextq_u32(q_a.val[ 3], q_a.val[ 3], 1);

			q_tmp.val[ 2] = vaddq_u32(q_a.val[ 3], q_a.val[ 2]);
			q_tmp.val[ 3] = vshlq_n_u32(q_tmp.val[ 2], 18);
			q_tmp.val[ 3] = vsriq_n_u32(q_tmp.val[ 3], q_tmp.val[ 2], 14);
			q_a.val[ 0] = veorq_u32(q_tmp.val[ 3], q_a.val[ 0]);
		}
		ba_a.val[ 0] = vaddq_u32(ba_a.val[ 0], q_a.val[ 0]);
		ba_a.val[ 1] = vaddq_u32(ba_a.val[ 1], q_a.val[ 1]);
		ba_a.val[ 2] = vaddq_u32(ba_a.val[ 2], q_a.val[ 2]);
		ba_a.val[ 3] = vaddq_u32(ba_a.val[ 3], q_a.val[ 3]);

		q_a = ba_a;

	// loop 1 part b
			vst1q_u32(&V[      (0 * 4) ], ba_a.val[ 0]);
		q_a.val[ 0] = veorq_u32(ba_b.val[ 0], q_a.val[ 0]);
			vst1q_u32(&V[      (1 * 4) ], ba_a.val[ 1]);
		q_a.val[ 1] = veorq_u32(ba_b.val[ 1], q_a.val[ 1]);
			vst1q_u32(&V[      (2 * 4) ], ba_a.val[ 2]);
		q_a.val[ 2] = veorq_u32(ba_b.val[ 2], q_a.val[ 2]);
			vst1q_u32(&V[      (3 * 4) ], ba_a.val[ 3]);
		q_a.val[ 3] = veorq_u32(ba_b.val[ 3], q_a.val[ 3]);
		ba_b = q_a;

		for (register int i = 0; i < 4; i ++)
		{

			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 0], q_a.val[ 1]);  	
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 7);	
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 25);
			q_a.val[ 3] = veorq_u32(q_tmp.val[ 1], q_a.val[ 3]);

			q_tmp.val[ 2] = vaddq_u32(q_a.val[ 3], q_a.val[ 0]);
			q_tmp.val[ 3] = vshlq_n_u32(q_tmp.val[ 2], 9);
			q_tmp.val[ 3] = vsriq_n_u32(q_tmp.val[ 3], q_tmp.val[ 2], 23);
			q_a.val[ 2] = veorq_u32(q_tmp.val[ 3], q_a.val[ 2]);

			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 2], q_a.val[ 3]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 13);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 19);
			q_a.val[ 1] = veorq_u32(q_tmp.val[ 1], q_a.val[ 1]);
			
			q_tmp.val[ 2] = vaddq_u32(q_a.val[ 1], q_a.val[ 2]);
			q_tmp.val[ 3] = vshlq_n_u32(q_tmp.val[ 2], 18);
			q_tmp.val[ 3] = vsriq_n_u32(q_tmp.val[ 3], q_tmp.val[ 2], 14);
			q_a.val[ 0] = veorq_u32(q_tmp.val[ 3], q_a.val[ 0]);
			
			q_a.val[ 1] = vextq_u32(q_a.val[ 1], q_a.val[ 1], 1);
			q_a.val[ 3] = vextq_u32(q_a.val[ 3], q_a.val[ 3], 3);
			q_a.val[ 2] = vextq_u32(q_a.val[ 2], q_a.val[ 2], 2);
			
			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 0], q_a.val[ 3]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 7);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 25);
			q_a.val[ 1] = veorq_u32(q_tmp.val[ 1], q_a.val[ 1]);

			q_tmp.val[ 2] = vaddq_u32(q_a.val[ 1], q_a.val[ 0]);
			q_tmp.val[ 3] = vshlq_n_u32(q_tmp.val[ 2], 9);
			q_tmp.val[ 3] = vsriq_n_u32(q_tmp.val[ 3], q_tmp.val[ 2], 23);
			q_a.val[ 2] = veorq_u32(q_tmp.val[ 3], q_a.val[ 2]);

			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 2], q_a.val[ 1]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 13);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 19);
			q_a.val[ 3] = veorq_u32(q_tmp.val[ 1], q_a.val[ 3]);

			q_a.val[ 1] = vextq_u32(q_a.val[ 1], q_a.val[ 1], 3);
			q_a.val[ 2] = vextq_u32(q_a.val[ 2], q_a.val[ 2], 2);
			q_a.val[ 3] = vextq_u32(q_a.val[ 3], q_a.val[ 3], 1);

			q_tmp.val[ 2] = vaddq_u32(q_a.val[ 3], q_a.val[ 2]);
			q_tmp.val[ 3] = vshlq_n_u32(q_tmp.val[ 2], 18);
			q_tmp.val[ 3] = vsriq_n_u32(q_tmp.val[ 3], q_tmp.val[ 2], 14);
			q_a.val[ 0] = veorq_u32(q_tmp.val[ 3], q_a.val[ 0]);
		}

		ba_b.val[ 0] = vaddq_u32(q_a.val[ 0], ba_b.val[ 0]);
		ba_b.val[ 1] = vaddq_u32(q_a.val[ 1], ba_b.val[ 1]);
		ba_b.val[ 2] = vaddq_u32(q_a.val[ 2], ba_b.val[ 2]);
		ba_b.val[ 3] = vaddq_u32(q_a.val[ 3], ba_b.val[ 3]); 
	}
	V = W;

    // loop 2

	uint32_t one =   32 * (1 * (ba_b.val[ 0][ 0] & (N - 1)) + 0);
	q_tmp.val[ 0] = vld1q_u32(&W[one +  0]);
	q_tmp.val[ 1] = vld1q_u32(&W[one +  4]);
	q_tmp.val[ 2] = vld1q_u32(&W[one +  8]);
	q_tmp.val[ 3] = vld1q_u32(&W[one + 12]);

	for (register int n = 0; n < N; n++)
	{
	// loop 2 part a

		ba_a.val[ 0] = veorq_u32(ba_a.val[ 0], q_tmp.val[ 0]);
			q_tmp.val[ 0] = vld1q_u32(&W[one + 16 +  0]);
		ba_a.val[ 1] = veorq_u32(ba_a.val[ 1], q_tmp.val[ 1]);
			q_tmp.val[ 1] = vld1q_u32(&W[one + 16 +  4]);
		ba_a.val[ 2] = veorq_u32(ba_a.val[ 2], q_tmp.val[ 2]);
			q_tmp.val[ 2] = vld1q_u32(&W[one + 16 +  8]);
		ba_a.val[ 3] = veorq_u32(ba_a.val[ 3], q_tmp.val[ 3]);
		q_tmp.val[ 3] = vld1q_u32(&W[one + 16 + 12]);

			ba_b.val[ 0] = veorq_u32(ba_b.val[ 0], q_tmp.val[ 0]);
			ba_b.val[ 1] = veorq_u32(ba_b.val[ 1], q_tmp.val[ 1]);
			ba_b.val[ 2] = veorq_u32(ba_b.val[ 2], q_tmp.val[ 2]);
			ba_b.val[ 3] = veorq_u32(ba_b.val[ 3], q_tmp.val[ 3]);

				q_a.val[ 0] = veorq_u32(ba_b.val[ 0], ba_a.val[ 0]);
				q_a.val[ 1] = veorq_u32(ba_b.val[ 1], ba_a.val[ 1]);
				q_a.val[ 2] = veorq_u32(ba_b.val[ 2], ba_a.val[ 2]);
				q_a.val[ 3] = veorq_u32(ba_b.val[ 3], ba_a.val[ 3]);
		ba_a = q_a;

		for (register int i = 0; i < 4; i++)
		{
			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 0], q_a.val[ 1]);  	
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 7);	
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 25);
			q_a.val[ 3] = veorq_u32(q_tmp.val[ 1], q_a.val[ 3]);

			q_tmp.val[ 2] = vaddq_u32(q_a.val[ 3], q_a.val[ 0]);
			q_tmp.val[ 3] = vshlq_n_u32(q_tmp.val[ 2], 9);
			q_tmp.val[ 3] = vsriq_n_u32(q_tmp.val[ 3], q_tmp.val[ 2], 23);
			q_a.val[ 2] = veorq_u32(q_tmp.val[ 3], q_a.val[ 2]);

			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 2], q_a.val[ 3]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 13);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 19);
			q_a.val[ 1] = veorq_u32(q_tmp.val[ 1], q_a.val[ 1]);
			
			q_tmp.val[ 2] = vaddq_u32(q_a.val[ 1], q_a.val[ 2]);
			q_tmp.val[ 3] = vshlq_n_u32(q_tmp.val[ 2], 18);
			q_tmp.val[ 3] = vsriq_n_u32(q_tmp.val[ 3], q_tmp.val[ 2], 14);
			q_a.val[ 0] = veorq_u32(q_tmp.val[ 3], q_a.val[ 0]);
			
			q_a.val[ 1] = vextq_u32(q_a.val[ 1], q_a.val[ 1], 1);
			q_a.val[ 3] = vextq_u32(q_a.val[ 3], q_a.val[ 3], 3);
			q_a.val[ 2] = vextq_u32(q_a.val[ 2], q_a.val[ 2], 2);
			
			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 0], q_a.val[ 3]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 7);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 25);
			q_a.val[ 1] = veorq_u32(q_tmp.val[ 1], q_a.val[ 1]);

			q_tmp.val[ 2] = vaddq_u32(q_a.val[ 1], q_a.val[ 0]);
			q_tmp.val[ 3] = vshlq_n_u32(q_tmp.val[ 2], 9);
			q_tmp.val[ 3] = vsriq_n_u32(q_tmp.val[ 3], q_tmp.val[ 2], 23);
			q_a.val[ 2] = veorq_u32(q_tmp.val[ 3], q_a.val[ 2]);

			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 2], q_a.val[ 1]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 13);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 19);
			q_a.val[ 3] = veorq_u32(q_tmp.val[ 1], q_a.val[ 3]);

			q_a.val[ 1] = vextq_u32(q_a.val[ 1], q_a.val[ 1], 3);
			q_a.val[ 2] = vextq_u32(q_a.val[ 2], q_a.val[ 2], 2);
			q_a.val[ 3] = vextq_u32(q_a.val[ 3], q_a.val[ 3], 1);

			q_tmp.val[ 2] = vaddq_u32(q_a.val[ 3], q_a.val[ 2]);
			q_tmp.val[ 3] = vshlq_n_u32(q_tmp.val[ 2], 18);
			q_tmp.val[ 3] = vsriq_n_u32(q_tmp.val[ 3], q_tmp.val[ 2], 14);
			q_a.val[ 0] = veorq_u32(q_tmp.val[ 3], q_a.val[ 0]);

		}
		ba_a.val[ 0] = vaddq_u32(ba_a.val[ 0], q_a.val[ 0]);
		ba_a.val[ 1] = vaddq_u32(ba_a.val[ 1], q_a.val[ 1]);
		ba_a.val[ 2] = vaddq_u32(ba_a.val[ 2], q_a.val[ 2]);
		ba_a.val[ 3] = vaddq_u32(ba_a.val[ 3], q_a.val[ 3]);

		q_a = ba_a;

	// loop 2 b

		q_a.val[ 0] = veorq_u32(ba_b.val[ 0], q_a.val[ 0]);
		q_a.val[ 1] = veorq_u32(ba_b.val[ 1], q_a.val[ 1]);
		q_a.val[ 2] = veorq_u32(ba_b.val[ 2], q_a.val[ 2]);
		q_a.val[ 3] = veorq_u32(ba_b.val[ 3], q_a.val[ 3]);
		ba_b = q_a;

		for (register int i = 0; i < 3; i++)
		{
			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 0], q_a.val[ 1]);  	
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 7);	
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 25);
			q_a.val[ 3] = veorq_u32(q_tmp.val[ 1], q_a.val[ 3]);

			q_tmp.val[ 2] = vaddq_u32(q_a.val[ 3], q_a.val[ 0]);
			q_tmp.val[ 3] = vshlq_n_u32(q_tmp.val[ 2], 9);
			q_tmp.val[ 3] = vsriq_n_u32(q_tmp.val[ 3], q_tmp.val[ 2], 23);
			q_a.val[ 2] = veorq_u32(q_tmp.val[ 3], q_a.val[ 2]);

			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 2], q_a.val[ 3]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 13);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 19);
			q_a.val[ 1] = veorq_u32(q_tmp.val[ 1], q_a.val[ 1]);
			
			q_tmp.val[ 2] = vaddq_u32(q_a.val[ 1], q_a.val[ 2]);
			q_tmp.val[ 3] = vshlq_n_u32(q_tmp.val[ 2], 18);
			q_tmp.val[ 3] = vsriq_n_u32(q_tmp.val[ 3], q_tmp.val[ 2], 14);
			q_a.val[ 0] = veorq_u32(q_tmp.val[ 3], q_a.val[ 0]);
			
			q_a.val[ 1] = vextq_u32(q_a.val[ 1], q_a.val[ 1], 1);
			q_a.val[ 3] = vextq_u32(q_a.val[ 3], q_a.val[ 3], 3);
			q_a.val[ 2] = vextq_u32(q_a.val[ 2], q_a.val[ 2], 2);
			
			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 0], q_a.val[ 3]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 7);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 25);
			q_a.val[ 1] = veorq_u32(q_tmp.val[ 1], q_a.val[ 1]);

			q_tmp.val[ 2] = vaddq_u32(q_a.val[ 1], q_a.val[ 0]);
			q_tmp.val[ 3] = vshlq_n_u32(q_tmp.val[ 2], 9);
			q_tmp.val[ 3] = vsriq_n_u32(q_tmp.val[ 3], q_tmp.val[ 2], 23);
			q_a.val[ 2] = veorq_u32(q_tmp.val[ 3], q_a.val[ 2]);

			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 2], q_a.val[ 1]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 13);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 19);
			q_a.val[ 3] = veorq_u32(q_tmp.val[ 1], q_a.val[ 3]);

			q_tmp.val[ 2] = vaddq_u32(q_a.val[ 3], q_a.val[ 2]);
			q_tmp.val[ 3] = vshlq_n_u32(q_tmp.val[ 2], 18);
			q_tmp.val[ 3] = vsriq_n_u32(q_tmp.val[ 3], q_tmp.val[ 2], 14);
			q_a.val[ 0] = veorq_u32(q_tmp.val[ 3], q_a.val[ 0]);

			q_a.val[ 1] = vextq_u32(q_a.val[ 1], q_a.val[ 1], 3);
			q_a.val[ 2] = vextq_u32(q_a.val[ 2], q_a.val[ 2], 2);
			q_a.val[ 3] = vextq_u32(q_a.val[ 3], q_a.val[ 3], 1);
		}
		{
			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 0], q_a.val[ 1]);  	
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 7);	
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 25);
			q_a.val[ 3] = veorq_u32(q_tmp.val[ 1], q_a.val[ 3]);

			q_tmp.val[ 2] = vaddq_u32(q_a.val[ 3], q_a.val[ 0]);
			q_tmp.val[ 3] = vshlq_n_u32(q_tmp.val[ 2], 9);
			q_tmp.val[ 3] = vsriq_n_u32(q_tmp.val[ 3], q_tmp.val[ 2], 23);
			q_a.val[ 2] = veorq_u32(q_tmp.val[ 3], q_a.val[ 2]);

			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 2], q_a.val[ 3]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 13);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 19);
			q_a.val[ 1] = veorq_u32(q_tmp.val[ 1], q_a.val[ 1]);
			
			q_tmp.val[ 2] = vaddq_u32(q_a.val[ 1], q_a.val[ 2]);
			q_tmp.val[ 3] = vshlq_n_u32(q_tmp.val[ 2], 18);
			q_tmp.val[ 3] = vsriq_n_u32(q_tmp.val[ 3], q_tmp.val[ 2], 14);
			q_a.val[ 0] = veorq_u32(q_tmp.val[ 3], q_a.val[ 0]);
			
			q_a.val[ 1] = vextq_u32(q_a.val[ 1], q_a.val[ 1], 1);
			q_a.val[ 3] = vextq_u32(q_a.val[ 3], q_a.val[ 3], 3);
			q_a.val[ 2] = vextq_u32(q_a.val[ 2], q_a.val[ 2], 2);
			
			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 0], q_a.val[ 3]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 7);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 25);
			q_a.val[ 1] = veorq_u32(q_tmp.val[ 1], q_a.val[ 1]);

			q_tmp.val[ 2] = vaddq_u32(q_a.val[ 1], q_a.val[ 0]);
			q_tmp.val[ 3] = vshlq_n_u32(q_tmp.val[ 2], 9);
			q_tmp.val[ 3] = vsriq_n_u32(q_tmp.val[ 3], q_tmp.val[ 2], 23);
			q_a.val[ 2] = veorq_u32(q_tmp.val[ 3], q_a.val[ 2]);

			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 2], q_a.val[ 1]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 13);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 19);
			q_a.val[ 3] = veorq_u32(q_tmp.val[ 1], q_a.val[ 3]);

			q_tmp.val[ 2] = vaddq_u32(q_a.val[ 3], q_a.val[ 2]);
			q_tmp.val[ 3] = vshlq_n_u32(q_tmp.val[ 2], 18);
			q_tmp.val[ 3] = vsriq_n_u32(q_tmp.val[ 3], q_tmp.val[ 2], 14);
			q_a.val[ 0] = veorq_u32(q_tmp.val[ 3], q_a.val[ 0]);
				ba_b.val[ 0] = vaddq_u32(q_a.val[ 0], ba_b.val[ 0]);
					one =	32 * (1 * (ba_b.val[ 0][ 0] & (N - 1)) + 0);
					__builtin_prefetch(&W[one + 0]);
					__builtin_prefetch(&W[one + 8]);
					__builtin_prefetch(&W[one + 16]);
					__builtin_prefetch(&W[one + 24]);

			q_a.val[ 1] = vextq_u32(q_a.val[ 1], q_a.val[ 1], 3);
			q_a.val[ 2] = vextq_u32(q_a.val[ 2], q_a.val[ 2], 2);
			q_a.val[ 3] = vextq_u32(q_a.val[ 3], q_a.val[ 3], 1);

		}

		q_tmp.val[ 0] = vld1q_u32(&W[one +  0]);
		ba_b.val[ 1] = vaddq_u32(q_a.val[ 1], ba_b.val[ 1]);
		q_tmp.val[ 1] = vld1q_u32(&W[one +  4]);
		ba_b.val[ 2] = vaddq_u32(q_a.val[ 2], ba_b.val[ 2]);
		q_tmp.val[ 2] = vld1q_u32(&W[one +  8]);
		ba_b.val[ 3] = vaddq_u32(q_a.val[ 3], ba_b.val[ 3]);
		q_tmp.val[ 3] = vld1q_u32(&W[one + 12]);
	}

	vst1q_u32(&B[ 0],       ba_a.val[ 0]);
	vst1q_u32(&B[ 4],       ba_a.val[ 1]);
	vst1q_u32(&B[ 8],       ba_a.val[ 2]);
	vst1q_u32(&B[12],      ba_a.val[ 3]);
	vst1q_u32(&B[16 + 0],  ba_b.val[ 0]);
	vst1q_u32(&B[16 + 4],  ba_b.val[ 1]);
	vst1q_u32(&B[16 + 8],  ba_b.val[ 2]);
	vst1q_u32(&B[16 + 12], ba_b.val[ 3]);

	scrypt_shuffle(&B[0  + 0]);
	scrypt_shuffle(&B[16 + 0]);
}

// Used with vld4/str4 to compensate for their interleaved load/stores.
static inline void scrypt_deinterleaved_shuffle(uint32_t B[16])
{
	uint32_t x01,x02,x03,x04,x05,x06,x07,x08,x09,x10,x11,x12,x13,x14,x15;
	
	x01 = B[ 1];
	x02 = B[ 2];
	x03 = B[ 3];
	x04 = B[ 4];
	x05 = B[ 5];
	x06 = B[ 6];
	x07 = B[ 7];
	x08 = B[ 8];
	x09 = B[ 9];
	x10 = B[10];
	x11 = B[11];
	x12 = B[12];
	x13 = B[13];
	x14 = B[14];
	x15 = B[15];

	B[ 1] = x12;
	B[ 2] = x08;
	B[ 3] = x04;
	B[ 4] = x05;
	B[ 5] = x01;
	B[ 6] = x13;
	B[ 7] = x09;
	B[ 8] = x10;
	B[ 9] = x06;
	B[10] = x02;
	B[11] = x14;
	B[12] = x15;
	B[13] = x11;
	B[14] = x07;
	B[15] = x03;
}

/*
Stripped down implementation of scrypt_core_3way for aarch64/armv8.
Usually outperforms original while consuming 1/3rd less memory.
This is a better tuned approach for limited memory capacity and bandwidth
typical of armv8 sbc's while maximizing dual issue. 1gb can run 2x or 3x 2ways (-t 3 --oneways=1).
Experimented using vld1q_u32/vst1q_u32 (interleaves/deinterleaves) in conjunction with scrypt_deinterleaved_shuffle
reduced asm code by 10% however performance degraded 15% since it maybe causing misdirected cache prefetching,
or some other overheads I am not aware about. Other small improvements including inlineable memcpy & sha256 alternatives, 
yielding 1-2% improvement over initial 2ways fork released June 2018. Hints at data alignment seem to have no effect.
asm code lacks indication of said hints and sparse cortex-a53 documentation suggests alignment is handled transparently instead
using checks. fireworm71 believes peak performance has been reached - cache and memory cannot keep up with code.
UPDATE. scrypt_core() now approaches performance of 2/3 ways while consuming 20% less power.
*/
// try prohibit loop unrolling loops for 2ways
#ifdef HAVE_SCRYPT_2WAY
#pragma GCC push_options
#pragma GCC optimize ("unroll-all-loops")
static __attribute__ ((noinline)) void scrypt_core_2way(uint32_t B[32 * 2], uint32_t *V/*, int N*/)
{
	//uint32_t* W = V;
	uint32x4_t *W = (uint32x4_t *) V;//__attribute__((__aligned__(64))) = (uint32x4_t *) V __builtin_assume_aligned(V, 64);

	uint32x4x4_t q_tmp __attribute__((__aligned__(16)));
 	uint32x4x4_t q_a __attribute__((__aligned__(16))), q_b __attribute__((__aligned__(16)));
	uint32x4x4_t ba_a __attribute__((__aligned__(16))), bb_a __attribute__((__aligned__(16))), ba_b __attribute__((__aligned__(16))), bb_b __attribute__((__aligned__(16)));

	scrypt_shuffle(&B[0  + 0]);
	scrypt_shuffle(&B[16 + 0]);
	scrypt_shuffle(&B[0 + 32]);
	scrypt_shuffle(&B[16 + 32]);

	ba_a.val[ 0] = vld1q_u32(&B[( 0) / 4]);
	ba_a.val[ 1] = vld1q_u32(&B[(16) / 4]);
	ba_a.val[ 2] = vld1q_u32(&B[(32) / 4]);
	ba_a.val[ 3] = vld1q_u32(&B[(48) / 4]);

	ba_b.val[ 0] = vld1q_u32(&B[(0 + 64 + 0) / 4]);
	ba_b.val[ 1] = vld1q_u32(&B[(0 + 64 + 16) / 4]);
	ba_b.val[ 2] = vld1q_u32(&B[(0 + 64 + 32) / 4]);
	ba_b.val[ 3] = vld1q_u32(&B[(0 + 64 + 48) / 4]);

	bb_a.val[ 0] = vld1q_u32(&B[(128 +  0) / 4]);
	W[ 0] = ba_a.val[ 0];
	bb_a.val[ 1] = vld1q_u32(&B[(128 + 16) / 4]);
	W[ 1] = ba_a.val[ 1];
	bb_a.val[ 2] = vld1q_u32(&B[(128 + 32) / 4]);
	W[ 2] = ba_a.val[ 2];
	bb_a.val[ 3] = vld1q_u32(&B[(128 + 48) / 4]);
	W[ 3] = ba_a.val[ 3];

	bb_b.val[ 0] = vld1q_u32(&B[(128 + 64 + 0) / 4]);
	W[ 8] = bb_a.val[ 0];
	bb_b.val[ 1] = vld1q_u32(&B[(128 + 64 + 16) / 4]);
	W[ 9] = bb_a.val[ 1];
	bb_b.val[ 2] = vld1q_u32(&B[(128 + 64 + 32) / 4]);
	W[10] = bb_a.val[ 2];
	bb_b.val[ 3] = vld1q_u32(&B[(128 + 64 + 48) / 4]);
	W[11] = bb_a.val[ 3];
 

	for (register int n = 0; n < 1048576; n++)
	{
	// loop 1 part a
		W[ 4] = ba_b.val[ 0];
		q_a.val[ 0] = veorq_u32(ba_b.val[ 0], ba_a.val[ 0]);
		W[ 5] = ba_b.val[ 1];
		q_a.val[ 1] = veorq_u32(ba_b.val[ 1], ba_a.val[ 1]);
 		W[ 6] = ba_b.val[ 2];
		q_a.val[ 2] = veorq_u32(ba_b.val[ 2], ba_a.val[ 2]);
 		W[ 7] = ba_b.val[ 3];
		q_a.val[ 3] = veorq_u32(ba_b.val[ 3], ba_a.val[ 3]);
 		W[12] = bb_b.val[ 0];
		q_b.val[ 0] = veorq_u32(bb_b.val[ 0], bb_a.val[ 0]);
 		W[13] = bb_b.val[ 1];
		q_b.val[ 1] = veorq_u32(bb_b.val[ 1], bb_a.val[ 1]);
 		W[14] = bb_b.val[ 2];	
		q_b.val[ 2] = veorq_u32(bb_b.val[ 2], bb_a.val[ 2]);
		W[15] = bb_b.val[ 3];
		q_b.val[ 3] = veorq_u32(bb_b.val[ 3], bb_a.val[ 3]);
 
		ba_a = q_a;
		bb_a = q_b;
	//increments scratchpad pointer
		W += 16;

		for (register int i = 0; i < 4; i ++)
		{
			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 0], q_a.val[ 1]);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 0], q_b.val[ 1]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 7);	
			q_tmp.val[ 3] = vshlq_n_u32(q_tmp.val[ 2], 7);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 25);
			q_tmp.val[ 3] = vsriq_n_u32(q_tmp.val[ 3], q_tmp.val[ 2], 25);
			q_a.val[ 3] = veorq_u32(q_tmp.val[ 1], q_a.val[ 3]);
			q_b.val[ 3] = veorq_u32(q_tmp.val[ 3], q_b.val[ 3]);

			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 3], q_a.val[ 0]);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 3], q_b.val[ 0]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 9);
			q_tmp.val[ 3] = vshlq_n_u32(q_tmp.val[ 2], 9);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 23);
			q_tmp.val[ 3] = vsriq_n_u32(q_tmp.val[ 3], q_tmp.val[ 2], 23);
			q_a.val[ 2] = veorq_u32(q_tmp.val[ 1], q_a.val[ 2]);
			q_b.val[ 2] = veorq_u32(q_tmp.val[ 3], q_b.val[ 2]);

			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 2], q_a.val[ 3]);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 2], q_b.val[ 3]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 13);
			q_tmp.val[ 3] = vshlq_n_u32(q_tmp.val[ 2], 13);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 19);
			q_tmp.val[ 3] = vsriq_n_u32(q_tmp.val[ 3], q_tmp.val[ 2], 19);
			q_a.val[ 1] = veorq_u32(q_tmp.val[ 1], q_a.val[ 1]);
			q_b.val[ 1] = veorq_u32(q_tmp.val[ 3], q_b.val[ 1]);
			
			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 1], q_a.val[ 2]);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 1], q_b.val[ 2]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 18);
			q_tmp.val[ 3] = vshlq_n_u32(q_tmp.val[ 2], 18);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 14);
			q_tmp.val[ 3] = vsriq_n_u32(q_tmp.val[ 3], q_tmp.val[ 2], 14);
			q_a.val[ 0] = veorq_u32(q_tmp.val[ 1], q_a.val[ 0]);
			q_b.val[ 0] = veorq_u32(q_tmp.val[ 3], q_b.val[ 0]);
 
			q_a.val[ 1] = vextq_u32(q_a.val[ 1], q_a.val[ 1], 1);
			q_a.val[ 2] = vextq_u32(q_a.val[ 2], q_a.val[ 2], 2);
			q_a.val[ 3] = vextq_u32(q_a.val[ 3], q_a.val[ 3], 3);
			q_b.val[ 1] = vextq_u32(q_b.val[ 1], q_b.val[ 1], 1);
			q_b.val[ 2] = vextq_u32(q_b.val[ 2], q_b.val[ 2], 2);
			q_b.val[ 3] = vextq_u32(q_b.val[ 3], q_b.val[ 3], 3);

			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 0], q_a.val[ 3]);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 0], q_b.val[ 3]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 7);
			q_tmp.val[ 3] = vshlq_n_u32(q_tmp.val[ 2], 7);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 25);
			q_tmp.val[ 3] = vsriq_n_u32(q_tmp.val[ 3], q_tmp.val[ 2], 25);
			q_a.val[ 1] = veorq_u32(q_tmp.val[ 1], q_a.val[ 1]);
			q_b.val[ 1] = veorq_u32(q_tmp.val[ 3], q_b.val[ 1]);

			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 1], q_a.val[ 0]);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 1], q_b.val[ 0]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 9);
			q_tmp.val[ 3] = vshlq_n_u32(q_tmp.val[ 2], 9);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 23);
			q_tmp.val[ 3] = vsriq_n_u32(q_tmp.val[ 3], q_tmp.val[ 2], 23);
			q_a.val[ 2] = veorq_u32(q_tmp.val[ 1], q_a.val[ 2]);;
			q_b.val[ 2] = veorq_u32(q_tmp.val[ 3], q_b.val[ 2]);

			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 2], q_a.val[ 1]);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 2], q_b.val[ 1]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 13);
			q_tmp.val[ 3] = vshlq_n_u32(q_tmp.val[ 2], 13);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 19);
			q_tmp.val[ 3] = vsriq_n_u32(q_tmp.val[ 3], q_tmp.val[ 2], 19);
			q_a.val[ 3] = veorq_u32(q_tmp.val[ 1], q_a.val[ 3]);
			q_b.val[ 3] = veorq_u32(q_tmp.val[ 3], q_b.val[ 3]);

			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 3], q_a.val[ 2]);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 3], q_b.val[ 2]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 18);
			q_tmp.val[ 3] = vshlq_n_u32(q_tmp.val[ 2], 18);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 14);
			q_tmp.val[ 3] = vsriq_n_u32(q_tmp.val[ 3], q_tmp.val[ 2], 14);
			q_a.val[ 0] = veorq_u32(q_tmp.val[ 1], q_a.val[ 0]);
			q_b.val[ 0] = veorq_u32(q_tmp.val[ 3], q_b.val[ 0]);

		// gcc8 mixes ext with add instructions. Dual issue should still be preserved.
			q_a.val[ 1] = vextq_u32(q_a.val[ 1], q_a.val[ 1], 3);
			q_a.val[ 2] = vextq_u32(q_a.val[ 2], q_a.val[ 2], 2);
			q_a.val[ 3] = vextq_u32(q_a.val[ 3], q_a.val[ 3], 1);
			q_b.val[ 1] = vextq_u32(q_b.val[ 1], q_b.val[ 1], 3);
			q_b.val[ 2] = vextq_u32(q_b.val[ 2], q_b.val[ 2], 2);
			q_b.val[ 3] = vextq_u32(q_b.val[ 3], q_b.val[ 3], 1);
		}
		ba_a.val[ 0] = vaddq_u32(ba_a.val[ 0], q_a.val[ 0]);
		ba_a.val[ 1] = vaddq_u32(ba_a.val[ 1], q_a.val[ 1]);
		ba_a.val[ 2] = vaddq_u32(ba_a.val[ 2], q_a.val[ 2]);
		ba_a.val[ 3] = vaddq_u32(ba_a.val[ 3], q_a.val[ 3]);

		bb_a.val[ 0] = vaddq_u32(bb_a.val[ 0], q_b.val[ 0]);
		bb_a.val[ 1] = vaddq_u32(bb_a.val[ 1], q_b.val[ 1]);
		bb_a.val[ 2] = vaddq_u32(bb_a.val[ 2], q_b.val[ 2]);
		bb_a.val[ 3] = vaddq_u32(bb_a.val[ 3], q_b.val[ 3]);

		q_a = ba_a;
		q_b = bb_a;
		
		/*for (int i = 0; i < 4; i++) // code unrolled and moved below to perhaps encourage dual issue
		{
			vst1q_u32(&W[      (i * 4) ], ba_a.val[i]);
			vst1q_u32(&W[(32 + (i * 4))], bb_a.val[i]);
		}*/
		//vst4q_u32(&W[      (0 * 4) ], ba_a); //experimented with alternative store
		//vst4q_u32(&W[(32 + (0 * 4))], bb_a); //experimented with alternative store

	// loop 1 part b
 			W[ 0] = ba_a.val[ 0];
		q_a.val[ 0] = veorq_u32(ba_b.val[ 0], q_a.val[ 0]);
 			W[ 1] = ba_a.val[ 1];
		q_a.val[ 1] = veorq_u32(ba_b.val[ 1], q_a.val[ 1]);
 			W[ 2] = ba_a.val[ 2];
		q_a.val[ 2] = veorq_u32(ba_b.val[ 2], q_a.val[ 2]);
			W[ 3] = ba_a.val[ 3];
		q_a.val[ 3] = veorq_u32(ba_b.val[ 3], q_a.val[ 3]);
 
			W[ 8] = bb_a.val[ 0];
		q_b.val[ 0] = veorq_u32(bb_b.val[ 0], q_b.val[ 0]);
 			W[ 9] = bb_a.val[ 1];
		q_b.val[ 1] = veorq_u32(bb_b.val[ 1], q_b.val[ 1]);
 			W[10] = bb_a.val[ 2];
		q_b.val[ 2] = veorq_u32(bb_b.val[ 2], q_b.val[ 2]);
 			W[11] = bb_a.val[ 3];
		q_b.val[ 3] = veorq_u32(bb_b.val[ 3], q_b.val[ 3]);
		
		ba_b = q_a;		
		bb_b = q_b;

		for (register int i = 0; i < 4; i ++)
		{
			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 0], q_a.val[ 1]);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 0], q_b.val[ 1]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 7);
			q_tmp.val[ 3] = vshlq_n_u32(q_tmp.val[ 2], 7);	
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 25);
			q_tmp.val[ 3] = vsriq_n_u32(q_tmp.val[ 3], q_tmp.val[ 2], 25);	
			q_a.val[ 3] = veorq_u32(q_tmp.val[ 1], q_a.val[ 3]);
			q_b.val[ 3] = veorq_u32(q_tmp.val[ 3], q_b.val[ 3]);

			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 3], q_a.val[ 0]);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 3], q_b.val[ 0]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 9);
			q_tmp.val[ 3] = vshlq_n_u32(q_tmp.val[ 2], 9);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 23);
			q_tmp.val[ 3] = vsriq_n_u32(q_tmp.val[ 3], q_tmp.val[ 2], 23);
			q_a.val[ 2] = veorq_u32(q_tmp.val[ 1], q_a.val[ 2]);
			q_b.val[ 2] = veorq_u32(q_tmp.val[ 3], q_b.val[ 2]);

			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 2], q_a.val[ 3]);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 2], q_b.val[ 3]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 13);
			q_tmp.val[ 3] = vshlq_n_u32(q_tmp.val[ 2], 13);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 19);
			q_tmp.val[ 3] = vsriq_n_u32(q_tmp.val[ 3], q_tmp.val[ 2], 19);
			q_a.val[ 1] = veorq_u32(q_tmp.val[ 1], q_a.val[ 1]);
			q_b.val[ 1] = veorq_u32(q_tmp.val[ 3], q_b.val[ 1]);
			
			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 1], q_a.val[ 2]);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 1], q_b.val[ 2]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 18);
			q_tmp.val[ 3] = vshlq_n_u32(q_tmp.val[ 2], 18);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 14);
			q_tmp.val[ 3] = vsriq_n_u32(q_tmp.val[ 3], q_tmp.val[ 2], 14);
			q_a.val[ 0] = veorq_u32(q_tmp.val[ 1], q_a.val[ 0]);
			q_b.val[ 0] = veorq_u32(q_tmp.val[ 3], q_b.val[ 0]);
			
			q_a.val[ 1] = vextq_u32(q_a.val[ 1], q_a.val[ 1], 1);
			q_a.val[ 2] = vextq_u32(q_a.val[ 2], q_a.val[ 2], 2);
			q_a.val[ 3] = vextq_u32(q_a.val[ 3], q_a.val[ 3], 3);
			q_b.val[ 1] = vextq_u32(q_b.val[ 1], q_b.val[ 1], 1);
			q_b.val[ 2] = vextq_u32(q_b.val[ 2], q_b.val[ 2], 2);
			q_b.val[ 3] = vextq_u32(q_b.val[ 3], q_b.val[ 3], 3);
			
			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 0], q_a.val[ 3]);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 0], q_b.val[ 3]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 7);
			q_tmp.val[ 3] = vshlq_n_u32(q_tmp.val[ 2], 7);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 25);
			q_tmp.val[ 3] = vsriq_n_u32(q_tmp.val[ 3], q_tmp.val[ 2], 25);
			q_a.val[ 1] = veorq_u32(q_tmp.val[ 1], q_a.val[ 1]);
			q_b.val[ 1] = veorq_u32(q_tmp.val[ 3], q_b.val[ 1]);

			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 1], q_a.val[ 0]);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 1], q_b.val[ 0]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 9);
			q_tmp.val[ 3] = vshlq_n_u32(q_tmp.val[ 2], 9);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 23);
			q_tmp.val[ 3] = vsriq_n_u32(q_tmp.val[ 3], q_tmp.val[ 2], 23);
			q_a.val[ 2] = veorq_u32(q_tmp.val[ 1], q_a.val[ 2]);
			q_b.val[ 2] = veorq_u32(q_tmp.val[ 3], q_b.val[ 2]);

			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 2], q_a.val[ 1]);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 2], q_b.val[ 1]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 13);
			q_tmp.val[ 3] = vshlq_n_u32(q_tmp.val[ 2], 13);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 19);
			q_tmp.val[ 3] = vsriq_n_u32(q_tmp.val[ 3], q_tmp.val[ 2], 19);
			q_a.val[ 3] = veorq_u32(q_tmp.val[ 1], q_a.val[ 3]);
			q_b.val[ 3] = veorq_u32(q_tmp.val[ 3], q_b.val[ 3]);

			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 3], q_a.val[ 2]);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 3], q_b.val[ 2]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 18);
			q_tmp.val[ 3] = vshlq_n_u32(q_tmp.val[ 2], 18);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 14);
			q_tmp.val[ 3] = vsriq_n_u32(q_tmp.val[ 3], q_tmp.val[ 2], 14);
			q_a.val[ 0] = veorq_u32(q_tmp.val[ 1], q_a.val[ 0]);
			q_b.val[ 0] = veorq_u32(q_tmp.val[ 3], q_b.val[ 0]);

			q_b.val[ 1] = vextq_u32(q_b.val[ 1], q_b.val[ 1], 3);
			q_b.val[ 2] = vextq_u32(q_b.val[ 2], q_b.val[ 2], 2);
			q_b.val[ 3] = vextq_u32(q_b.val[ 3], q_b.val[ 3], 1);
			q_a.val[ 1] = vextq_u32(q_a.val[ 1], q_a.val[ 1], 3);
			q_a.val[ 2] = vextq_u32(q_a.val[ 2], q_a.val[ 2], 2);
			q_a.val[ 3] = vextq_u32(q_a.val[ 3], q_a.val[ 3], 1);
		}

		ba_b.val[ 0] = vaddq_u32(q_a.val[ 0], ba_b.val[ 0]);
		ba_b.val[ 1] = vaddq_u32(q_a.val[ 1], ba_b.val[ 1]);
		ba_b.val[ 2] = vaddq_u32(q_a.val[ 2], ba_b.val[ 2]);
		ba_b.val[ 3] = vaddq_u32(q_a.val[ 3], ba_b.val[ 3]);
		bb_b.val[ 0] = vaddq_u32(q_b.val[ 0], bb_b.val[ 0]);
		bb_b.val[ 1] = vaddq_u32(q_b.val[ 1], bb_b.val[ 1]);
		bb_b.val[ 2] = vaddq_u32(q_b.val[ 2], bb_b.val[ 2]);
		bb_b.val[ 3] = vaddq_u32(q_b.val[ 3], bb_b.val[ 3]);

		/*for (int i = 0; i < 4; i++) // stores unrolled moved to start of loop 1
		{
			vst1q_u32(&V[(     16 + (i * 4))], ba_b.val[i]);
			vst1q_u32(&V[(32 + 16 + (i * 4))], bb_b.val[i]);
		}*/
	}

 	for (register int n = 0; n < 1048576; n++)
	{
		register int one = 32 * (2 * (ba_b.val[ 0][ 0] & 1048575));
		register int two = 32 * (2 * (bb_b.val[ 0][ 0] & 1048575) + 1);
		uint32x4_t *oneneon __attribute__((__aligned__(64))) = (uint32x4_t *) __builtin_assume_aligned(&V[one], 64);
		uint32x4_t *twoneon __attribute__((__aligned__(64))) = (uint32x4_t *) __builtin_assume_aligned(&V[two], 64);
	// loop 2 part a
		ba_a.val[ 0] ^= *oneneon++;
		ba_a.val[ 1] ^= *oneneon++;
		ba_a.val[ 2] ^= *oneneon++;
		ba_a.val[ 3] ^= *oneneon++;

		ba_b.val[ 0] ^= *oneneon++;
		ba_b.val[ 1] ^= *oneneon++;
		ba_b.val[ 2] ^= *oneneon++;
		ba_b.val[ 3] ^= *oneneon++;
		 
		bb_a.val[ 0] ^= *twoneon++;
		bb_a.val[ 1] ^= *twoneon++;
		bb_a.val[ 2] ^= *twoneon++;
		bb_a.val[ 3] ^= *twoneon++;

		bb_b.val[ 0] ^= *twoneon++;
		bb_b.val[ 1] ^= *twoneon++;
		bb_b.val[ 2] ^= *twoneon++;
		bb_b.val[ 3] ^= *twoneon++;

		q_a.val[ 0] = veorq_u32(ba_b.val[ 0], ba_a.val[ 0]);
		q_a.val[ 1] = veorq_u32(ba_b.val[ 1], ba_a.val[ 1]);
		q_a.val[ 2] = veorq_u32(ba_b.val[ 2], ba_a.val[ 2]);
		q_a.val[ 3] = veorq_u32(ba_b.val[ 3], ba_a.val[ 3]);

		q_b.val[ 0] = veorq_u32(bb_b.val[ 0], bb_a.val[ 0]);
		q_b.val[ 1] = veorq_u32(bb_b.val[ 1], bb_a.val[ 1]);
		q_b.val[ 2] = veorq_u32(bb_b.val[ 2], bb_a.val[ 2]);
		q_b.val[ 3] = veorq_u32(bb_b.val[ 3], bb_a.val[ 3]);

		ba_a = q_a;
		bb_a = q_b;

		for (register int i = 0; i < 4; i++)
		{
			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 0], q_a.val[ 1]);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 0], q_b.val[ 1]);  	
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 7);
			q_tmp.val[ 3] = vshlq_n_u32(q_tmp.val[ 2], 7);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 25);
			q_tmp.val[ 3] = vsriq_n_u32(q_tmp.val[ 3], q_tmp.val[ 2], 25);	
			q_a.val[ 3] = veorq_u32(q_tmp.val[ 1], q_a.val[ 3]);
			q_b.val[ 3] = veorq_u32(q_tmp.val[ 3], q_b.val[ 3]);

			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 3], q_a.val[ 0]);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 3], q_b.val[ 0]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 9);
			q_tmp.val[ 3] = vshlq_n_u32(q_tmp.val[ 2], 9);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 23);
			q_tmp.val[ 3] = vsriq_n_u32(q_tmp.val[ 3], q_tmp.val[ 2], 23);
			q_a.val[ 2] = veorq_u32(q_tmp.val[ 1], q_a.val[ 2]);
			q_b.val[ 2] = veorq_u32(q_tmp.val[ 3], q_b.val[ 2]);

			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 2], q_a.val[ 3]);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 2], q_b.val[ 3]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 13);
			q_tmp.val[ 3] = vshlq_n_u32(q_tmp.val[ 2], 13);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 19);
			q_tmp.val[ 3] = vsriq_n_u32(q_tmp.val[ 3], q_tmp.val[ 2], 19);
			q_a.val[ 1] = veorq_u32(q_tmp.val[ 1], q_a.val[ 1]);
			q_b.val[ 1] = veorq_u32(q_tmp.val[ 3], q_b.val[ 1]);
			
			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 1], q_a.val[ 2]);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 1], q_b.val[ 2]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 18);
			q_tmp.val[ 3] = vshlq_n_u32(q_tmp.val[ 2], 18);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 14);
			q_tmp.val[ 3] = vsriq_n_u32(q_tmp.val[ 3], q_tmp.val[ 2], 14);
			q_a.val[ 0] = veorq_u32(q_tmp.val[ 1], q_a.val[ 0]);
			q_b.val[ 0] = veorq_u32(q_tmp.val[ 3], q_b.val[ 0]);
			
			q_a.val[ 1] = vextq_u32(q_a.val[ 1], q_a.val[ 1], 1);
			q_a.val[ 2] = vextq_u32(q_a.val[ 2], q_a.val[ 2], 2);
			q_a.val[ 3] = vextq_u32(q_a.val[ 3], q_a.val[ 3], 3);
			q_b.val[ 1] = vextq_u32(q_b.val[ 1], q_b.val[ 1], 1);
			q_b.val[ 2] = vextq_u32(q_b.val[ 2], q_b.val[ 2], 2);
			q_b.val[ 3] = vextq_u32(q_b.val[ 3], q_b.val[ 3], 3);
			
			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 0], q_a.val[ 3]);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 0], q_b.val[ 3]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 7);
			q_tmp.val[ 3] = vshlq_n_u32(q_tmp.val[ 2], 7);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 25);
			q_tmp.val[ 3] = vsriq_n_u32(q_tmp.val[ 3], q_tmp.val[ 2], 25);
			q_a.val[ 1] = veorq_u32(q_tmp.val[ 1], q_a.val[ 1]);
			q_b.val[ 1] = veorq_u32(q_tmp.val[ 3], q_b.val[ 1]);

			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 1], q_a.val[ 0]);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 1], q_b.val[ 0]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 9);
			q_tmp.val[ 3] = vshlq_n_u32(q_tmp.val[ 2], 9);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 23);
			q_tmp.val[ 3] = vsriq_n_u32(q_tmp.val[ 3], q_tmp.val[ 2], 23);
			q_a.val[ 2] = veorq_u32(q_tmp.val[ 1], q_a.val[ 2]);
			q_b.val[ 2] = veorq_u32(q_tmp.val[ 3], q_b.val[ 2]);

			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 2], q_a.val[ 1]);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 2], q_b.val[ 1]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 13);
			q_tmp.val[ 3] = vshlq_n_u32(q_tmp.val[ 2], 13);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 19);
			q_tmp.val[ 3] = vsriq_n_u32(q_tmp.val[ 3], q_tmp.val[ 2], 19);
			q_a.val[ 3] = veorq_u32(q_tmp.val[ 1], q_a.val[ 3]);
			q_b.val[ 3] = veorq_u32(q_tmp.val[ 3], q_b.val[ 3]);

			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 3], q_a.val[ 2]);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 3], q_b.val[ 2]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 18);
			q_tmp.val[ 3] = vshlq_n_u32(q_tmp.val[ 2], 18);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 14);
			q_tmp.val[ 3] = vsriq_n_u32(q_tmp.val[ 3], q_tmp.val[ 2], 14);
			q_a.val[ 0] = veorq_u32(q_tmp.val[ 1], q_a.val[ 0]);
			q_b.val[ 0] = veorq_u32(q_tmp.val[ 3], q_b.val[ 0]);

			q_a.val[ 1] = vextq_u32(q_a.val[ 1], q_a.val[ 1], 3);
			q_a.val[ 2] = vextq_u32(q_a.val[ 2], q_a.val[ 2], 2);
			q_a.val[ 3] = vextq_u32(q_a.val[ 3], q_a.val[ 3], 1);
			q_b.val[ 1] = vextq_u32(q_b.val[ 1], q_b.val[ 1], 3);
			q_b.val[ 2] = vextq_u32(q_b.val[ 2], q_b.val[ 2], 2);
			q_b.val[ 3] = vextq_u32(q_b.val[ 3], q_b.val[ 3], 1);
		}
		ba_a.val[ 0] = vaddq_u32(ba_a.val[ 0], q_a.val[ 0]);
		ba_a.val[ 1] = vaddq_u32(ba_a.val[ 1], q_a.val[ 1]);
		ba_a.val[ 2] = vaddq_u32(ba_a.val[ 2], q_a.val[ 2]);
		ba_a.val[ 3] = vaddq_u32(ba_a.val[ 3], q_a.val[ 3]);

		bb_a.val[ 0] = vaddq_u32(bb_a.val[ 0], q_b.val[ 0]);
		bb_a.val[ 1] = vaddq_u32(bb_a.val[ 1], q_b.val[ 1]);
		bb_a.val[ 2] = vaddq_u32(bb_a.val[ 2], q_b.val[ 2]);
		bb_a.val[ 3] = vaddq_u32(bb_a.val[ 3], q_b.val[ 3]);

		q_a = ba_a;
		q_b = bb_a;

	// loop 2 b
		q_a.val[ 0] = veorq_u32(ba_b.val[ 0], q_a.val[ 0]);
		q_a.val[ 1] = veorq_u32(ba_b.val[ 1], q_a.val[ 1]);
		q_a.val[ 2] = veorq_u32(ba_b.val[ 2], q_a.val[ 2]);
		q_a.val[ 3] = veorq_u32(ba_b.val[ 3], q_a.val[ 3]);

		q_b.val[ 0] = veorq_u32(bb_b.val[ 0], q_b.val[ 0]);
		q_b.val[ 1] = veorq_u32(bb_b.val[ 1], q_b.val[ 1]);
		q_b.val[ 2] = veorq_u32(bb_b.val[ 2], q_b.val[ 2]);
		q_b.val[ 3] = veorq_u32(bb_b.val[ 3], q_b.val[ 3]);

		ba_b = q_a;
		bb_b = q_b;

		for (register int i = 0; i < 3; i++)
		{
			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 0], q_a.val[ 1]);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 0], q_b.val[ 1]);	
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 7);	
			q_tmp.val[ 3] = vshlq_n_u32(q_tmp.val[ 2], 7);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 25);
			q_tmp.val[ 3] = vsriq_n_u32(q_tmp.val[ 3], q_tmp.val[ 2], 25);
			q_a.val[ 3] = veorq_u32(q_tmp.val[ 1], q_a.val[ 3]);
			q_b.val[ 3] = veorq_u32(q_tmp.val[ 3], q_b.val[ 3]);

			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 3], q_a.val[ 0]);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 3], q_b.val[ 0]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 9);
			q_tmp.val[ 3] = vshlq_n_u32(q_tmp.val[ 2], 9);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 23);
			q_tmp.val[ 3] = vsriq_n_u32(q_tmp.val[ 3], q_tmp.val[ 2], 23);
			q_a.val[ 2] = veorq_u32(q_tmp.val[ 1], q_a.val[ 2]);
			q_b.val[ 2] = veorq_u32(q_tmp.val[ 3], q_b.val[ 2]);

			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 2], q_a.val[ 3]);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 2], q_b.val[ 3]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 13);
			q_tmp.val[ 3] = vshlq_n_u32(q_tmp.val[ 2], 13);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 19);
			q_tmp.val[ 3] = vsriq_n_u32(q_tmp.val[ 3], q_tmp.val[ 2], 19);
			q_a.val[ 1] = veorq_u32(q_tmp.val[ 1], q_a.val[ 1]);
			q_b.val[ 1] = veorq_u32(q_tmp.val[ 3], q_b.val[ 1]);
			
			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 1], q_a.val[ 2]);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 1], q_b.val[ 2]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 18);
			q_tmp.val[ 3] = vshlq_n_u32(q_tmp.val[ 2], 18);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 14);
			q_tmp.val[ 3] = vsriq_n_u32(q_tmp.val[ 3], q_tmp.val[ 2], 14);
			q_a.val[ 0] = veorq_u32(q_tmp.val[ 1], q_a.val[ 0]);
			q_b.val[ 0] = veorq_u32(q_tmp.val[ 3], q_b.val[ 0]);
			
			q_a.val[ 1] = vextq_u32(q_a.val[ 1], q_a.val[ 1], 1);
			q_a.val[ 2] = vextq_u32(q_a.val[ 2], q_a.val[ 2], 2);
			q_a.val[ 3] = vextq_u32(q_a.val[ 3], q_a.val[ 3], 3);
			q_b.val[ 1] = vextq_u32(q_b.val[ 1], q_b.val[ 1], 1);
			q_b.val[ 2] = vextq_u32(q_b.val[ 2], q_b.val[ 2], 2);
			q_b.val[ 3] = vextq_u32(q_b.val[ 3], q_b.val[ 3], 3);
			
			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 0], q_a.val[ 3]);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 0], q_b.val[ 3]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 7);
			q_tmp.val[ 3] = vshlq_n_u32(q_tmp.val[ 2], 7);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 25);
			q_tmp.val[ 3] = vsriq_n_u32(q_tmp.val[ 3], q_tmp.val[ 2], 25);
			q_a.val[ 1] = veorq_u32(q_tmp.val[ 1], q_a.val[ 1]);
			q_b.val[ 1] = veorq_u32(q_tmp.val[ 3], q_b.val[ 1]);;

			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 1], q_a.val[ 0]);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 1], q_b.val[ 0]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 9);
			q_tmp.val[ 3] = vshlq_n_u32(q_tmp.val[ 2], 9);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 23);
			q_tmp.val[ 3] = vsriq_n_u32(q_tmp.val[ 3], q_tmp.val[ 2], 23);
			q_a.val[ 2] = veorq_u32(q_tmp.val[ 1], q_a.val[ 2]);
			q_b.val[ 2] = veorq_u32(q_tmp.val[ 3], q_b.val[ 2]);

			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 2], q_a.val[ 1]);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 2], q_b.val[ 1]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 13);
			q_tmp.val[ 3] = vshlq_n_u32(q_tmp.val[ 2], 13);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 19);
			q_tmp.val[ 3] = vsriq_n_u32(q_tmp.val[ 3], q_tmp.val[ 2], 19);
			q_a.val[ 3] = veorq_u32(q_tmp.val[ 1], q_a.val[ 3]);
			q_b.val[ 3] = veorq_u32(q_tmp.val[ 3], q_b.val[ 3]);

			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 3], q_a.val[ 2]);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 3], q_b.val[ 2]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 18);
			q_tmp.val[ 3] = vshlq_n_u32(q_tmp.val[ 2], 18);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 14);
			q_tmp.val[ 3] = vsriq_n_u32(q_tmp.val[ 3], q_tmp.val[ 2], 14);
			q_a.val[ 0] = veorq_u32(q_tmp.val[ 1], q_a.val[ 0]);
			q_b.val[ 0] = veorq_u32(q_tmp.val[ 3], q_b.val[ 0]);

			q_a.val[ 1] = vextq_u32(q_a.val[ 1], q_a.val[ 1], 3);
			q_a.val[ 2] = vextq_u32(q_a.val[ 2], q_a.val[ 2], 2);
			q_a.val[ 3] = vextq_u32(q_a.val[ 3], q_a.val[ 3], 1);
			q_b.val[ 1] = vextq_u32(q_b.val[ 1], q_b.val[ 1], 3);
			q_b.val[ 2] = vextq_u32(q_b.val[ 2], q_b.val[ 2], 2);
			q_b.val[ 3] = vextq_u32(q_b.val[ 3], q_b.val[ 3], 1);
		}
		{
		//1
			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 0], q_a.val[ 1]);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 0], q_b.val[ 1]);  	
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 7);	
			q_tmp.val[ 3] = vshlq_n_u32(q_tmp.val[ 2], 7);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 25);
			q_tmp.val[ 3] = vsriq_n_u32(q_tmp.val[ 3], q_tmp.val[ 2], 25);
			q_a.val[ 3] = veorq_u32(q_tmp.val[ 1], q_a.val[ 3]);
			q_b.val[ 3] = veorq_u32(q_tmp.val[ 3], q_b.val[ 3]);
		//2
			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 3], q_a.val[ 0]);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 3], q_b.val[ 0]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 9);
			q_tmp.val[ 3] = vshlq_n_u32(q_tmp.val[ 2], 9);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 23);
			q_tmp.val[ 3] = vsriq_n_u32(q_tmp.val[ 3], q_tmp.val[ 2], 23);
			q_a.val[ 2] = veorq_u32(q_tmp.val[ 1], q_a.val[ 2]);
			q_b.val[ 2] = veorq_u32(q_tmp.val[ 3], q_b.val[ 2]);
		//3
			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 2], q_a.val[ 3]);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 2], q_b.val[ 3]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 13);
			q_tmp.val[ 3] = vshlq_n_u32(q_tmp.val[ 2], 13);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 19);
			q_tmp.val[ 3] = vsriq_n_u32(q_tmp.val[ 3], q_tmp.val[ 2], 19);
			q_a.val[ 1] = veorq_u32(q_tmp.val[ 1], q_a.val[ 1]);
			q_b.val[ 1] = veorq_u32(q_tmp.val[ 3], q_b.val[ 1]);
		//4
			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 1], q_a.val[ 2]);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 1], q_b.val[ 2]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 18);
			q_tmp.val[ 3] = vshlq_n_u32(q_tmp.val[ 2], 18);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 14);
			q_tmp.val[ 3] = vsriq_n_u32(q_tmp.val[ 3], q_tmp.val[ 2], 14);
			q_a.val[ 0] = veorq_u32(q_tmp.val[ 1], q_a.val[ 0]);
			q_b.val[ 0] = veorq_u32(q_tmp.val[ 3], q_b.val[ 0]);
			
			q_a.val[ 1] = vextq_u32(q_a.val[ 1], q_a.val[ 1], 1);
			q_a.val[ 2] = vextq_u32(q_a.val[ 2], q_a.val[ 2], 2);
			q_a.val[ 3] = vextq_u32(q_a.val[ 3], q_a.val[ 3], 3);
			q_b.val[ 1] = vextq_u32(q_b.val[ 1], q_b.val[ 1], 1);
			q_b.val[ 2] = vextq_u32(q_b.val[ 2], q_b.val[ 2], 2);
			q_b.val[ 3] = vextq_u32(q_b.val[ 3], q_b.val[ 3], 3);
		//5
			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 0], q_a.val[ 3]);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 0], q_b.val[ 3]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 7);
			q_tmp.val[ 3] = vshlq_n_u32(q_tmp.val[ 2], 7);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 25);
			q_tmp.val[ 3] = vsriq_n_u32(q_tmp.val[ 3], q_tmp.val[ 2], 25);
			q_a.val[ 1] = veorq_u32(q_tmp.val[ 1], q_a.val[ 1]);
			q_b.val[ 1] = veorq_u32(q_tmp.val[ 3], q_b.val[ 1]);
		//6
			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 1], q_a.val[ 0]);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 1], q_b.val[ 0]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 9);
			q_tmp.val[ 3] = vshlq_n_u32(q_tmp.val[ 2], 9);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 23);
			q_tmp.val[ 3] = vsriq_n_u32(q_tmp.val[ 3], q_tmp.val[ 2], 23);
			q_a.val[ 2] = veorq_u32(q_tmp.val[ 1], q_a.val[ 2]);
			q_b.val[ 2] = veorq_u32(q_tmp.val[ 3], q_b.val[ 2]);
		//7
			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 2], q_a.val[ 1]);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 2], q_b.val[ 1]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 13);
			q_tmp.val[ 3] = vshlq_n_u32(q_tmp.val[ 2], 13);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 19);
			q_tmp.val[ 3] = vsriq_n_u32(q_tmp.val[ 3], q_tmp.val[ 2], 19);
			q_a.val[ 3] = veorq_u32(q_tmp.val[ 1], q_a.val[ 3]);
			q_b.val[ 3] = veorq_u32(q_tmp.val[ 3], q_b.val[ 3]);
		//8
			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 3], q_a.val[ 2]);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 3], q_b.val[ 2]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 18);
			q_tmp.val[ 3] = vshlq_n_u32(q_tmp.val[ 2], 18);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 14);
			q_tmp.val[ 3] = vsriq_n_u32(q_tmp.val[ 3], q_tmp.val[ 2], 14);
			q_a.val[ 0] = veorq_u32(q_tmp.val[ 1], q_a.val[ 0]);
			q_b.val[ 0] = veorq_u32(q_tmp.val[ 3], q_b.val[ 0]);
				bb_b.val[ 0] = vaddq_u32(q_b.val[ 0], bb_b.val[ 0]);
				ba_b.val[ 0] = vaddq_u32(q_a.val[ 0], ba_b.val[ 0]);
					one =	32 * (2 * (ba_b.val[ 0][ 0] & 1048575));	
					two =	32 * (2 * (bb_b.val[ 0][ 0] & 1048575) + 1);
				// Cast pointer suitable for 64 byte cache line size
					__builtin_prefetch((uint32x4x4_t *) &V[one]);
					__builtin_prefetch((uint32x4x4_t *) &V[one + 16]);
					__builtin_prefetch((uint32x4x4_t *) &V[two]);
					__builtin_prefetch((uint32x4x4_t *) &V[two + 16]);

			q_a.val[ 1] = vextq_u32(q_a.val[ 1], q_a.val[ 1], 3);
			q_a.val[ 2] = vextq_u32(q_a.val[ 2], q_a.val[ 2], 2);
			q_a.val[ 3] = vextq_u32(q_a.val[ 3], q_a.val[ 3], 1);
			q_b.val[ 1] = vextq_u32(q_b.val[ 1], q_b.val[ 1], 3);
			q_b.val[ 2] = vextq_u32(q_b.val[ 2], q_b.val[ 2], 2);
			q_b.val[ 3] = vextq_u32(q_b.val[ 3], q_b.val[ 3], 1);
		}

		ba_b.val[ 1] = vaddq_u32(q_a.val[ 1], ba_b.val[ 1]);
		ba_b.val[ 2] = vaddq_u32(q_a.val[ 2], ba_b.val[ 2]);
		ba_b.val[ 3] = vaddq_u32(q_a.val[ 3], ba_b.val[ 3]);
		bb_b.val[ 1] = vaddq_u32(q_b.val[ 1], bb_b.val[ 1]);
		bb_b.val[ 2] = vaddq_u32(q_b.val[ 2], bb_b.val[ 2]);
		bb_b.val[ 3] = vaddq_u32(q_b.val[ 3], bb_b.val[ 3]);
	}

	vst1q_u32(&B[ 0],	ba_a.val[ 0]);
	vst1q_u32(&B[ 4],	ba_a.val[ 1]);
	vst1q_u32(&B[ 8],	ba_a.val[ 2]);
	vst1q_u32(&B[12],	ba_a.val[ 3]);

	vst1q_u32(&B[16 + 0],	ba_b.val[ 0]);
	vst1q_u32(&B[16 + 4],	ba_b.val[ 1]);
	vst1q_u32(&B[16 + 8],	ba_b.val[ 2]);
	vst1q_u32(&B[16 + 12],	ba_b.val[ 3]);

	vst1q_u32(&B[32 + 0],	bb_a.val[ 0]);
	vst1q_u32(&B[32 + 4],	bb_a.val[ 1]);
	vst1q_u32(&B[32 + 8],	bb_a.val[ 2]);
	vst1q_u32(&B[32 + 12],	bb_a.val[ 3]);

	vst1q_u32(&B[32 + 16 + 0],  bb_b.val[ 0]);
	vst1q_u32(&B[32 + 16 + 4],  bb_b.val[ 1]);
	vst1q_u32(&B[32 + 16 + 8],  bb_b.val[ 2]);
	vst1q_u32(&B[32 + 16 + 12], bb_b.val[ 3]);

	scrypt_shuffle(&B[0  + 0]);
	scrypt_shuffle(&B[16 + 0]);
	scrypt_shuffle(&B[0 + 32]);
	scrypt_shuffle(&B[16 + 32]);
}
#pragma GCC pop_options
#endif
// restore normal gcc options
//#pragma GCC pop_options

/* 
* scrypt_core_3way disabled for aarch64/armv8. Refer to scrypt_core_2way for notes as to why. 
* Code left in as comment for reference purposes
*/
/*
static inline void scrypt_core_3way(uint32_t B[32 * 3], uint32_t *V, uint32_t N)
{
	uint32_t* W = V;

	scrypt_shuffle(&B[0  + 0]);
	scrypt_shuffle(&B[16 + 0]);
	scrypt_shuffle(&B[0 + 32]);
	scrypt_shuffle(&B[16 + 32]);
	scrypt_shuffle(&B[0 + 64]);
	scrypt_shuffle(&B[16 + 64]);

	uint32x4x4_t q_a, q_b, q_c, q_tmp;
	uint32x4x4_t ba_a, bb_a, bc_a, ba_b, bb_b, bc_b;

	ba_a.val[ 0] = vld1q_u32(&B[( 0) / 4]);
	ba_a.val[ 1] = vld1q_u32(&B[(16) / 4]);
	ba_a.val[ 2] = vld1q_u32(&B[(32) / 4]);
	ba_a.val[ 3] = vld1q_u32(&B[(48) / 4]);
	ba_b.val[ 0] = vld1q_u32(&B[(0 + 64 + 0) / 4]);
	ba_b.val[ 1] = vld1q_u32(&B[(0 + 64 + 16) / 4]);
	ba_b.val[ 2] = vld1q_u32(&B[(0 + 64 + 32) / 4]);
	ba_b.val[ 3] = vld1q_u32(&B[(0 + 64 + 48) / 4]);

	bb_a.val[ 0] = vld1q_u32(&B[(128 +  0) / 4]);
	bb_a.val[ 1] = vld1q_u32(&B[(128 + 16) / 4]);
	bb_a.val[ 2] = vld1q_u32(&B[(128 + 32) / 4]);
	bb_a.val[ 3] = vld1q_u32(&B[(128 + 48) / 4]);
	bb_b.val[ 0] = vld1q_u32(&B[(128 + 64 + 0) / 4]);
	bb_b.val[ 1] = vld1q_u32(&B[(128 + 64 + 16) / 4]);
	bb_b.val[ 2] = vld1q_u32(&B[(128 + 64 + 32) / 4]);
	bb_b.val[ 3] = vld1q_u32(&B[(128 + 64 + 48) / 4]);
	
	bc_a.val[ 0] = vld1q_u32(&B[(256 + 0) / 4]);
	bc_a.val[ 1] = vld1q_u32(&B[(256 + 16) / 4]);
	bc_a.val[ 2] = vld1q_u32(&B[(256 + 32) / 4]);
	bc_a.val[ 3] = vld1q_u32(&B[(256 + 48) / 4]);
	bc_b.val[ 0] = vld1q_u32(&B[(256 + 64 + 0) / 4]);
	bc_b.val[ 1] = vld1q_u32(&B[(256 + 64 + 16) / 4]);
	bc_b.val[ 2] = vld1q_u32(&B[(256 + 64 + 32) / 4]);
	bc_b.val[ 3] = vld1q_u32(&B[(256 + 64 + 48) / 4]);

	// prep

	vst1q_u32(&V[( 0) / 4], ba_a.val[ 0]);
	vst1q_u32(&V[(16) / 4], ba_a.val[ 1]);
	vst1q_u32(&V[(32) / 4], ba_a.val[ 2]);
	vst1q_u32(&V[(48) / 4], ba_a.val[ 3]);
	vst1q_u32(&V[(64) / 4],  ba_b.val[ 0]);
	vst1q_u32(&V[(80) / 4],  ba_b.val[ 1]);
	vst1q_u32(&V[(96) / 4],  ba_b.val[ 2]);
	vst1q_u32(&V[(112) / 4], ba_b.val[ 3]);

	vst1q_u32(&V[(128 +  0) / 4], bb_a.val[ 0]);
	vst1q_u32(&V[(128 + 16) / 4], bb_a.val[ 1]);
	vst1q_u32(&V[(128 + 32) / 4], bb_a.val[ 2]);
	vst1q_u32(&V[(128 + 48) / 4], bb_a.val[ 3]);
	vst1q_u32(&V[(128 + 64) / 4],  bb_b.val[ 0]);
	vst1q_u32(&V[(128 + 80) / 4],  bb_b.val[ 1]);
	vst1q_u32(&V[(128 + 96) / 4],  bb_b.val[ 2]);
	vst1q_u32(&V[(128 + 112) / 4], bb_b.val[ 3]);

	vst1q_u32(&V[(256 +  0) / 4], bc_a.val[ 0]);
	vst1q_u32(&V[(256 + 16) / 4], bc_a.val[ 1]);
	vst1q_u32(&V[(256 + 32) / 4], bc_a.val[ 2]);
	vst1q_u32(&V[(256 + 48) / 4], bc_a.val[ 3]);
	vst1q_u32(&V[(256 + 64) / 4], bc_b.val[ 0]);
	vst1q_u32(&V[(256 + 80) / 4], bc_b.val[ 1]);
	vst1q_u32(&V[(256 + 96) / 4], bc_b.val[ 2]);
	vst1q_u32(&V[(256 + 112) / 4],bc_b.val[ 3]);

	V += 96;

	for (int n = 0; n < N; n++)
	{
	// loop 1 part a
		q_a.val[ 0] = veorq_u32(ba_b.val[ 0], ba_a.val[ 0]);
		q_a.val[ 1] = veorq_u32(ba_b.val[ 1], ba_a.val[ 1]);
		q_a.val[ 2] = veorq_u32(ba_b.val[ 2], ba_a.val[ 2]);
		q_a.val[ 3] = veorq_u32(ba_b.val[ 3], ba_a.val[ 3]);

		q_b.val[ 0] = veorq_u32(bb_b.val[ 0], bb_a.val[ 0]);
		q_b.val[ 1] = veorq_u32(bb_b.val[ 1], bb_a.val[ 1]);
		q_b.val[ 2] = veorq_u32(bb_b.val[ 2], bb_a.val[ 2]);
		q_b.val[ 3] = veorq_u32(bb_b.val[ 3], bb_a.val[ 3]);

		q_c.val[ 0] = veorq_u32(bc_b.val[ 0], bc_a.val[ 0]);
		q_c.val[ 1] = veorq_u32(bc_b.val[ 1], bc_a.val[ 1]);
		q_c.val[ 2] = veorq_u32(bc_b.val[ 2], bc_a.val[ 2]);
		q_c.val[ 3] = veorq_u32(bc_b.val[ 3], bc_a.val[ 3]);

		ba_a = q_a;
		bb_a = q_b;
		bc_a = q_c;

		for (int i = 0; i < 4; i ++)
		{
			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 0], q_a.val[ 1]);  	
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 7);	
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 0], q_b.val[ 1]);  	
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 25);
			q_a.val[ 3] = veorq_u32(q_tmp.val[ 1], q_a.val[ 3]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 2], 7);
			q_tmp.val[ 3] = vaddq_u32(q_c.val[ 0], q_c.val[ 1]); 
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 2], 25);
			q_b.val[ 3] = veorq_u32(q_tmp.val[ 1], q_b.val[ 3]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 3], 7); 				
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 3], 25);				
			q_c.val[ 3] = veorq_u32(q_tmp.val[ 1], q_c.val[ 3]);

			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 3], q_a.val[ 0]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 9);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 3], q_b.val[ 0]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 23);
			q_a.val[ 2] = veorq_u32(q_tmp.val[ 1], q_a.val[ 2]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 2], 9);
			q_tmp.val[ 3] = vaddq_u32(q_c.val[ 3], q_c.val[ 0]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 2], 23);
			q_b.val[ 2] = veorq_u32(q_tmp.val[ 1], q_b.val[ 2]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 3], 9);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 3], 23);
			q_c.val[ 2] = veorq_u32(q_tmp.val[ 1], q_c.val[ 2]);

			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 2], q_a.val[ 3]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 13);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 2], q_b.val[ 3]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 19);
			q_a.val[ 1] = veorq_u32(q_tmp.val[ 1], q_a.val[ 1]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 2], 13);
			q_tmp.val[ 3] = vaddq_u32(q_c.val[ 2], q_c.val[ 3]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 2], 19);
			q_b.val[ 1] = veorq_u32(q_tmp.val[ 1], q_b.val[ 1]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 3], 13);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 3], 19);
			q_c.val[ 1] = veorq_u32(q_tmp.val[ 1], q_c.val[ 1]);
			
			q_a.val[ 3] = vextq_u32(q_a.val[ 3], q_a.val[ 3], 3);
			q_b.val[ 3] = vextq_u32(q_b.val[ 3], q_b.val[ 3], 3);
			q_c.val[ 3] = vextq_u32(q_c.val[ 3], q_c.val[ 3], 3);
			
			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 1], q_a.val[ 2]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 18);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 1], q_b.val[ 2]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 14);
			q_a.val[ 0] = veorq_u32(q_tmp.val[ 1], q_a.val[ 0]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 2], 18);
			q_tmp.val[ 3] = vaddq_u32(q_c.val[ 1], q_c.val[ 2]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 2], 14);
			q_b.val[ 0] = veorq_u32(q_tmp.val[ 1], q_b.val[ 0]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 3], 18);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 3], 14);
			q_c.val[ 0] = veorq_u32(q_tmp.val[ 1], q_c.val[ 0]);
			
			q_a.val[ 2] = vextq_u32(q_a.val[ 2], q_a.val[ 2], 2);
			q_b.val[ 2] = vextq_u32(q_b.val[ 2], q_b.val[ 2], 2);
			q_c.val[ 2] = vextq_u32(q_c.val[ 2], q_c.val[ 2], 2);
			
			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 0], q_a.val[ 3]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 7);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 0], q_b.val[ 3]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 25);
			q_a.val[ 1] = vextq_u32(q_a.val[ 1], q_a.val[ 1], 1);
			q_a.val[ 1] = veorq_u32(q_tmp.val[ 1], q_a.val[ 1]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 2], 7);
			q_tmp.val[ 3] = vaddq_u32(q_c.val[ 0], q_c.val[ 3]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 2], 25);
			q_b.val[ 1] = vextq_u32(q_b.val[ 1], q_b.val[ 1], 1);
			q_b.val[ 1] = veorq_u32(q_tmp.val[ 1], q_b.val[ 1]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 3], 7);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 3], 25);
			q_c.val[ 1] = vextq_u32(q_c.val[ 1], q_c.val[ 1], 1);
			q_c.val[ 1] = veorq_u32(q_tmp.val[ 1], q_c.val[ 1]);

			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 1], q_a.val[ 0]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 9);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 1], q_b.val[ 0]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 23);
			q_a.val[ 2] = veorq_u32(q_tmp.val[ 1], q_a.val[ 2]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 2], 9);
			q_tmp.val[ 3] = vaddq_u32(q_c.val[ 1], q_c.val[ 0]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 2], 23);
			q_b.val[ 2] = veorq_u32(q_tmp.val[ 1], q_b.val[ 2]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 3], 9);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 3], 23);
			q_c.val[ 2] = veorq_u32(q_tmp.val[ 1], q_c.val[ 2]);

			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 2], q_a.val[ 1]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 13);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 2], q_b.val[ 1]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 19);
			q_a.val[ 3] = veorq_u32(q_tmp.val[ 1], q_a.val[ 3]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 2], 13);
			q_tmp.val[ 3] = vaddq_u32(q_c.val[ 2], q_c.val[ 1]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 2], 19);
			q_b.val[ 3] = veorq_u32(q_tmp.val[ 1], q_b.val[ 3]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 3], 13);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 3], 19);
			q_c.val[ 3] = veorq_u32(q_tmp.val[ 1], q_c.val[ 3]);
			q_a.val[ 1] = vextq_u32(q_a.val[ 1], q_a.val[ 1], 3);
			q_b.val[ 1] = vextq_u32(q_b.val[ 1], q_b.val[ 1], 3);
			q_c.val[ 1] = vextq_u32(q_c.val[ 1], q_c.val[ 1], 3);

			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 3], q_a.val[ 2]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 18);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 3], q_b.val[ 2]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 14);
			q_a.val[ 2] = vextq_u32(q_a.val[ 2], q_a.val[ 2], 2);
			q_b.val[ 2] = vextq_u32(q_b.val[ 2], q_b.val[ 2], 2);
			q_a.val[ 0] = veorq_u32(q_tmp.val[ 1], q_a.val[ 0]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 2], 18);
			q_tmp.val[ 3] = vaddq_u32(q_c.val[ 3], q_c.val[ 2]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 2], 14);
			q_c.val[ 2] = vextq_u32(q_c.val[ 2], q_c.val[ 2], 2);
			q_b.val[ 3] = vextq_u32(q_b.val[ 3], q_b.val[ 3], 1);
			q_b.val[ 0] = veorq_u32(q_tmp.val[ 1], q_b.val[ 0]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 3], 18);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 3], 14);
			q_a.val[ 3] = vextq_u32(q_a.val[ 3], q_a.val[ 3], 1);
			q_c.val[ 3] = vextq_u32(q_c.val[ 3], q_c.val[ 3], 1);
			q_c.val[ 0] = veorq_u32(q_tmp.val[ 1], q_c.val[ 0]);
		}
		ba_a.val[ 0] = vaddq_u32(ba_a.val[ 0], q_a.val[ 0]);
		ba_a.val[ 1] = vaddq_u32(ba_a.val[ 1], q_a.val[ 1]);
		ba_a.val[ 2] = vaddq_u32(ba_a.val[ 2], q_a.val[ 2]);
		ba_a.val[ 3] = vaddq_u32(ba_a.val[ 3], q_a.val[ 3]);

		q_a = ba_a;

		bb_a.val[ 0] = vaddq_u32(bb_a.val[ 0], q_b.val[ 0]);
		bb_a.val[ 1] = vaddq_u32(bb_a.val[ 1], q_b.val[ 1]);
		bb_a.val[ 2] = vaddq_u32(bb_a.val[ 2], q_b.val[ 2]);
		bb_a.val[ 3] = vaddq_u32(bb_a.val[ 3], q_b.val[ 3]);

		q_b = bb_a;

		bc_a.val[ 0] = vaddq_u32(bc_a.val[ 0], q_c.val[ 0]);
		bc_a.val[ 1] = vaddq_u32(bc_a.val[ 1], q_c.val[ 1]);
		bc_a.val[ 2] = vaddq_u32(bc_a.val[ 2], q_c.val[ 2]);
		bc_a.val[ 3] = vaddq_u32(bc_a.val[ 3], q_c.val[ 3]);

		q_c = bc_a;
		
		for (int i = 0; i < 4; i++)
		{
			vst1q_u32(&V[      (i * 4) ], ba_a.val[i]);
			vst1q_u32(&V[(32 + (i * 4))], bb_a.val[i]);
			vst1q_u32(&V[(64 + (i * 4))], bc_a.val[i]);
		}

	// loop 1 part b

		q_a.val[ 0] = veorq_u32(ba_b.val[ 0], q_a.val[ 0]);
		q_a.val[ 1] = veorq_u32(ba_b.val[ 1], q_a.val[ 1]);
		q_a.val[ 2] = veorq_u32(ba_b.val[ 2], q_a.val[ 2]);
		q_a.val[ 3] = veorq_u32(ba_b.val[ 3], q_a.val[ 3]);
		ba_b = q_a;

		q_b.val[ 0] = veorq_u32(bb_b.val[ 0], q_b.val[ 0]);
		q_b.val[ 1] = veorq_u32(bb_b.val[ 1], q_b.val[ 1]);
		q_b.val[ 2] = veorq_u32(bb_b.val[ 2], q_b.val[ 2]);
		q_b.val[ 3] = veorq_u32(bb_b.val[ 3], q_b.val[ 3]);
		bb_b = q_b;

		q_c.val[ 0] = veorq_u32(bc_b.val[ 0], q_c.val[ 0]);
		q_c.val[ 1] = veorq_u32(bc_b.val[ 1], q_c.val[ 1]);
		q_c.val[ 2] = veorq_u32(bc_b.val[ 2], q_c.val[ 2]);
		q_c.val[ 3] = veorq_u32(bc_b.val[ 3], q_c.val[ 3]);
		bc_b = q_c;


		for (int i = 0; i < 4; i ++)
		{
			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 0], q_a.val[ 1]);  	
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 7);	
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 0], q_b.val[ 1]);  	
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 25);
			q_a.val[ 3] = veorq_u32(q_tmp.val[ 1], q_a.val[ 3]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 2], 7);
			q_tmp.val[ 3] = vaddq_u32(q_c.val[ 0], q_c.val[ 1]); 
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 2], 25);
			q_b.val[ 3] = veorq_u32(q_tmp.val[ 1], q_b.val[ 3]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 3], 7); 				
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 3], 25);				
			q_c.val[ 3] = veorq_u32(q_tmp.val[ 1], q_c.val[ 3]);

			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 3], q_a.val[ 0]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 9);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 3], q_b.val[ 0]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 23);
			q_a.val[ 2] = veorq_u32(q_tmp.val[ 1], q_a.val[ 2]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 2], 9);
			q_tmp.val[ 3] = vaddq_u32(q_c.val[ 3], q_c.val[ 0]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 2], 23);
			q_b.val[ 2] = veorq_u32(q_tmp.val[ 1], q_b.val[ 2]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 3], 9);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 3], 23);
			q_c.val[ 2] = veorq_u32(q_tmp.val[ 1], q_c.val[ 2]);

			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 2], q_a.val[ 3]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 13);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 2], q_b.val[ 3]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 19);
			q_a.val[ 1] = veorq_u32(q_tmp.val[ 1], q_a.val[ 1]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 2], 13);
			q_tmp.val[ 3] = vaddq_u32(q_c.val[ 2], q_c.val[ 3]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 2], 19);
			q_b.val[ 1] = veorq_u32(q_tmp.val[ 1], q_b.val[ 1]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 3], 13);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 3], 19);
			q_c.val[ 1] = veorq_u32(q_tmp.val[ 1], q_c.val[ 1]);
			
			q_a.val[ 3] = vextq_u32(q_a.val[ 3], q_a.val[ 3], 3);
			q_b.val[ 3] = vextq_u32(q_b.val[ 3], q_b.val[ 3], 3);
			q_c.val[ 3] = vextq_u32(q_c.val[ 3], q_c.val[ 3], 3);
			
			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 1], q_a.val[ 2]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 18);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 1], q_b.val[ 2]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 14);
			q_a.val[ 0] = veorq_u32(q_tmp.val[ 1], q_a.val[ 0]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 2], 18);
			q_tmp.val[ 3] = vaddq_u32(q_c.val[ 1], q_c.val[ 2]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 2], 14);
			q_b.val[ 0] = veorq_u32(q_tmp.val[ 1], q_b.val[ 0]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 3], 18);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 3], 14);
			q_c.val[ 0] = veorq_u32(q_tmp.val[ 1], q_c.val[ 0]);
			
			q_a.val[ 2] = vextq_u32(q_a.val[ 2], q_a.val[ 2], 2);
			q_b.val[ 2] = vextq_u32(q_b.val[ 2], q_b.val[ 2], 2);
			q_c.val[ 2] = vextq_u32(q_c.val[ 2], q_c.val[ 2], 2);
			
			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 0], q_a.val[ 3]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 7);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 0], q_b.val[ 3]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 25);
			q_a.val[ 1] = vextq_u32(q_a.val[ 1], q_a.val[ 1], 1);
			q_a.val[ 1] = veorq_u32(q_tmp.val[ 1], q_a.val[ 1]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 2], 7);
			q_tmp.val[ 3] = vaddq_u32(q_c.val[ 0], q_c.val[ 3]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 2], 25);
			q_b.val[ 1] = vextq_u32(q_b.val[ 1], q_b.val[ 1], 1);
			q_b.val[ 1] = veorq_u32(q_tmp.val[ 1], q_b.val[ 1]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 3], 7);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 3], 25);
			q_c.val[ 1] = vextq_u32(q_c.val[ 1], q_c.val[ 1], 1);
			q_c.val[ 1] = veorq_u32(q_tmp.val[ 1], q_c.val[ 1]);

			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 1], q_a.val[ 0]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 9);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 1], q_b.val[ 0]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 23);
			q_a.val[ 2] = veorq_u32(q_tmp.val[ 1], q_a.val[ 2]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 2], 9);
			q_tmp.val[ 3] = vaddq_u32(q_c.val[ 1], q_c.val[ 0]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 2], 23);
			q_b.val[ 2] = veorq_u32(q_tmp.val[ 1], q_b.val[ 2]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 3], 9);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 3], 23);
			q_c.val[ 2] = veorq_u32(q_tmp.val[ 1], q_c.val[ 2]);

			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 2], q_a.val[ 1]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 13);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 2], q_b.val[ 1]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 19);
			q_a.val[ 3] = veorq_u32(q_tmp.val[ 1], q_a.val[ 3]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 2], 13);
			q_tmp.val[ 3] = vaddq_u32(q_c.val[ 2], q_c.val[ 1]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 2], 19);
			q_b.val[ 3] = veorq_u32(q_tmp.val[ 1], q_b.val[ 3]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 3], 13);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 3], 19);
			q_c.val[ 3] = veorq_u32(q_tmp.val[ 1], q_c.val[ 3]);
			q_a.val[ 1] = vextq_u32(q_a.val[ 1], q_a.val[ 1], 3);
			q_b.val[ 1] = vextq_u32(q_b.val[ 1], q_b.val[ 1], 3);
			q_c.val[ 1] = vextq_u32(q_c.val[ 1], q_c.val[ 1], 3);

			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 3], q_a.val[ 2]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 18);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 3], q_b.val[ 2]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 14);
			q_a.val[ 2] = vextq_u32(q_a.val[ 2], q_a.val[ 2], 2);
			q_b.val[ 2] = vextq_u32(q_b.val[ 2], q_b.val[ 2], 2);
			q_a.val[ 0] = veorq_u32(q_tmp.val[ 1], q_a.val[ 0]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 2], 18);
			q_tmp.val[ 3] = vaddq_u32(q_c.val[ 3], q_c.val[ 2]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 2], 14);
			q_c.val[ 2] = vextq_u32(q_c.val[ 2], q_c.val[ 2], 2);
			q_b.val[ 3] = vextq_u32(q_b.val[ 3], q_b.val[ 3], 1);
			q_b.val[ 0] = veorq_u32(q_tmp.val[ 1], q_b.val[ 0]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 3], 18);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 3], 14);
			q_a.val[ 3] = vextq_u32(q_a.val[ 3], q_a.val[ 3], 1);
			q_c.val[ 3] = vextq_u32(q_c.val[ 3], q_c.val[ 3], 1);
			q_c.val[ 0] = veorq_u32(q_tmp.val[ 1], q_c.val[ 0]);
		}

		ba_b.val[ 0] = vaddq_u32(q_a.val[ 0], ba_b.val[ 0]);
		ba_b.val[ 1] = vaddq_u32(q_a.val[ 1], ba_b.val[ 1]);
		ba_b.val[ 2] = vaddq_u32(q_a.val[ 2], ba_b.val[ 2]);
		ba_b.val[ 3] = vaddq_u32(q_a.val[ 3], ba_b.val[ 3]);
		bb_b.val[ 0] = vaddq_u32(q_b.val[ 0], bb_b.val[ 0]);
		bb_b.val[ 1] = vaddq_u32(q_b.val[ 1], bb_b.val[ 1]);
		bb_b.val[ 2] = vaddq_u32(q_b.val[ 2], bb_b.val[ 2]);
		bb_b.val[ 3] = vaddq_u32(q_b.val[ 3], bb_b.val[ 3]);
		bc_b.val[ 0] = vaddq_u32(q_c.val[ 0], bc_b.val[ 0]);
		bc_b.val[ 1] = vaddq_u32(q_c.val[ 1], bc_b.val[ 1]);
		bc_b.val[ 2] = vaddq_u32(q_c.val[ 2], bc_b.val[ 2]);
		bc_b.val[ 3] = vaddq_u32(q_c.val[ 3], bc_b.val[ 3]);
		for (int i = 0; i < 4; i++)
		{
			vst1q_u32(&V[(     16 + (i * 4))], ba_b.val[i]);
			vst1q_u32(&V[(32 + 16 + (i * 4))], bb_b.val[i]);
			vst1q_u32(&V[(64 + 16 + (i * 4))], bc_b.val[i]);
		}
		V += 96;
	}
	V = W;

    // loop 2

	uint32x4x4_t x;

	uint32_t one =   32 * (3 * (ba_b.val[ 0][ 0] & (N - 1)) + 0);
	uint32_t two =   32 * (3 * (bb_b.val[ 0][ 0] & (N - 1)) + 1);
	uint32_t three = 32 * (3 * (bc_b.val[ 0][ 0] & (N - 1)) + 2);
	q_tmp.val[ 0] = vld1q_u32(&W[one +  0]);
	q_tmp.val[ 1] = vld1q_u32(&W[one +  4]);
	q_tmp.val[ 2] = vld1q_u32(&W[one +  8]);
	q_tmp.val[ 3] = vld1q_u32(&W[one + 12]);

	for (int n = 0; n < N; n++)
	{
	// loop 2 part a

		ba_a.val[ 0] = veorq_u32(ba_a.val[ 0], q_tmp.val[ 0]);
			q_tmp.val[ 0] = vld1q_u32(&W[one + 16 +  0]);
		ba_a.val[ 1] = veorq_u32(ba_a.val[ 1], q_tmp.val[ 1]);
			q_tmp.val[ 1] = vld1q_u32(&W[one + 16 +  4]);
		ba_a.val[ 2] = veorq_u32(ba_a.val[ 2], q_tmp.val[ 2]);
			q_tmp.val[ 2] = vld1q_u32(&W[one + 16 +  8]);
		ba_a.val[ 3] = veorq_u32(ba_a.val[ 3], q_tmp.val[ 3]);

			ba_b.val[ 0] = veorq_u32(ba_b.val[ 0], q_tmp.val[ 0]);
			ba_b.val[ 1] = veorq_u32(ba_b.val[ 1], q_tmp.val[ 1]);
			q_tmp.val[ 3] = vld1q_u32(&W[one + 16 + 12]);
			ba_b.val[ 2] = veorq_u32(ba_b.val[ 2], q_tmp.val[ 2]);
			ba_b.val[ 3] = veorq_u32(ba_b.val[ 3], q_tmp.val[ 3]);
		q_tmp.val[ 0] = vld1q_u32(&W[two +  0]);
				q_a.val[ 0] = veorq_u32(ba_b.val[ 0], ba_a.val[ 0]);
				q_a.val[ 1] = veorq_u32(ba_b.val[ 1], ba_a.val[ 1]);
		q_tmp.val[ 1] = vld1q_u32(&W[two +  4]);
				q_a.val[ 2] = veorq_u32(ba_b.val[ 2], ba_a.val[ 2]);
				q_a.val[ 3] = veorq_u32(ba_b.val[ 3], ba_a.val[ 3]);
		q_tmp.val[ 2] = vld1q_u32(&W[two +  8]);
		ba_a = q_a;

		q_tmp.val[ 3] = vld1q_u32(&W[two + 12]);

		bb_a.val[ 0] = veorq_u32(bb_a.val[ 0], q_tmp.val[ 0]);
			q_tmp.val[ 0] = vld1q_u32(&W[two + 16 +  0]);
		bb_a.val[ 1] = veorq_u32(bb_a.val[ 1], q_tmp.val[ 1]);
			q_tmp.val[ 1] = vld1q_u32(&W[two + 16 +  4]);
		bb_a.val[ 2] = veorq_u32(bb_a.val[ 2], q_tmp.val[ 2]);
			q_tmp.val[ 2] = vld1q_u32(&W[two + 16 +  8]);
		bb_a.val[ 3] = veorq_u32(bb_a.val[ 3], q_tmp.val[ 3]);
			bb_b.val[ 0] = veorq_u32(bb_b.val[ 0], q_tmp.val[ 0]);
			q_tmp.val[ 3] = vld1q_u32(&W[two + 16 + 12]);
			bb_b.val[ 1] = veorq_u32(bb_b.val[ 1], q_tmp.val[ 1]);
		q_tmp.val[ 0] = vld1q_u32(&W[three +  0]);
			bb_b.val[ 2] = veorq_u32(bb_b.val[ 2], q_tmp.val[ 2]);
			bb_b.val[ 3] = veorq_u32(bb_b.val[ 3], q_tmp.val[ 3]);
		q_tmp.val[ 1] = vld1q_u32(&W[three +  4]);
				q_b.val[ 0] = veorq_u32(bb_b.val[ 0], bb_a.val[ 0]);
				q_b.val[ 1] = veorq_u32(bb_b.val[ 1], bb_a.val[ 1]);
		q_tmp.val[ 2] = vld1q_u32(&W[three +  8]);
				q_b.val[ 2] = veorq_u32(bb_b.val[ 2], bb_a.val[ 2]);
				q_b.val[ 3] = veorq_u32(bb_b.val[ 3], bb_a.val[ 3]);
		q_tmp.val[ 3] = vld1q_u32(&W[three + 12]);
		bb_a = q_b;

		bc_a.val[ 0] = veorq_u32(bc_a.val[ 0], q_tmp.val[ 0]);
			q_tmp.val[ 0] = vld1q_u32(&W[three + 16 +  0]);
		bc_a.val[ 1] = veorq_u32(bc_a.val[ 1], q_tmp.val[ 1]);
			q_tmp.val[ 1] = vld1q_u32(&W[three + 16 +  4]);
		bc_a.val[ 2] = veorq_u32(bc_a.val[ 2], q_tmp.val[ 2]);
			q_tmp.val[ 2] = vld1q_u32(&W[three + 16 +  8]);
		bc_a.val[ 3] = veorq_u32(bc_a.val[ 3], q_tmp.val[ 3]);
			bc_b.val[ 0] = veorq_u32(bc_b.val[ 0], q_tmp.val[ 0]);
			q_tmp.val[ 3] = vld1q_u32(&W[three + 16 + 12]);
			bc_b.val[ 1] = veorq_u32(bc_b.val[ 1], q_tmp.val[ 1]);
			bc_b.val[ 2] = veorq_u32(bc_b.val[ 2], q_tmp.val[ 2]);
			bc_b.val[ 3] = veorq_u32(bc_b.val[ 3], q_tmp.val[ 3]);
				q_c.val[ 0] = veorq_u32(bc_b.val[ 0], bc_a.val[ 0]);
				q_c.val[ 1] = veorq_u32(bc_b.val[ 1], bc_a.val[ 1]);
				q_c.val[ 2] = veorq_u32(bc_b.val[ 2], bc_a.val[ 2]);
				q_c.val[ 3] = veorq_u32(bc_b.val[ 3], bc_a.val[ 3]);
		bc_a = q_c;

		for (int i = 0; i < 4; i++)
		{
			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 0], q_a.val[ 1]);  	
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 7);	
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 0], q_b.val[ 1]);  	
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 25);
			q_a.val[ 3] = veorq_u32(q_tmp.val[ 1], q_a.val[ 3]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 2], 7);
			q_tmp.val[ 3] = vaddq_u32(q_c.val[ 0], q_c.val[ 1]); 
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 2], 25);
			q_b.val[ 3] = veorq_u32(q_tmp.val[ 1], q_b.val[ 3]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 3], 7); 				
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 3], 25);				
			q_c.val[ 3] = veorq_u32(q_tmp.val[ 1], q_c.val[ 3]);

			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 3], q_a.val[ 0]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 9);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 3], q_b.val[ 0]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 23);
			q_a.val[ 2] = veorq_u32(q_tmp.val[ 1], q_a.val[ 2]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 2], 9);
			q_tmp.val[ 3] = vaddq_u32(q_c.val[ 3], q_c.val[ 0]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 2], 23);
			q_b.val[ 2] = veorq_u32(q_tmp.val[ 1], q_b.val[ 2]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 3], 9);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 3], 23);
			q_c.val[ 2] = veorq_u32(q_tmp.val[ 1], q_c.val[ 2]);

			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 2], q_a.val[ 3]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 13);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 2], q_b.val[ 3]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 19);
			q_a.val[ 1] = veorq_u32(q_tmp.val[ 1], q_a.val[ 1]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 2], 13);
			q_tmp.val[ 3] = vaddq_u32(q_c.val[ 2], q_c.val[ 3]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 2], 19);
			q_b.val[ 1] = veorq_u32(q_tmp.val[ 1], q_b.val[ 1]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 3], 13);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 3], 19);
			q_c.val[ 1] = veorq_u32(q_tmp.val[ 1], q_c.val[ 1]);
			
			q_a.val[ 3] = vextq_u32(q_a.val[ 3], q_a.val[ 3], 3);
			q_b.val[ 3] = vextq_u32(q_b.val[ 3], q_b.val[ 3], 3);
			q_c.val[ 3] = vextq_u32(q_c.val[ 3], q_c.val[ 3], 3);
			
			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 1], q_a.val[ 2]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 18);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 1], q_b.val[ 2]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 14);
			q_a.val[ 0] = veorq_u32(q_tmp.val[ 1], q_a.val[ 0]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 2], 18);
			q_tmp.val[ 3] = vaddq_u32(q_c.val[ 1], q_c.val[ 2]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 2], 14);
			q_b.val[ 0] = veorq_u32(q_tmp.val[ 1], q_b.val[ 0]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 3], 18);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 3], 14);
			q_c.val[ 0] = veorq_u32(q_tmp.val[ 1], q_c.val[ 0]);
			
			q_a.val[ 2] = vextq_u32(q_a.val[ 2], q_a.val[ 2], 2);
			q_b.val[ 2] = vextq_u32(q_b.val[ 2], q_b.val[ 2], 2);
			q_c.val[ 2] = vextq_u32(q_c.val[ 2], q_c.val[ 2], 2);
			
			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 0], q_a.val[ 3]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 7);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 0], q_b.val[ 3]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 25);
			q_a.val[ 1] = vextq_u32(q_a.val[ 1], q_a.val[ 1], 1);
			q_a.val[ 1] = veorq_u32(q_tmp.val[ 1], q_a.val[ 1]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 2], 7);
			q_tmp.val[ 3] = vaddq_u32(q_c.val[ 0], q_c.val[ 3]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 2], 25);
			q_b.val[ 1] = vextq_u32(q_b.val[ 1], q_b.val[ 1], 1);
			q_b.val[ 1] = veorq_u32(q_tmp.val[ 1], q_b.val[ 1]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 3], 7);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 3], 25);
			q_c.val[ 1] = vextq_u32(q_c.val[ 1], q_c.val[ 1], 1);
			q_c.val[ 1] = veorq_u32(q_tmp.val[ 1], q_c.val[ 1]);

			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 1], q_a.val[ 0]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 9);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 1], q_b.val[ 0]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 23);
			q_a.val[ 2] = veorq_u32(q_tmp.val[ 1], q_a.val[ 2]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 2], 9);
			q_tmp.val[ 3] = vaddq_u32(q_c.val[ 1], q_c.val[ 0]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 2], 23);
			q_b.val[ 2] = veorq_u32(q_tmp.val[ 1], q_b.val[ 2]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 3], 9);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 3], 23);
			q_c.val[ 2] = veorq_u32(q_tmp.val[ 1], q_c.val[ 2]);

			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 2], q_a.val[ 1]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 13);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 2], q_b.val[ 1]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 19);
			q_a.val[ 3] = veorq_u32(q_tmp.val[ 1], q_a.val[ 3]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 2], 13);
			q_tmp.val[ 3] = vaddq_u32(q_c.val[ 2], q_c.val[ 1]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 2], 19);
			q_b.val[ 3] = veorq_u32(q_tmp.val[ 1], q_b.val[ 3]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 3], 13);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 3], 19);
			q_c.val[ 3] = veorq_u32(q_tmp.val[ 1], q_c.val[ 3]);
			q_a.val[ 1] = vextq_u32(q_a.val[ 1], q_a.val[ 1], 3);
			q_b.val[ 1] = vextq_u32(q_b.val[ 1], q_b.val[ 1], 3);
			q_c.val[ 1] = vextq_u32(q_c.val[ 1], q_c.val[ 1], 3);

			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 3], q_a.val[ 2]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 18);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 3], q_b.val[ 2]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 14);
			q_a.val[ 2] = vextq_u32(q_a.val[ 2], q_a.val[ 2], 2);
			q_b.val[ 2] = vextq_u32(q_b.val[ 2], q_b.val[ 2], 2);
			q_a.val[ 0] = veorq_u32(q_tmp.val[ 1], q_a.val[ 0]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 2], 18);
			q_tmp.val[ 3] = vaddq_u32(q_c.val[ 3], q_c.val[ 2]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 2], 14);
			q_c.val[ 2] = vextq_u32(q_c.val[ 2], q_c.val[ 2], 2);
			q_b.val[ 3] = vextq_u32(q_b.val[ 3], q_b.val[ 3], 1);
			q_b.val[ 0] = veorq_u32(q_tmp.val[ 1], q_b.val[ 0]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 3], 18);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 3], 14);
			q_a.val[ 3] = vextq_u32(q_a.val[ 3], q_a.val[ 3], 1);
			q_c.val[ 3] = vextq_u32(q_c.val[ 3], q_c.val[ 3], 1);
			q_c.val[ 0] = veorq_u32(q_tmp.val[ 1], q_c.val[ 0]);
		}
		ba_a.val[ 0] = vaddq_u32(ba_a.val[ 0], q_a.val[ 0]);
		ba_a.val[ 1] = vaddq_u32(ba_a.val[ 1], q_a.val[ 1]);
		ba_a.val[ 2] = vaddq_u32(ba_a.val[ 2], q_a.val[ 2]);
		ba_a.val[ 3] = vaddq_u32(ba_a.val[ 3], q_a.val[ 3]);

		q_a = ba_a;

		bb_a.val[ 0] = vaddq_u32(bb_a.val[ 0], q_b.val[ 0]);
		bb_a.val[ 1] = vaddq_u32(bb_a.val[ 1], q_b.val[ 1]);
		bb_a.val[ 2] = vaddq_u32(bb_a.val[ 2], q_b.val[ 2]);
		bb_a.val[ 3] = vaddq_u32(bb_a.val[ 3], q_b.val[ 3]);
		q_b = bb_a;

		bc_a.val[ 0] = vaddq_u32(bc_a.val[ 0], q_c.val[ 0]);
		bc_a.val[ 1] = vaddq_u32(bc_a.val[ 1], q_c.val[ 1]);
		bc_a.val[ 2] = vaddq_u32(bc_a.val[ 2], q_c.val[ 2]);
		bc_a.val[ 3] = vaddq_u32(bc_a.val[ 3], q_c.val[ 3]);
		q_c = bc_a;

	// loop 2 b

		q_a.val[ 0] = veorq_u32(ba_b.val[ 0], q_a.val[ 0]);
		q_a.val[ 1] = veorq_u32(ba_b.val[ 1], q_a.val[ 1]);
		q_a.val[ 2] = veorq_u32(ba_b.val[ 2], q_a.val[ 2]);
		q_a.val[ 3] = veorq_u32(ba_b.val[ 3], q_a.val[ 3]);
		ba_b = q_a;

		q_b.val[ 0] = veorq_u32(bb_b.val[ 0], q_b.val[ 0]);
		q_b.val[ 1] = veorq_u32(bb_b.val[ 1], q_b.val[ 1]);
		q_b.val[ 2] = veorq_u32(bb_b.val[ 2], q_b.val[ 2]);
		q_b.val[ 3] = veorq_u32(bb_b.val[ 3], q_b.val[ 3]);
		bb_b = q_b;

		q_c.val[ 0] = veorq_u32(bc_b.val[ 0], q_c.val[ 0]);
		q_c.val[ 1] = veorq_u32(bc_b.val[ 1], q_c.val[ 1]);
		q_c.val[ 2] = veorq_u32(bc_b.val[ 2], q_c.val[ 2]);
		q_c.val[ 3] = veorq_u32(bc_b.val[ 3], q_c.val[ 3]);
		bc_b = q_c;


		for (int i = 0; i < 3; i++)
		{
			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 0], q_a.val[ 1]);  	
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 7);	
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 0], q_b.val[ 1]);  	
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 25);
			q_a.val[ 3] = veorq_u32(q_tmp.val[ 1], q_a.val[ 3]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 2], 7);
			q_tmp.val[ 3] = vaddq_u32(q_c.val[ 0], q_c.val[ 1]); 
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 2], 25);
			q_b.val[ 3] = veorq_u32(q_tmp.val[ 1], q_b.val[ 3]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 3], 7); 				
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 3], 25);				
			q_c.val[ 3] = veorq_u32(q_tmp.val[ 1], q_c.val[ 3]);

			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 3], q_a.val[ 0]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 9);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 3], q_b.val[ 0]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 23);
			q_a.val[ 2] = veorq_u32(q_tmp.val[ 1], q_a.val[ 2]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 2], 9);
			q_tmp.val[ 3] = vaddq_u32(q_c.val[ 3], q_c.val[ 0]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 2], 23);
			q_b.val[ 2] = veorq_u32(q_tmp.val[ 1], q_b.val[ 2]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 3], 9);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 3], 23);
			q_c.val[ 2] = veorq_u32(q_tmp.val[ 1], q_c.val[ 2]);

			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 2], q_a.val[ 3]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 13);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 2], q_b.val[ 3]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 19);
			q_a.val[ 1] = veorq_u32(q_tmp.val[ 1], q_a.val[ 1]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 2], 13);
			q_tmp.val[ 3] = vaddq_u32(q_c.val[ 2], q_c.val[ 3]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 2], 19);
			q_b.val[ 1] = veorq_u32(q_tmp.val[ 1], q_b.val[ 1]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 3], 13);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 3], 19);
			q_c.val[ 1] = veorq_u32(q_tmp.val[ 1], q_c.val[ 1]);
			
			q_a.val[ 3] = vextq_u32(q_a.val[ 3], q_a.val[ 3], 3);
			q_b.val[ 3] = vextq_u32(q_b.val[ 3], q_b.val[ 3], 3);
			q_c.val[ 3] = vextq_u32(q_c.val[ 3], q_c.val[ 3], 3);
			
			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 1], q_a.val[ 2]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 18);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 1], q_b.val[ 2]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 14);
			q_a.val[ 0] = veorq_u32(q_tmp.val[ 1], q_a.val[ 0]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 2], 18);
			q_tmp.val[ 3] = vaddq_u32(q_c.val[ 1], q_c.val[ 2]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 2], 14);
			q_b.val[ 0] = veorq_u32(q_tmp.val[ 1], q_b.val[ 0]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 3], 18);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 3], 14);
			q_c.val[ 0] = veorq_u32(q_tmp.val[ 1], q_c.val[ 0]);
			
			q_a.val[ 2] = vextq_u32(q_a.val[ 2], q_a.val[ 2], 2);
			q_b.val[ 2] = vextq_u32(q_b.val[ 2], q_b.val[ 2], 2);
			q_c.val[ 2] = vextq_u32(q_c.val[ 2], q_c.val[ 2], 2);
			
			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 0], q_a.val[ 3]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 7);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 0], q_b.val[ 3]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 25);
			q_a.val[ 1] = vextq_u32(q_a.val[ 1], q_a.val[ 1], 1);
			q_a.val[ 1] = veorq_u32(q_tmp.val[ 1], q_a.val[ 1]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 2], 7);
			q_tmp.val[ 3] = vaddq_u32(q_c.val[ 0], q_c.val[ 3]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 2], 25);
			q_b.val[ 1] = vextq_u32(q_b.val[ 1], q_b.val[ 1], 1);
			q_b.val[ 1] = veorq_u32(q_tmp.val[ 1], q_b.val[ 1]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 3], 7);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 3], 25);
			q_c.val[ 1] = vextq_u32(q_c.val[ 1], q_c.val[ 1], 1);
			q_c.val[ 1] = veorq_u32(q_tmp.val[ 1], q_c.val[ 1]);

			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 1], q_a.val[ 0]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 9);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 1], q_b.val[ 0]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 23);
			q_a.val[ 2] = veorq_u32(q_tmp.val[ 1], q_a.val[ 2]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 2], 9);
			q_tmp.val[ 3] = vaddq_u32(q_c.val[ 1], q_c.val[ 0]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 2], 23);
			q_b.val[ 2] = veorq_u32(q_tmp.val[ 1], q_b.val[ 2]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 3], 9);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 3], 23);
			q_c.val[ 2] = veorq_u32(q_tmp.val[ 1], q_c.val[ 2]);

			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 2], q_a.val[ 1]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 13);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 2], q_b.val[ 1]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 19);
			q_a.val[ 3] = veorq_u32(q_tmp.val[ 1], q_a.val[ 3]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 2], 13);
			q_tmp.val[ 3] = vaddq_u32(q_c.val[ 2], q_c.val[ 1]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 2], 19);
			q_b.val[ 3] = veorq_u32(q_tmp.val[ 1], q_b.val[ 3]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 3], 13);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 3], 19);
			q_c.val[ 3] = veorq_u32(q_tmp.val[ 1], q_c.val[ 3]);
			q_a.val[ 1] = vextq_u32(q_a.val[ 1], q_a.val[ 1], 3);
			q_b.val[ 1] = vextq_u32(q_b.val[ 1], q_b.val[ 1], 3);
			q_c.val[ 1] = vextq_u32(q_c.val[ 1], q_c.val[ 1], 3);

			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 3], q_a.val[ 2]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 18);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 3], q_b.val[ 2]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 14);
			q_a.val[ 2] = vextq_u32(q_a.val[ 2], q_a.val[ 2], 2);
			q_b.val[ 2] = vextq_u32(q_b.val[ 2], q_b.val[ 2], 2);
			q_a.val[ 0] = veorq_u32(q_tmp.val[ 1], q_a.val[ 0]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 2], 18);
			q_tmp.val[ 3] = vaddq_u32(q_c.val[ 3], q_c.val[ 2]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 2], 14);
			q_c.val[ 2] = vextq_u32(q_c.val[ 2], q_c.val[ 2], 2);
			q_b.val[ 3] = vextq_u32(q_b.val[ 3], q_b.val[ 3], 1);
			q_b.val[ 0] = veorq_u32(q_tmp.val[ 1], q_b.val[ 0]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 3], 18);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 3], 14);
			q_a.val[ 3] = vextq_u32(q_a.val[ 3], q_a.val[ 3], 1);
			q_c.val[ 3] = vextq_u32(q_c.val[ 3], q_c.val[ 3], 1);
			q_c.val[ 0] = veorq_u32(q_tmp.val[ 1], q_c.val[ 0]);
		}
		{
		//1
			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 0], q_a.val[ 1]);  	
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 7);	
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 0], q_b.val[ 1]);  	
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 25);
			q_a.val[ 3] = veorq_u32(q_tmp.val[ 1], q_a.val[ 3]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 2], 7);
			q_tmp.val[ 3] = vaddq_u32(q_c.val[ 0], q_c.val[ 1]); 
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 2], 25);
			q_b.val[ 3] = veorq_u32(q_tmp.val[ 1], q_b.val[ 3]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 3], 7); 				
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 3], 25);				
			q_c.val[ 3] = veorq_u32(q_tmp.val[ 1], q_c.val[ 3]);
		//2
			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 3], q_a.val[ 0]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 9);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 3], q_b.val[ 0]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 23);
			q_a.val[ 2] = veorq_u32(q_tmp.val[ 1], q_a.val[ 2]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 2], 9);
			q_tmp.val[ 3] = vaddq_u32(q_c.val[ 3], q_c.val[ 0]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 2], 23);
			q_b.val[ 2] = veorq_u32(q_tmp.val[ 1], q_b.val[ 2]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 3], 9);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 3], 23);
			q_c.val[ 2] = veorq_u32(q_tmp.val[ 1], q_c.val[ 2]);
		//3
			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 2], q_a.val[ 3]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 13);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 2], q_b.val[ 3]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 19);
			q_a.val[ 1] = veorq_u32(q_tmp.val[ 1], q_a.val[ 1]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 2], 13);
			q_tmp.val[ 3] = vaddq_u32(q_c.val[ 2], q_c.val[ 3]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 2], 19);
			q_b.val[ 1] = veorq_u32(q_tmp.val[ 1], q_b.val[ 1]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 3], 13);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 3], 19);
			q_c.val[ 1] = veorq_u32(q_tmp.val[ 1], q_c.val[ 1]);
			
			q_a.val[ 3] = vextq_u32(q_a.val[ 3], q_a.val[ 3], 3);
			q_b.val[ 3] = vextq_u32(q_b.val[ 3], q_b.val[ 3], 3);
			q_c.val[ 3] = vextq_u32(q_c.val[ 3], q_c.val[ 3], 3);
		//4
			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 1], q_a.val[ 2]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 18);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 1], q_b.val[ 2]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 14);
			q_a.val[ 0] = veorq_u32(q_tmp.val[ 1], q_a.val[ 0]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 2], 18);
			q_tmp.val[ 3] = vaddq_u32(q_c.val[ 1], q_c.val[ 2]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 2], 14);
			q_b.val[ 0] = veorq_u32(q_tmp.val[ 1], q_b.val[ 0]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 3], 18);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 3], 14);
			q_c.val[ 0] = veorq_u32(q_tmp.val[ 1], q_c.val[ 0]);
			
			q_a.val[ 2] = vextq_u32(q_a.val[ 2], q_a.val[ 2], 2);
			q_b.val[ 2] = vextq_u32(q_b.val[ 2], q_b.val[ 2], 2);
			q_c.val[ 2] = vextq_u32(q_c.val[ 2], q_c.val[ 2], 2);
		//5
			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 0], q_a.val[ 3]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 7);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 0], q_b.val[ 3]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 25);
			q_a.val[ 1] = vextq_u32(q_a.val[ 1], q_a.val[ 1], 1);
			q_a.val[ 1] = veorq_u32(q_tmp.val[ 1], q_a.val[ 1]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 2], 7);
			q_tmp.val[ 3] = vaddq_u32(q_c.val[ 0], q_c.val[ 3]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 2], 25);
			q_b.val[ 1] = vextq_u32(q_b.val[ 1], q_b.val[ 1], 1);
			q_b.val[ 1] = veorq_u32(q_tmp.val[ 1], q_b.val[ 1]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 3], 7);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 3], 25);
			q_c.val[ 1] = vextq_u32(q_c.val[ 1], q_c.val[ 1], 1);
			q_c.val[ 1] = veorq_u32(q_tmp.val[ 1], q_c.val[ 1]);
		//6
			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 1], q_a.val[ 0]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 9);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 1], q_b.val[ 0]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 23);
			q_a.val[ 2] = veorq_u32(q_tmp.val[ 1], q_a.val[ 2]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 2], 9);
			q_tmp.val[ 3] = vaddq_u32(q_c.val[ 1], q_c.val[ 0]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 2], 23);
			q_b.val[ 2] = veorq_u32(q_tmp.val[ 1], q_b.val[ 2]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 3], 9);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 3], 23);
			q_c.val[ 2] = veorq_u32(q_tmp.val[ 1], q_c.val[ 2]);
		//7
			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 2], q_a.val[ 1]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 13);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 2], q_b.val[ 1]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 19);
			q_a.val[ 3] = veorq_u32(q_tmp.val[ 1], q_a.val[ 3]);
				q_a.val[ 1] = vextq_u32(q_a.val[ 1], q_a.val[ 1], 3);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 2], 13);
			q_tmp.val[ 3] = vaddq_u32(q_c.val[ 2], q_c.val[ 1]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 2], 19);
			q_b.val[ 3] = veorq_u32(q_tmp.val[ 1], q_b.val[ 3]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 3], 13);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 3], 19);
			q_c.val[ 3] = veorq_u32(q_tmp.val[ 1], q_c.val[ 3]);
			q_b.val[ 1] = vextq_u32(q_b.val[ 1], q_b.val[ 1], 3);
			q_c.val[ 1] = vextq_u32(q_c.val[ 1], q_c.val[ 1], 3);

		//8
			q_tmp.val[ 0] = vaddq_u32(q_a.val[ 3], q_a.val[ 2]);
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 0], 18);
			q_tmp.val[ 2] = vaddq_u32(q_b.val[ 3], q_b.val[ 2]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 0], 14);
			q_a.val[ 0] = veorq_u32(q_tmp.val[ 1], q_a.val[ 0]);
				ba_b.val[ 0] = vaddq_u32(q_a.val[ 0], ba_b.val[ 0]);
					one =	32 * (3 * (ba_b.val[ 0][ 0] & (N - 1)) + 0);
					__builtin_prefetch(&W[one + 0]);
					__builtin_prefetch(&W[one + 8]);
					__builtin_prefetch(&W[one + 16]);
					__builtin_prefetch(&W[one + 24]);
			
			q_a.val[ 2] = vextq_u32(q_a.val[ 2], q_a.val[ 2], 2);
			q_b.val[ 2] = vextq_u32(q_b.val[ 2], q_b.val[ 2], 2);
			
			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 2], 18);
			q_tmp.val[ 3] = vaddq_u32(q_c.val[ 3], q_c.val[ 2]);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 2], 14);
			q_c.val[ 2] = vextq_u32(q_c.val[ 2], q_c.val[ 2], 2);
			q_b.val[ 3] = vextq_u32(q_b.val[ 3], q_b.val[ 3], 1);
			q_b.val[ 0] = veorq_u32(q_tmp.val[ 1], q_b.val[ 0]);
				bb_b.val[ 0] = vaddq_u32(q_b.val[ 0], bb_b.val[ 0]);
					two =	32 * (3 * (bb_b.val[ 0][ 0] & (N - 1)) + 1);
					__builtin_prefetch(&W[two + 0]);
					__builtin_prefetch(&W[two + 8]);
					__builtin_prefetch(&W[two + 16]);
					__builtin_prefetch(&W[two + 24]);

			q_tmp.val[ 1] = vshlq_n_u32(q_tmp.val[ 3], 18);
			q_tmp.val[ 1] = vsriq_n_u32(q_tmp.val[ 1], q_tmp.val[ 3], 14);
			q_a.val[ 3] = vextq_u32(q_a.val[ 3], q_a.val[ 3], 1);
			q_c.val[ 3] = vextq_u32(q_c.val[ 3], q_c.val[ 3], 1);
			q_c.val[ 0] = veorq_u32(q_tmp.val[ 1], q_c.val[ 0]);
				bc_b.val[ 0] = vaddq_u32(q_c.val[ 0], bc_b.val[ 0]);
					three = 32 * (3 * (bc_b.val[ 0][ 0] & (N - 1)) + 2);
					__builtin_prefetch(&W[three + 0]);
					__builtin_prefetch(&W[three + 8]);
					__builtin_prefetch(&W[three + 16]);
					__builtin_prefetch(&W[three + 24]);
		}

		q_tmp.val[ 0] = vld1q_u32(&W[one +  0]);
		ba_b.val[ 1] = vaddq_u32(q_a.val[ 1], ba_b.val[ 1]);
		ba_b.val[ 2] = vaddq_u32(q_a.val[ 2], ba_b.val[ 2]);
		ba_b.val[ 3] = vaddq_u32(q_a.val[ 3], ba_b.val[ 3]);
		q_tmp.val[ 1] = vld1q_u32(&W[one +  4]);
		bb_b.val[ 1] = vaddq_u32(q_b.val[ 1], bb_b.val[ 1]);
		bb_b.val[ 2] = vaddq_u32(q_b.val[ 2], bb_b.val[ 2]);
		bb_b.val[ 3] = vaddq_u32(q_b.val[ 3], bb_b.val[ 3]);
		q_tmp.val[ 2] = vld1q_u32(&W[one +  8]);
		bc_b.val[ 1] = vaddq_u32(q_c.val[ 1], bc_b.val[ 1]);
		bc_b.val[ 2] = vaddq_u32(q_c.val[ 2], bc_b.val[ 2]);
		bc_b.val[ 3] = vaddq_u32(q_c.val[ 3], bc_b.val[ 3]);
		q_tmp.val[ 3] = vld1q_u32(&W[one + 12]);
	}

	vst1q_u32(&B[ 0],       ba_a.val[ 0]);
	vst1q_u32(&B[ 4],       ba_a.val[ 1]);
	vst1q_u32(&B[ 8],       ba_a.val[ 2]);
	vst1q_u32(&B[12],      ba_a.val[ 3]);
	vst1q_u32(&B[16 + 0],  ba_b.val[ 0]);
	vst1q_u32(&B[16 + 4],  ba_b.val[ 1]);
	vst1q_u32(&B[16 + 8],  ba_b.val[ 2]);
	vst1q_u32(&B[16 + 12], ba_b.val[ 3]);

	vst1q_u32(&B[32 + 0],  		bb_a.val[ 0]);
	vst1q_u32(&B[32 + 4],  		bb_a.val[ 1]);
	vst1q_u32(&B[32 + 8],  		bb_a.val[ 2]);
	vst1q_u32(&B[32 + 12], 		bb_a.val[ 3]);
	vst1q_u32(&B[32 + 16 + 0],  bb_b.val[ 0]);
	vst1q_u32(&B[32 + 16 + 4],  bb_b.val[ 1]);
	vst1q_u32(&B[32 + 16 + 8],  bb_b.val[ 2]);
	vst1q_u32(&B[32 + 16 + 12], bb_b.val[ 3]);

	vst1q_u32(&B[64 + 0],  		bc_a.val[ 0]);
	vst1q_u32(&B[64 + 4],  		bc_a.val[ 1]);
	vst1q_u32(&B[64 + 8],  		bc_a.val[ 2]);
	vst1q_u32(&B[64 + 12], 		bc_a.val[ 3]);
	vst1q_u32(&B[64 + 16 + 0],  bc_b.val[ 0]);
	vst1q_u32(&B[64 + 16 + 4],  bc_b.val[ 1]);
	vst1q_u32(&B[64 + 16 + 8],  bc_b.val[ 2]);
	vst1q_u32(&B[64 + 16 + 12], bc_b.val[ 3]);

        scrypt_shuffle(&B[0  + 0]);
	scrypt_shuffle(&B[16 + 0]);
	scrypt_shuffle(&B[0 + 32]);
	scrypt_shuffle(&B[16 + 32]);
	scrypt_shuffle(&B[0 + 64]);
	scrypt_shuffle(&B[16 + 64]);
}*/

#else

static inline void xor_salsa8(uint32_t B[16], const uint32_t Bx[16], uint32_t*V, uint32_t N)
{
	uint32_t x00,x01,x02,x03,x04,x05,x06,x07,x08,x09,x10,x11,x12,x13,x14,x15;
	int i;

	x00 = (B[ 0] ^= Bx[ 0]);
	x01 = (B[ 1] ^= Bx[ 1]);
	x02 = (B[ 2] ^= Bx[ 2]);
	x03 = (B[ 3] ^= Bx[ 3]);
	x04 = (B[ 4] ^= Bx[ 4]);
	x05 = (B[ 5] ^= Bx[ 5]);
	x06 = (B[ 6] ^= Bx[ 6]);
	x07 = (B[ 7] ^= Bx[ 7]);
	x08 = (B[ 8] ^= Bx[ 8]);
	x09 = (B[ 9] ^= Bx[ 9]);
	x10 = (B[10] ^= Bx[10]);
	x11 = (B[11] ^= Bx[11]);
	x12 = (B[12] ^= Bx[12]);
	x13 = (B[13] ^= Bx[13]);
	x14 = (B[14] ^= Bx[14]);
	x15 = (B[15] ^= Bx[15]);
	for (i = 0; i < 8; i += 2) {
		#define R(a, b) (((a) << (b)) | ((a) >> (32 - (b))))
		/* Operate on columns. */
		x04 ^= R(x00+x12, 7);	x09 ^= R(x05+x01, 7);
		x14 ^= R(x10+x06, 7);	x03 ^= R(x15+x11, 7);
		
		x08 ^= R(x04+x00, 9);	x13 ^= R(x09+x05, 9);
		x02 ^= R(x14+x10, 9);	x07 ^= R(x03+x15, 9);
		
		x12 ^= R(x08+x04,13);	x01 ^= R(x13+x09,13);
		x06 ^= R(x02+x14,13);	x11 ^= R(x07+x03,13);
		
		x00 ^= R(x12+x08,18);	x05 ^= R(x01+x13,18);
		x10 ^= R(x06+x02,18);	x15 ^= R(x11+x07,18);
		
		/* Operate on rows. */
		x01 ^= R(x00+x03, 7);	x06 ^= R(x05+x04, 7);
		x11 ^= R(x10+x09, 7);	x12 ^= R(x15+x14, 7);
		
		x02 ^= R(x01+x00, 9);	x07 ^= R(x06+x05, 9);
		x08 ^= R(x11+x10, 9);	x13 ^= R(x12+x15, 9);
		
		x03 ^= R(x02+x01,13);	x04 ^= R(x07+x06,13);
		x09 ^= R(x08+x11,13);	x14 ^= R(x13+x12,13);
		
		x00 ^= R(x03+x02,18);	x05 ^= R(x04+x07,18);
		x10 ^= R(x09+x08,18);	x15 ^= R(x14+x13,18);
		#undef R
	}
	B[ 0] += x00;
	B[ 1] += x01;
	B[ 2] += x02;
	B[ 3] += x03;
	B[ 4] += x04;
	B[ 5] += x05;
	B[ 6] += x06;
	B[ 7] += x07;
	B[ 8] += x08;
	B[ 9] += x09;
	B[10] += x10;
	B[11] += x11;
	B[12] += x12;
	B[13] += x13;
	B[14] += x14;
	B[15] += x15;
}
static inline void xor_salsa8_prefetch(uint32_t B[16], const uint32_t Bx[16], uint32_t*V, uint32_t N)
{
	uint32_t x00,x01,x02,x03,x04,x05,x06,x07,x08,x09,x10,x11,x12,x13,x14,x15;
	int i;

	x00 = (B[ 0] ^= Bx[ 0]);
	x01 = (B[ 1] ^= Bx[ 1]);
	x02 = (B[ 2] ^= Bx[ 2]);
	x03 = (B[ 3] ^= Bx[ 3]);
	x04 = (B[ 4] ^= Bx[ 4]);
	x05 = (B[ 5] ^= Bx[ 5]);
	x06 = (B[ 6] ^= Bx[ 6]);
	x07 = (B[ 7] ^= Bx[ 7]);
	x08 = (B[ 8] ^= Bx[ 8]);
	x09 = (B[ 9] ^= Bx[ 9]);
	x10 = (B[10] ^= Bx[10]);
	x11 = (B[11] ^= Bx[11]);
	x12 = (B[12] ^= Bx[12]);
	x13 = (B[13] ^= Bx[13]);
	x14 = (B[14] ^= Bx[14]);
	x15 = (B[15] ^= Bx[15]);
	for (i = 0; i < 8; i += 2) {
		#define R(a, b) (((a) << (b)) | ((a) >> (32 - (b))))
		/* Operate on columns. */
		x04 ^= R(x00+x12, 7);	x09 ^= R(x05+x01, 7);
		x14 ^= R(x10+x06, 7);	x03 ^= R(x15+x11, 7);
		
		x08 ^= R(x04+x00, 9);	x13 ^= R(x09+x05, 9);
		x02 ^= R(x14+x10, 9);	x07 ^= R(x03+x15, 9);
		
		x12 ^= R(x08+x04,13);	x01 ^= R(x13+x09,13);
		x06 ^= R(x02+x14,13);	x11 ^= R(x07+x03,13);
		
		x00 ^= R(x12+x08,18);	x05 ^= R(x01+x13,18);
		x10 ^= R(x06+x02,18);	x15 ^= R(x11+x07,18);
		
		/* Operate on rows. */
		x01 ^= R(x00+x03, 7);	x06 ^= R(x05+x04, 7);
		x11 ^= R(x10+x09, 7);	x12 ^= R(x15+x14, 7);
		
		x02 ^= R(x01+x00, 9);	x07 ^= R(x06+x05, 9);
		x08 ^= R(x11+x10, 9);	x13 ^= R(x12+x15, 9);
		
		x03 ^= R(x02+x01,13);	x04 ^= R(x07+x06,13);
		x09 ^= R(x08+x11,13);	x14 ^= R(x13+x12,13);
		
		x00 ^= R(x03+x02,18);	x05 ^= R(x04+x07,18);
		x10 ^= R(x09+x08,18);	x15 ^= R(x14+x13,18);
		#undef R
	}
	B[ 0] += x00;
	uint32_t one = 32 * (B[ 0] & (N - 1));
	__builtin_prefetch(&V[one]);
	__builtin_prefetch(&V[one + 8]);
	__builtin_prefetch(&V[one + 16]);
	__builtin_prefetch(&V[one + 24]);
	asm("":::"memory");
	B[ 1] += x01;
	B[ 2] += x02;
	B[ 3] += x03;
	B[ 4] += x04;
	B[ 5] += x05;
	B[ 6] += x06;
	B[ 7] += x07;
	B[ 8] += x08;
	B[ 9] += x09;
	B[10] += x10;
	B[11] += x11;
	B[12] += x12;
	B[13] += x13;
	B[14] += x14;
	B[15] += x15;
}

static inline void scrypt_core(uint32_t *X, uint32_t *V, int N)
{
	int i;

	for (i = 0; i < N; i++) {
		memcpy(&V[i * 32], X, 128);
		xor_salsa8(&x[ 0], &X[16]);
		xor_salsa8(&X[16], &x[ 0]);
	}
	for (i = 0; i < N; i++) {
		uint32_t j = 32 * (X[16] & (N - 1));
		for (uint8_t k = 0; k < 32; k++)
			X[k] ^= V[j + k];
		xor_salsa8(&x[ 0], &X[16]);
		xor_salsa8_prefetch(&X[16], &x[ 0], V, N);
	}
}

#endif

#ifndef SCRYPT_MAX_WAYS
#define SCRYPT_MAX_WAYS 1
#define scrypt_best_throughput() 1
#endif

pthread_mutex_t alloc_mutex = PTHREAD_MUTEX_INITIALIZER;
bool printed = false;
bool tested_hugepages = false;
bool disable_hugepages = false;
int hugepages_successes = 0;
int hugepages_fails = 0;
int hugepages_size_failed = 0;
unsigned char __attribute__((cold))  __attribute__((malloc)) *scrypt_buffer_alloc(int N, int forceThroughput)
{
	uint32_t throughput = forceThroughput == -1 ? scrypt_best_throughput() : forceThroughput;
	#ifndef __aarch64__
	if (opt_ryzen_1x) {
	// force throughput to be 3 (aka AVX) instead of AVX2.
		throughput = 3;
	}
	#endif
	size_t size = (throughput * 32 * (N + 1) * sizeof(uint32_t));

#ifdef __linux__
	pthread_mutex_lock(&alloc_mutex);
	if (!tested_hugepages)
	{
		FILE* f = fopen("/sys/kernel/mm/transparent_hugepage/enabled", "r");
		if (f)
		{
			char buff[32];
			fread(buff, 32, 1, f);
			fclose(f);
			if (strstr(buff, "[always]") != NULL)
			{
				applog(LOG_DEBUG, "HugePages type: transparent_hugepages\n");
				disable_hugepages = true;
			}
		}
		else
		{
		}
		tested_hugepages = true;
	}
	pthread_mutex_unlock(&alloc_mutex);

	if (!disable_hugepages)
	{
		unsigned char* m_memory = (unsigned char*)(mmap(0, size, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS | MAP_HUGETLB | MAP_POPULATE | MAP_NONBLOCK | MAP_NORESERVE, 0, 0));
		if (m_memory == MAP_FAILED)
		{
			pthread_mutex_lock(&alloc_mutex);
			hugepages_fails++;
			hugepages_size_failed += ((size / (2 * 1024 * 1024)) + 1);
			if( hugepages_successes == 0)
			{
				if (!printed)
				{
					applog(LOG_DEBUG, "HugePages unavailable (%d)\n", errno);
					printed = true;
				}
			}
			else
			{
				applog(LOG_INFO, "HugePages too small! (%d success, %d fail)\n\tNeed at most %d more hugepages\n", hugepages_successes, hugepages_fails, hugepages_size_failed);
			}
			pthread_mutex_unlock(&alloc_mutex);
			m_memory = (unsigned char*)malloc(size);
		}
		else
		{
			pthread_mutex_lock(&alloc_mutex);
			if (!printed)
			{
				printed = true;
				applog(LOG_DEBUG, "HugePages type: preallocated\n");
			}
			hugepages_successes++;
			pthread_mutex_unlock(&alloc_mutex);
		}
		return m_memory;
	}
	else
	{
		// Attempt to inform kernel not to perform read ahead
		unsigned char *m_memory = malloc(size);
		madvise(m_memory, size, MADV_RANDOM);
		return m_memory;
	}
#elif defined(WIN32)

	pthread_mutex_lock(&alloc_mutex);
	if (!tested_hugepages)
	{
		tested_hugepages = true;
		
		HANDLE           hToken;
		TOKEN_PRIVILEGES tp;
		BOOL             status;

		if (!OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &hToken))
			disable_hugepages = true;

		if (!disable_hugepages && !LookupPrivilegeValue(NULL, TEXT("SeLockMemoryPrivilege"), &tp.Privileges[ 0].Luid))
			disable_hugepages = true;

		if (!disable_hugepages)
		{
			tp.PrivilegeCount = 1;
			tp.Privileges[ 0].Attributes = SE_PRIVILEGE_ENABLED;

			status = AdjustTokenPrivileges(hToken, FALSE, &tp, 0, (PTOKEN_PRIVILEGES)NULL, 0);
		}

		if (disable_hugepages || (!status || (GetLastError() != ERROR_SUCCESS)))
		{
			applog(LOG_DEBUG, "HugePages: not enabled, view readme for more info!");
			disable_hugepages = true;
		}

		CloseHandle(hToken);
	}
	pthread_mutex_unlock(&alloc_mutex);

	if (tested_hugepages && !disable_hugepages)
	{   
		int size = N * scrypt_best_throughput() * 128;
		SIZE_T iLargePageMin = GetLargePageMinimum();
		if (size < iLargePageMin)
			size = iLargePageMin;

		unsigned char *scratchpad = VirtualAllocEx(GetCurrentProcess(), NULL, size, MEM_RESERVE | MEM_COMMIT | MEM_LARGE_PAGES, PAGE_READWRITE);
		if (!scratchpad)
		{
			applog(LOG_ERR, "Large page allocation failed.");
			scratchpad = VirtualAllocEx(GetCurrentProcess(), NULL, size, MEM_RESERVE | MEM_COMMIT, PAGE_READWRITE);
		}

		return scratchpad;
	}
	else
	{
		return (unsigned char*)malloc(size);
	}

#else
	return (unsigned char*)malloc(size);
#endif
}

#define UNION_CAST(x, destType) \
   (((union {__typeof__(x) a; destType b;})x).b)

static inline void __attribute__((hot)) scrypt_1024_1_1_256(const uint32_t *input, uint32_t *output,
	uint32_t *midstate, unsigned char *scratchpad, uint32_t thr_id, uint32_t totalthreads)
{
	uint32_t tstate[ 8] __attribute__((__aligned__(16))), ostate[ 8] __attribute__((__aligned__(16)));
	uint32_t X[32] __attribute__((__aligned__(16)));

	// Cast custom typedef 1024 bit scratchpad pointer aligned to cache line size of 64 bytes on armv8
	#ifdef __aarch64__
	uint32_t *V = (uint32_t *)(((uintptr_t)(scratchpad) + 63) & ~ (uintptr_t)(63));
	#else
	uint32_t *V = (uint32_t *)(((uintptr_t)(void *)(scratchpad) + 63) & ~ (uintptr_t)(63));
	#endif

	newmemcpy(tstate, midstate, 32);
	HMAC_SHA256_80_init_armv8(input, tstate, ostate, 1);

	PBKDF2_SHA256_80_128_armv8(tstate, ostate, input, X);
 
	// Wait for all scrypt_core() to stop
	while(startwork == 0) { asm volatile("nop"); };

	scrypt_core(X, V, thr_id, totalthreads); // Hardcode N into function instead

	PBKDF2_SHA256_128_32_armv8(tstate, ostate, X, output, 1);
}

#ifdef HAVE_SHA256_4WAY
static void scrypt_1024_1_1_256_4way(const uint32_t *input,
	uint32_t *output, uint32_t *midstate, unsigned char *scratchpad, int N)
{
	uint32_t _ALIGN(128) tstate[4 * 8];
	uint32_t _ALIGN(128) ostate[4 * 8];
	uint32_t _ALIGN(128) W[4 * 32];
	uint32_t _ALIGN(128) X[4 * 32];
	uint32_t *V;
	int i, k;
	
	V = (uint32_t *)(((uintptr_t)(scratchpad) + 63) & ~ (uintptr_t)(63));

	for (i = 0; i < 20; i++)
		for (k = 0; k < 4; k++)
			W[4 * i + k] = input[k * 20 + i];
	for (i = 0; i < 8; i++)
		for (k = 0; k < 4; k++)
			tstate[4 * i + k] = midstate[i];
	HMAC_SHA256_80_init_4way(W, tstate, ostate);
	PBKDF2_SHA256_80_128_4way(tstate, ostate, W, W);
	for (i = 0; i < 32; i++)
		for (k = 0; k < 4; k++)
			X[k * 32 + i] = W[4 * i + k];
	scrypt_core(X + 0 * 32, V, N);
	scrypt_core(X + 1 * 32, V, N);
	scrypt_core(X + 2 * 32, V, N);
	scrypt_core(X + 3 * 32, V, N);
	for (i = 0; i < 32; i++)
		for (k = 0; k < 4; k++)
			W[4 * i + k] = X[k * 32 + i];
	PBKDF2_SHA256_128_32_4way(tstate, ostate, W, W);
	for (i = 0; i < 8; i++)
		for (k = 0; k < 4; k++)
			output[k * 8 + i] = W[4 * i + k];
}
#endif /* HAVE_SHA256_4WAY */

#ifdef HAVE_SCRYPT_2WAY

static __attribute__ ((noinline)) void scrypt_1024_1_1_256_2way(const uint32_t *input,
	uint32_t *output, uint32_t *midstate, unsigned char *scratchpad, int N)
{
	uint32_t tstate[2 * 8] __attribute__((__aligned__(16))), ostate[2 * 8] __attribute__((__aligned__(16)));
	uint32_t X[2 * 32] __attribute__((__aligned__(16)));
	uint32_t *V __attribute__((__aligned__(16)));
	
	V = (uint32_t *)(((uintptr_t)(UNION_CAST(scratchpad, uint32_t *)) + 63) & ~ (uintptr_t)(63));

	newmemcpy(tstate +  0, midstate, 32);
	newmemcpy(tstate +  8, midstate, 32);
	HMAC_SHA256_80_init_armv8(input, tstate, ostate, 2);
	//HMAC_SHA256_80_init_armv8(input + 20, tstate +  8, ostate +  8);
	PBKDF2_SHA256_80_128_armv8(tstate +  0, ostate +  0, input +  0, X +  0);
	PBKDF2_SHA256_80_128_armv8(tstate +  8, ostate +  8, input + 20, X + 32);

	scrypt_core_2way(X, V/*, N*/); // Hardcode N into function instead

	PBKDF2_SHA256_128_32_armv8(tstate +  0, ostate +  0, X +  0, output +  0, 2);
	//PBKDF2_SHA256_128_32_armv8(tstate +  8, ostate +  8, X + 32, output +  8);
}

#endif /* HAVE_SCRYPT_2WAY */

#ifdef HAVE_SCRYPT_3WAY

static void scrypt_1024_1_1_256_3way(const uint32_t *input,
	uint32_t *output, uint32_t *midstate, unsigned char *scratchpad, int N)
{
	uint32_t _ALIGN(64) tstate[3 * 8], ostate[3 * 8];
	uint32_t _ALIGN(64) X[3 * 32];
	uint32_t *V;
	
	V = (uint32_t *)(((uintptr_t)(scratchpad) + 63) & ~ (uintptr_t)(63));

	newmemcpy(tstate +  0, midstate, 32);
	newmemcpy(tstate +  8, midstate, 32);
	newmemcpy(tstate + 16, midstate, 32);
	HMAC_SHA256_80_init(input +  0, tstate +  0, ostate +  0);
	HMAC_SHA256_80_init(input + 20, tstate +  8, ostate +  8);
	HMAC_SHA256_80_init(input + 40, tstate + 16, ostate + 16);
	PBKDF2_SHA256_80_128(tstate +  0, ostate +  0, input +  0, X +  0);
	PBKDF2_SHA256_80_128(tstate +  8, ostate +  8, input + 20, X + 32);
	PBKDF2_SHA256_80_128(tstate + 16, ostate + 16, input + 40, X + 64);

	scrypt_core_3way(X, V, N);

	PBKDF2_SHA256_128_32(tstate +  0, ostate +  0, X +  0, output +  0);
	PBKDF2_SHA256_128_32(tstate +  8, ostate +  8, X + 32, output +  8);
	PBKDF2_SHA256_128_32(tstate + 16, ostate + 16, X + 64, output + 16);
}

#ifdef HAVE_SHA256_4WAY
static void scrypt_1024_1_1_256_12way(const uint32_t *input,
	uint32_t *output, uint32_t *midstate, unsigned char *scratchpad, int N)
{
	uint32_t _ALIGN(128) tstate[12 * 8];
	uint32_t _ALIGN(128) ostate[12 * 8];
	uint32_t _ALIGN(128) W[12 * 32];
	uint32_t _ALIGN(128) X[12 * 32];
	uint32_t *V;
	int i, j, k;
	
	V = (uint32_t *)(((uintptr_t)(scratchpad) + 63) & ~ (uintptr_t)(63));

	for (j = 0; j < 3; j++)
		for (i = 0; i < 20; i++)
			for (k = 0; k < 4; k++)
				W[128 * j + 4 * i + k] = input[80 * j + k * 20 + i];
	for (j = 0; j < 3; j++)
		for (i = 0; i < 8; i++)
			for (k = 0; k < 4; k++)
				tstate[32 * j + 4 * i + k] = midstate[i];
	HMAC_SHA256_80_init_4way(W +   0, tstate +  0, ostate +  0);
	HMAC_SHA256_80_init_4way(W + 128, tstate + 32, ostate + 32);
	HMAC_SHA256_80_init_4way(W + 256, tstate + 64, ostate + 64);
	PBKDF2_SHA256_80_128_4way(tstate +  0, ostate +  0, W +   0, W +   0);
	PBKDF2_SHA256_80_128_4way(tstate + 32, ostate + 32, W + 128, W + 128);
	PBKDF2_SHA256_80_128_4way(tstate + 64, ostate + 64, W + 256, W + 256);
	for (j = 0; j < 3; j++)
		for (i = 0; i < 32; i++)
			for (k = 0; k < 4; k++)
				X[128 * j + k * 32 + i] = W[128 * j + 4 * i + k];
	scrypt_core_3way(X + 0 * 96, V, N);
	scrypt_core_3way(X + 1 * 96, V, N);
	scrypt_core_3way(X + 2 * 96, V, N);
	scrypt_core_3way(X + 3 * 96, V, N);
	for (j = 0; j < 3; j++)
		for (i = 0; i < 32; i++)
			for (k = 0; k < 4; k++)
				W[128 * j + 4 * i + k] = X[128 * j + k * 32 + i];
	PBKDF2_SHA256_128_32_4way(tstate +  0, ostate +  0, W +   0, W +   0);
	PBKDF2_SHA256_128_32_4way(tstate + 32, ostate + 32, W + 128, W + 128);
	PBKDF2_SHA256_128_32_4way(tstate + 64, ostate + 64, W + 256, W + 256);
	for (j = 0; j < 3; j++)
		for (i = 0; i < 8; i++)
			for (k = 0; k < 4; k++)
				output[32 * j + k * 8 + i] = W[128 * j + 4 * i + k];
}
#endif /* HAVE_SHA256_4WAY */

#endif /* HAVE_SCRYPT_3WAY */

#ifdef HAVE_SCRYPT_6WAY
static void scrypt_1024_1_1_256_24way(const uint32_t *input,
	uint32_t *output, uint32_t *midstate, unsigned char *scratchpad, int N)
{
	uint32_t _ALIGN(128) tstate[24 * 8];
	uint32_t _ALIGN(128) ostate[24 * 8];
	uint32_t _ALIGN(128) W[24 * 32];
	uint32_t _ALIGN(128) X[24 * 32];
	uint32_t *V;
	int i, j, k;
	
	V = (uint32_t *)(((uintptr_t)(scratchpad) + 63) & ~ (uintptr_t)(63));
	
	for (j = 0; j < 3; j++) 
		for (i = 0; i < 20; i++)
			for (k = 0; k < 8; k++)
				W[8 * 32 * j + 8 * i + k] = input[8 * 20 * j + k * 20 + i];
	for (j = 0; j < 3; j++)
		for (i = 0; i < 8; i++)
			for (k = 0; k < 8; k++)
				tstate[8 * 8 * j + 8 * i + k] = midstate[i];
	HMAC_SHA256_80_init_8way(W +   0, tstate +   0, ostate +   0);
	HMAC_SHA256_80_init_8way(W + 256, tstate +  64, ostate +  64);
	HMAC_SHA256_80_init_8way(W + 512, tstate + 128, ostate + 128);
	PBKDF2_SHA256_80_128_8way(tstate +   0, ostate +   0, W +   0, W +   0);
	PBKDF2_SHA256_80_128_8way(tstate +  64, ostate +  64, W + 256, W + 256);
	PBKDF2_SHA256_80_128_8way(tstate + 128, ostate + 128, W + 512, W + 512);
	for (j = 0; j < 3; j++)
		for (i = 0; i < 32; i++)
			for (k = 0; k < 8; k++)
				X[8 * 32 * j + k * 32 + i] = W[8 * 32 * j + 8 * i + k];
	scrypt_core_6way(X + 0 * 32, V, N);
	scrypt_core_6way(X + 6 * 32, V, N);
	scrypt_core_6way(X + 12 * 32, V, N);
	scrypt_core_6way(X + 18 * 32, V, N);
	for (j = 0; j < 3; j++)
		for (i = 0; i < 32; i++)
			for (k = 0; k < 8; k++)
				W[8 * 32 * j + 8 * i + k] = X[8 * 32 * j + k * 32 + i];
	PBKDF2_SHA256_128_32_8way(tstate +   0, ostate +   0, W +   0, W +   0);
	PBKDF2_SHA256_128_32_8way(tstate +  64, ostate +  64, W + 256, W + 256);
	PBKDF2_SHA256_128_32_8way(tstate + 128, ostate + 128, W + 512, W + 512);
	for (j = 0; j < 3; j++)
		for (i = 0; i < 8; i++)
			for (k = 0; k < 8; k++)
				output[8 * 8 * j + k * 8 + i] = W[8 * 32 * j + 8 * i + k];
}
#endif /* HAVE_SCRYPT_6WAY */
 

void randombytes(size_t length, unsigned char *randomString) { // const size_t length, supra

	static unsigned char charset[] = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789,.-#'?!";

	if(length) {
		if(randomString) {
			unsigned l = (unsigned) (sizeof(charset) -1);
			for(unsigned n = 0;n < length;n++) {
				unsigned key = rand() % l;          // per-iteration instantiation
				randomString[n] = charset[key];
			}
			randomString[length] = '\0';
		}
	}
}

extern int inline __attribute__((hot)) scanhash_scrypt(int thr_id, struct work *work, uint32_t max_nonce, uint64_t *hashes_done,
	unsigned char *scratchbuf, uint32_t N, int forceThroughput, uint32_t totalthreads)
{
	int throughput = (forceThroughput != -1) ? forceThroughput : scrypt_best_throughput();
	uint32_t *pdata = work->data;
	uint32_t *ptarget = work->target;
	// create arrays based on exact size requirements
	uint32_t data[throughput * 20], hash[throughput * 8];
	uint32_t midstate[ 8];
	uint32_t n = pdata[19] - 1;
	const uint32_t Htarg = ptarget[ 7];
 

#ifndef __aarch64__
	if (opt_ryzen_1x) {
	// force throughput to be 3 (aka AVX) instead of AVX2.
		throughput = 3;
	}
#endif
//	int i = 0;
	
#ifdef HAVE_SHA256_4WAY
	if (sha256_use_4way())
		throughput *= 4;
#endif	

	/*if (forceThroughput != -1)
	{
		throughput = forceThroughput;
	}*/

	//for (i = 0; i < throughput; i++) {
		if(opt_benchmark) {
			randombytes(80, (unsigned char *) data/* + i * 20*/); // If benchmarking generate random blockheader
		} else {
			newmemcpy(data/* + i * 20*/, pdata, 80);
		}
	//}
	//sha256_init_armv8(midstate);
	sha256_transform_armv8_init(midstate, data);
	
	do {
		//for (i = 0; i < throughput; i++)
			data[/*i * 20 + */19] = ++n;
		
#if defined(HAVE_SHA256_4WAY)
		if (throughput == 4)
			scrypt_1024_1_1_256_4way(data, hash, midstate, scratchbuf, N);
		else
#endif
#if defined(HAVE_SCRYPT_3WAY) && defined(HAVE_SHA256_4WAY)
		if (throughput == 12)
			scrypt_1024_1_1_256_12way(data, hash, midstate, scratchbuf, N);
		else
#endif
#if defined(HAVE_SCRYPT_6WAY)
		if (throughput == 24)
			scrypt_1024_1_1_256_24way(data, hash, midstate, scratchbuf, N);
		else
#endif
#if defined(HAVE_SCRYPT_2WAY)
		if (throughput == 2)
			scrypt_1024_1_1_256_2way(data, hash, midstate, scratchbuf, N);
		else
#endif
#if defined(HAVE_SCRYPT_3WAY)
		if (throughput == 3)
			scrypt_1024_1_1_256_3way(data, hash, midstate, scratchbuf, N);
		else
#endif
			scrypt_1024_1_1_256(data, hash, midstate, scratchbuf, (uint32_t) thr_id, totalthreads);

		//for (i = 0; i < throughput; i++) {
			if (hash[/*i * 8 + */7] <= Htarg) {
				if(fulltest(hash/* + i * 8*/, ptarget)) {
					//dwork_set_target_ratio(work, hash + i * 8);
					*hashes_done = n - pdata[19] + 1;
					pdata[19] = data[/*i * 20 + */19];
					applog(LOG_ERR, "thread %d found share", thr_id);
					return 1;
				}
			}
		//}
	} while (likely(n < max_nonce && !work_restart[thr_id].restart));
	
	*hashes_done = n - pdata[19] + 1;
	pdata[19] = n;
	return 0;
}

/* simple cpu test (util.c) */
void __attribute__((cold)) scrypthash(void *output, const void *input, uint32_t N)
{
	uint32_t midstate[ 8];
	char *scratchbuf = scrypt_buffer_alloc(N, -1);

	memset(output, 0, 32);
	if (!scratchbuf)
		return;

	//sha256_init_armv8(midstate);
	sha256_transform_armv8_init(midstate, input);

	//scrypt_1024_1_1_256((uint32_t*)input, (uint32_t*)output, midstate, scratchbuf, thr_id);

	free(scratchbuf);
}
